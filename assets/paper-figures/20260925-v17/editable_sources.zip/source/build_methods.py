"""Native intent diagrams. Coordinates are physical bp; no external generation."""
from pathlib import Path
import csv, json, os, subprocess, hashlib
import fitz
from anonymize import clean_pdf
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs'; OUT.mkdir(exist_ok=True)
BUILD=ROOT/'build'; BUILD.mkdir(exist_ok=True)
PRE=r'''\documentclass[border=0bp]{standalone}
\usepackage{newtxtext,newtxmath}
\usepackage{tikz}
\usetikzlibrary{arrows.meta,calc}
\definecolor{teal}{HTML}{167C80}
\definecolor{orange}{HTML}{D55E00}
\definecolor{blue}{HTML}{0072B2}
\definecolor{lag}{HTML}{A0467E}
\definecolor{gray}{HTML}{59636A}
\definecolor{ink}{HTML}{23343B}
\definecolor{hard}{HTML}{C43C39}
\DeclareMathSizes{7.2}{7.2}{7.2}{7.2}
\DeclareMathSizes{7.5}{7.5}{7.2}{7.2}
\DeclareMathSizes{8}{8}{7.2}{7.2}
\DeclareMathSizes{8.8}{8.8}{7.2}{7.2}
\DeclareMathSizes{9}{9}{7.2}{7.2}
\newcommand{\bodyfont}{\fontsize{7.5}{8.5}\selectfont}
\newcommand{\smallfont}{\fontsize{7.2}{8}\selectfont}
\newcommand{\titlefont}{\fontsize{8.8}{9.6}\selectfont\bfseries}
\newcommand{\mathfont}{\fontsize{9}{10}\selectfont}
\tikzset{every node/.style={font=\bodyfont,text=ink,inner sep=0pt,outer sep=0pt},
module/.style={rounded corners=3bp,line width=.6bp},
flow/.style={line width=.8bp,-{Stealth[length=3.5bp,width=3bp]}},
title/.style={font=\titlefont}, formula/.style={font=\mathfont}}
\begin{document}
\begin{tikzpicture}[x=1bp,y=-1bp]
'''
END='\\end{tikzpicture}\n\\end{document}\n'

def graph(x,y,w,h,which='both',labels=False):
    # An observed costly route and a target detour, with a zero-capacity hard edge.
    pts={'s':(x,y+h/2),'a':(x+w*.3,y),'b':(x+w*.7,y),'c':(x+w*.3,y+h),'d':(x+w*.7,y+h),'g':(x+w,y+h/2)}
    s=''.join(rf'\coordinate ({n}) at ({a},{b});'+'\n' for n,(a,b) in pts.items())
    s+=r'\draw[orange!35,line width=5bp,line cap=round] (a)--(b);'+'\n'
    if which in ['both','observed']:
        s+=r'\draw[gray!50,line width=3.1bp,line cap=round] (s)--(a)--(b)--(g);\draw[gray!50,line width=.65bp] (s)--(c)--(d)--(g);'+'\n'
    if which in ['both','target']:
        s+=r'\begin{scope}[teal,-{Stealth[length=3bp,width=2.6bp]},shorten >=2.8bp,shorten <=2.8bp]'+'\n'
        for route,lw in [(['s','a','b','g'],.7),(['s','c','d','g'],2.2)]:
            for a,b in zip(route,route[1:]):s+=rf'\draw[line width={lw}bp] ({a})--({b});'+'\n'
        s+='\\end{scope}\n'
    s+=r'\draw[hard,dashed,line width=.65bp,shorten >=3bp,shorten <=3bp] (a)--(d);'
    s+=rf'\node[text=hard,font=\mathfont] at ({x+w/2},{y+h/2}) {{$\times$}};'
    s+=r'\foreach \n in {s,a,b,c,d} \filldraw[white,draw=gray,line width=.6bp] (\n) circle(2.8bp);\filldraw[teal] (g) circle(2.8bp);'
    if labels:
        s+=rf'\node[anchor=east] at ({x-4},{y+h/2}) {{start}};\node[anchor=west] at ({x+w+4},{y+h/2}) {{goal}};'
    return s+'\n'

# Text budget excludes symbols/formulas and the empirical payoff strip.
F1_WORDS='Penalty view Fixed penalty Lagrangian exact settings SafeOT-Dual one price rule Budgeted flow observed start goal costly target clusters width visits hard price clipped filtered feedback PPO/TRPO adaptive Constraint view slack greedy binding LP dual clip saturates active set conditional limits'.split()

def teaser(with_strip):
    h=198 if with_strip else 134
    s=rf'\path[use as bounding box] (0,0) rectangle (396,{h});'+'\n'
    s+=r'''
\draw[module,draw=gray!45,fill=gray!2] (3,3) rectangle (99,130);
\draw[module,draw=gray!45,fill=gray!2] (297,3) rectangle (393,130);
\draw[module,draw=teal,fill=teal!3] (107,3) rectangle (289,71);
\draw[module,draw=teal!70,fill=teal!3] (107,78) rectangle (289,100);
\draw[module,draw=blue!70,fill=blue!3] (107,107) rectangle (289,130);
\node[title,text=teal] at (198,12) {SafeOT-Dual: one price rule};
\node[anchor=west] at (112,24) {1\quad Budgeted flow};
\node[text=gray] at (240,24) {observed $\hat F$};
'''
    s+=graph(140,38,116,18,labels=True)
    s+=r'''
\node[text=orange,anchor=south] at (198,37) {costly};
\node[text=teal,anchor=west] at (244,60) {target $F^\star$};
\node[font=\smallfont] at (198,66) {$\circ$ clusters $\cdot$ width: visits $\cdot$ {\color{hard}$\times$} hard};
\draw[flow,teal] (198,71)--(198,78);
\node[anchor=west] at (112,87) {2\ price};
\node[formula] at (198,86) {$\lambda_k={\color{teal}\bar\lambda_k^\star}+{\color{orange}\beta_k}$};
\node[font=\smallfont,text=teal] at (162,96) {clipped $c$, filtered};
\node[font=\smallfont,text=orange] at (247,96) {feedback $\bar J_k-B_k$};
\draw[flow,blue] (198,100)--(198,107);
\node[anchor=west] at (112,118) {3};
\node[formula] at (204,119) {$\widetilde A=\frac{A_r-\sum_k\lambda_k A_{c_k}}{1+\sum_k\lambda_k}\ \to\ \text{PPO/TRPO}$};
\node[title] at (51,14) {Penalty view};
\node[formula] at (51,35) {$C_k\to\lambda_k\to\sum$};
\node[formula] at (51,57) {$\lambda_k=\beta_k\quad(c=0)$};
\node at (51,79) {$\beta_k=\mathrm{const}$};
\node at (51,89) {Fixed penalty};
\node at (51,106) {adaptive $\beta_k$};
\node at (51,119) {Lagrangian};
\draw[flow,gray] (107,87)--(99,87);
\node[text=gray,font=\smallfont] at (51,68) {exact settings};
\node[title] at (345,14) {Constraint view};
\fill[teal!10] (307,79) rectangle (348,41);
\draw[teal,line width=.65bp] (307,41)--(348,41)--(348,79);
\draw[flow,gray,line width=.6bp] (307,79)--(386,79);
\draw[flow,gray,line width=.6bp] (307,79)--(307,29);
\node[font=\smallfont,anchor=west] at (310,30) {$\langle C_2,F\rangle$};
\node[font=\smallfont,anchor=north east] at (390,82) {$\langle C_1,F\rangle$};
\node[font=\smallfont,text=gray] at (337,38) {$\lambda_2^\star=0$};
\node[font=\smallfont,text=gray] at (322,49) {slack};
\draw[gray,line width=.65bp] (376,56) circle(2.2bp);\node[font=\smallfont,text=gray] at (375,45) {greedy};
\draw[flow,gray,dashed] (373,56)--(352,56);
\fill[teal] (348,56) circle(2.3bp);
\node[anchor=east,font=\smallfont] at (344,58) {$F^\star$};
\draw[flow,teal] (348,69)--(366,69);
\node[font=\smallfont,text=teal,anchor=west] at (351,65) {$\lambda_1^\star>0$};
\node[font=\smallfont,text=teal] at (330,73) {binding};
\node[font=\smallfont] at (345,98) {$\varepsilon\to0$: LP dual};
\node[font=\smallfont] at (345,109) {clip saturates: active set};
\node[font=\smallfont,text=gray] at (345,121) {conditional limits};
\draw[flow,gray] (289,87)--(297,87);
'''
    if with_strip:s+=payoff()
    return s

def payoff():
    data=list(csv.DictReader((ROOT/'figure3c_alltask_aggregate.csv').open()))
    stats=json.loads((ROOT/'primary_V_summaries.json').read_text())
    s=r'''
\draw[gray!35,line width=.5bp] (3,136)--(393,136);
\node[anchor=west,font=\smallfont\bfseries] at (3,143) {Training cost$/B$};
\draw[blue,line width=1.1bp] (107,143)--(117,143);
\node[anchor=west,font=\smallfont] at (120,143) {SafeOT-Dual};
\draw[lag,densely dotted,line width=1bp] (172,143)--(182,143);
\node[anchor=west,font=\smallfont] at (185,143) {TRPO-Lag ($c=0$)};
\node[anchor=east,font=\smallfont,text=gray] at (393,143) {shaded: median excess};
'''
    for suite,x0,ymax,yticks in [('SafePO',20,2.6,[0,1,2]),('Bullet',219,22,[1,10,20])]:
        st=stats[suite];stat=f"{st['point']:.2f}";ci='['+','.join(f'{v:.2f}'.removeprefix('0') for v in st['ci95'])+']';wins=f"{st['lower_V']}/{st['n_tasks']}"
        top,hh,ww=159,27,111
        xy=lambda x,y:(x0+x/100*ww,top+hh-y/ymax*hh)
        coords=lambda a:'--'.join(f'({x:.9f},{y:.9f})' for x,y in a)
        s+=rf'\node[font=\smallfont\bfseries] at ({x0+ww/2},153) {{{suite} ({10 if suite=="SafePO" else 6} tasks)}};'
        for meth,col,sty in [('TRPO-Lag','lag','densely dotted'),('SafeOT-Dual','blue','solid')]:
            rr=sorted([(float(r['progress_pct']),float(r['cost_over_budget_median'])) for r in data if r['suite']==suite and r['method']==meth])
            assert max(y for x,y in rr)<ymax
            poly=[xy(x,max(1,y)) for x,y in rr]+[xy(rr[-1][0],1),xy(rr[0][0],1)]
            s+=rf'\fill[{col},opacity=.13] {coords(poly)}--cycle;'
            s+=rf'\draw[{col},{sty},line width=1bp,line join=round] {coords([xy(x,y) for x,y in rr])};'
        s+=rf'\draw[gray,line width=.5bp] ({x0},{top})--({x0},{top+hh})--({x0+ww},{top+hh});'
        y1=xy(0,1)[1]
        s+=rf'\draw[gray,dashed,line width=.5bp] ({x0},{y1})--({x0+ww},{y1});'
        for t in yticks:
            yy=xy(0,t)[1];s+=rf'\node[anchor=east,font=\smallfont] at ({x0-3},{yy}) {{{t}}};'
        for v,label in [(0,'0'),(100,r'100\%')]:
            s+=rf'\node[anchor=north,font=\smallfont] at ({x0+v/100*ww},{top+hh+2}) {{{label}}};'
        sx=x0+ww+7
        s+=rf'\node[anchor=west,font=\smallfont] at ({sx},162) {{ $V$ ratio: ${stat}$}};'
        s+=rf'\node[anchor=west,font=\smallfont] at ({sx},173) {{$ {ci} $}};'
        s+=rf'\node[anchor=west,font=\smallfont] at ({sx},184) {{{wins} lower}};'
    return s

F2_WORDS='Graph space once per epoch Observed flow Eq Budgeted projection Target flow Budget shadow prices target only not executed clip EMA realization gap Lemma Policy space Rollout GAE Realized feedback Eq Price Eq Priced advantage PPO TRPO next rollout Alg lines'.split()
def framework():
    s=r'''
\path[use as bounding box] (0,0) rectangle (396,165.6);
\node[title,anchor=west,text=teal] at (3,7) {Graph space};
\node[anchor=west,text=gray,font=\smallfont] at (65,7) {(once per epoch)};
\draw[module,draw=gray!50,fill=gray!2] (3,18) rectangle (74,87);
\draw[module,draw=teal,fill=teal!3] (82,18) rectangle (282,87);
\draw[module,draw=teal!65,fill=teal!3] (291,18) rectangle (393,87);
\node[font=\fontsize{8.8}{9.6}\selectfont\bfseries] at (38.5,28) {Observed flow};
\node[title,text=teal] at (182,28) {Budgeted projection\quad Eq. (3)};
\node[title,text=teal] at (342,28) {Target flow};
'''+graph(12,44,52,16,'observed')+graph(304,44,75,16,'target')+r'''
\node at (38.5,74) {$\hat F,\ A,\ C_k,\ b_k$};
\node[formula] at (182,44) {$\displaystyle F^\star=\mathop{\arg\min}_{F\ge0}-\langle A,F\rangle+\varepsilon\,\mathrm{KL}(F\|\hat F)$};
\node[font=\fontsize{8}{9}\selectfont] at (182,60) {$F\mathbf1-\gamma F^\top\mathbf1=(1-\gamma)\boldsymbol\mu_0$};
\node[font=\fontsize{8}{9}\selectfont] at (182,76) {$\langle C_k,F\rangle\le b_k\ (k\in\mathcal K_{\rm s}),\quad F_H=0$};
\draw[flow,gray] (74,55)--(82,55);
\draw[flow,teal] (282,55)--(291,55);
\node[font=\smallfont] at (342,70) {target only, not executed};
\node[font=\smallfont,text=teal] at (342,81) {Budget shadow prices $\lambda_k^\star$};
\draw[flow,teal] (342,87)--(342,96)--(229,96)--(229,115);
\node[fill=white,text=teal,font=\smallfont] at (323,102) {clip $c$ + EMA};
\draw[gray,dashed,line width=.65bp] (298,66)--(287,66)--(287,93)--(144,93)--(144,107);
\draw[gray,line width=.8bp] (298,63)--(298,69);
\node[fill=white,text=gray,font=\smallfont] at (176,93) {realization gap (Lemma 5)};
\draw[flow,gray!70] (3,125)--(.7,125)--(.7,93)--(20,93)--(20,87);\node[title,anchor=west,text=gray] at (3,100) {Policy space};
\draw[module,draw=gray!45,fill=gray!3] (3,107) rectangle (84,143);
\draw[module,draw=orange!70,fill=orange!4] (97,107) rectangle (191,143);
\draw[module,draw=blue!70,fill=blue!3] (265,107) rectangle (328,143);
\draw[module,draw=gray!45,fill=gray!3] (340,107) rectangle (393,143);
\node[title,text=gray] at (43.5,117) {Rollout + GAE};
\node[formula,text=gray] at (43.5,130) {$\pi_t\to\hat A_r,\hat A_{c_k}$};
\node[title,text=orange] at (144,117) {Realized feedback};
\node at (144,133) {$\bar J_k-B_k\to{\color{orange}\beta_k}$\quad Eq. (4)};
\draw[flow,gray] (84,125)--(97,125);
\node[font=\smallfont,fill=white] at (90,103) {$\bar J_k$};
\draw[flow,orange] (191,125)--(222,125);
\node[font=\smallfont,text=orange] at (204,119) {$\beta_k$};
\draw[blue,line width=.7bp,fill=white] (229,125) circle(7bp);
\node[formula,text=blue] at (229,125) {$+$};
\draw[flow,blue] (236,125)--(265,125);
\node[text=blue,font=\smallfont] at (250,119) {$\lambda_k$};
\node[formula] at (229,142) {$\lambda_k={\color{teal}\bar\lambda_k^\star}+{\color{orange}\beta_k}$};
\node[font=\fontsize{8.8}{9.6}\selectfont\bfseries,text=blue,align=center] at (296.5,118) {Priced\\advantage};
\node[formula,text=blue] at (296.5,134.5) {$\widetilde A$\quad Eq. (5)};
\draw[flow,blue] (328,125)--(340,125);
\node[font=\smallfont,text=blue,fill=white] at (334,116) {$\widetilde A$};
\node[title,text=gray] at (366.5,118) {PPO/TRPO};
\node[formula,text=gray] at (366.5,135) {$\pi_{t+1}$};
\draw[flow,gray] (64,143)--(64,151)--(296.5,151)--(296.5,143);
\node[font=\smallfont,fill=white,text=gray] at (144,151) {$\hat A_r,\hat A_{c_k}$};
\draw[flow,gray] (381,143)--(381,161)--(31,161)--(31,143);
\node[font=\smallfont,fill=white,text=gray] at (230,161) {next rollout};
\node[font=\smallfont,anchor=east,text=gray] at (391,7) {Alg. 1, lines 4--8};
'''
    return s

def compile_fig(name,body,words):
    p=ROOT/(name+'.tex');p.write_text(PRE+body+END)
    log=BUILD/(name+'.stdout.txt')
    with log.open('w') as f:
        cp=subprocess.run(['/usr/bin/pdflatex','-halt-on-error','-interaction=nonstopmode','-output-directory',str(BUILD),str(p)],stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'PATH':'/usr/bin:/bin:'+os.environ['PATH']})
    if cp.returncode:raise RuntimeError(log.read_text()[-5000:])
    dest=OUT/(name+'.pdf');clean_pdf(BUILD/(name+'.pdf'),dest)
    with fitz.open(dest) as d:
        p=d[0];(OUT/(name+'.svg')).write_text(p.get_svg_image(text_as_path=True))
        for ext,cs in [('300dpi',fitz.csRGB),('grayscale',fitz.csGRAY)]:
            pm=p.get_pixmap(matrix=fitz.Matrix(300/72,300/72),colorspace=cs,alpha=False);pm.set_dpi(300,300);pm.save(OUT/(name+'_'+ext+'.png'))
        spans=[s for b in p.get_text('dict')['blocks'] if 'lines' in b for l in b['lines'] for s in l['spans'] if s['text'].strip()]
        rpt={'size_in':[p.rect.width/72,p.rect.height/72],'minimum_font_pt':min(s['size'] for s in spans),'text_outside_page':[s['text'] for s in spans if not p.rect.contains(fitz.Rect(s['bbox']))],'raster_images':len(p.get_images()),'all_fonts_embedded':all(d.extract_font(f[0])[3] for f in p.get_fonts()),'word_count_math_excluded':len(words),'word_inventory':words,'metadata':d.metadata,'source_sha256':hashlib.sha256((ROOT/(name+'.tex')).read_bytes()).hexdigest()}
        (OUT/(name+'.report.json')).write_text(json.dumps(rpt,indent=2));print(name,rpt['size_in'],rpt['minimum_font_pt'],rpt['text_outside_page'])
        assert rpt['minimum_font_pt']>=7 and not rpt['text_outside_page']

if __name__=='__main__':
    compile_fig('Figure1A',teaser(False),F1_WORDS)
    compile_fig('Figure1B',teaser(True),F1_WORDS)
    compile_fig('Figure2',framework(),F2_WORDS)
