# Editable native figures

Run from this directory:

```
python3 build_methods.py
python3 build_figure3.py --alignment preferred_a41_alignment.json
python3 make_accessibility.py
```

Requirements: Python, NumPy, Matplotlib, PyMuPDF, Pillow; pdfLaTeX with newtxtext/newtxmath and TikZ. No external service is used. Output goes to outputs/. PDF and SVG are native vector; edit the TikZ or Python sources to change labels and layout. The math glyphs in SVG are outlined to preserve their appearance across machines.

Use the figures at 5.5 in width. Figure1A is the diagram-only alternative; Figure1B includes the empirical strip. Figure2 is 2.3 in tall; Figure3 is 4.4 in tall. Gray and two color-vision simulations are review previews, not separate scientific results.

Data are the frozen producer summaries, copied unchanged. No forest effects, confidence intervals, IQR values or reward/cost pairings are recomputed. Dagger counts apply the existing budget boundary to the supplied final task means; see dagger_cost_receipt.json. Primary V summaries in Figure1B use the estimators named in its caption; they are not areas under the median curves and are not the broader-cohort forest estimators.
