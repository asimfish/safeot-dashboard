from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib,json,re,shutil
import fitz

RUN=Path(__file__).resolve().parent
ROOT=RUN.parents[1]
D=RUN/'delivery';Q=RUN/'outputs/qa';P=RUN/'paper-preview'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    assert not (D/'manifest.json').exists()
    doc=fitz.open(P/'main.pdf')
    refs=[i+1 for i,p in enumerate(doc) if re.search(r'(?m)^REFERENCES\s*$',p.get_text())]
    assert len(doc)==57 and refs[0]==10
    log=(P/'main.log').read_text();issues=[s for s in log.splitlines() if re.search(r'Overfull|undefined|multiply defined|^!|LaTeX Error',s)]
    assert not issues
    fonts={f[0]:f for p in doc for f in p.get_fonts(full=True)}
    assert all(doc.extract_font(x)[3] for x in fonts)
    before=json.loads((Q/'paper-preview-provenance.json').read_text())
    assert sha(ROOT/'iclr_2027_v2/main.pdf')==before['canonical_main_pdf_sha256_before']
    aux=(P/'main.aux').read_text();pages={}
    for i,name in enumerate(['concept','method'],1):
        match=re.search(r'\\newlabel\{fig:safeot-dual-'+name+r'\}\{\{\d+\}\{(\d+)\}',aux);assert match
        pages[i]=int(match.group(1));doc[pages[i]-1].get_pixmap(matrix=fitz.Matrix(1.6,1.6)).save(Q/f'paper_figure{i}_page.png')
    excerpt=fitz.open()
    for page in pages.values():excerpt.insert_pdf(doc,from_page=page-1,to_page=page-1)
    excerpt.save(D/'ICLR2027_figure_placement.pdf')
    report={'status':'PASS','base':'Frozen author-referenced R2','pages':57,'main_text_pages':9,'references_start_page':10,
            'figure_pages':pages,'latex_issues':issues,'pdf_fonts_embedded':True,'canonical_main_unchanged':True,
            'width_fraction':.98,'min_ordinary_label_pt':{**{f'Figure{x["figure"]}':x['min_ordinary_label_pt_at_5_5in']*.98 for x in json.loads((Q/'native-verification.json').read_text())['figures']}},
            'scope':'Placement check of a separate R2 preview. Not submission clearance or a replacement for active writer work.'}
    (Q/'paper-placement.json').write_text(json.dumps(report,indent=2)+'\n')
    (D/'README.md').write_text('''# SafeOT-Dual figures — 2026-09-24 editorial refinement

This revision follows the author's choice of the rich legacy 53-page manuscript
as the visual/content-density reference, while using the current price-based method.

Figure1 makes one shared construction connect penalty and constraint views. It
retains multiple cost budgets, hard graph support, the graph objective, price
filtering and feedback, exact zero-clip settings and conditional graph limits.
Figure2 organizes the actual mechanism into graph-space pricing and policy-space
learning, with a separate GAE bypass and one outer policy rollout loop.

All displayed PNG previews are actual LibreOffice renders of the delivered PPTX.
The two figures contain 475 native leaf objects and no raster artwork. Text,
formula parts, nodes, panels and connectors can be edited. Formulas are grouped
styled text and lines, not Office Math / OMML. Moving a module does not reroute its
external connectors automatically. Fonts: Liberation Sans for labels and Liberation Serif for mathematics; the editing
machine needs both fonts. PDF exports embed fonts. PowerPoint/WPS rendering has
not been checked separately from LibreOffice.

SuperTeaser 3.2.21 guided the source and composition contracts. Built-in image
generation created visual proposals; provider model ID was not exposed. Both
proposals are retained as unadopted design history. This separate SuperImg2PPT
0.3.15 native semantic redraw corrects mathematical and routing details.
This is not a pixel-faithful conversion claim. The original generated files and
previous native version are preserved.

Verification: geometry, native-object, actual-render text/font and sampled target
fill checks pass. Both actual figure renders were inspected. Duplicate-file group
movement and label editing were verified. Main labels are about 6.7–7.5 pt at 5.5 inches; small axis/qualification
notes are about 6 pt. Formula scripts are smaller. Exact minima are recorded in
native-verification.json. Sans labels and serif math replace the prior uniform
serif treatment; schematic miniatures carry the richer visual content.
The isolated paper preview places both at 98% text width and retains 9 main pages,
57 total pages, embedded PDF fonts and zero overfull/undefined LaTeX diagnostics.
ICLR2027_figure_placement.pdf is an excerpt of the two figure pages, not the full
paper. Canonical manuscripts and active writer revisions were not overwritten.

Scientific scope: current graph prices plus cost feedback, not old capacity
compilation or F*/F-hat reweighting. Exact zero-clip settings and conditional
graph-price limits are different claims. No exact CPO recovery, graph-solve
superiority, or deployed-policy feasibility guarantee is implied.

Keep these dated files unchanged. New revisions should use a new version path.
''')
    (D/'captions.tex').write_text(r'''% Proposed captions for the revised concept/framework pair.
% The graph limits require the assumptions in the pricing section.
\textbf{One price rule connects two views.} SafeOT-Dual jointly prices empirical
graph constraints and combines the clipped, filtered prices with realized-cost
feedback in a shared policy-update rule. Setting the graph clip to zero gives
fixed-penalty or Lagrangian feedback settings. The graph-price limits are conditional
and retain clipping and feedback; external algorithms such as CPO are not recovered.
The cost-map tiles and budget geometry are schematic and contain no measured
results. Graphs do not certify deployed-policy feasibility.

\textbf{From joint graph constraints to policy learning.} Rollouts supply an
empirical graph, GAE advantages and episode-cost feedback. The dual solve uses
per-step budgets $b_k=B_k/L$, while feedback uses episodic budgets $B_k$. Only
prices pass from the graph construction to the PPO/TRPO update. GAE follows an
independent path, and the updated policy generates the next rollout. The figure
depicts the on-policy instantiation; separate off-policy executors are omitted.
''')
    shutil.copy2(Q/'native-verification.json',D/'native-verification.json')
    shutil.copy2(Q/'paper-placement.json',D/'paper-placement.json')
    bundle=D/'SafeOT_Dual_source_bundle.zip'
    with ZipFile(bundle,'x',compression=ZIP_DEFLATED,compresslevel=6) as z:
        for n in ['author.py','drawing.py','assemble.py','finalize_delivery.py']:z.write(RUN/n,n)
        z.write(D/'README.md','README.md')
        for folder in ['outputs/prompts','outputs/generated','state']:
            for p in (RUN/folder).rglob('*'):
                if p.is_file():z.write(p,p.relative_to(RUN))
        for n in ['figure1_r04','figure2_r02']:
            job=RUN/'outputs/native'/n
            for p in job.rglob('*'):
                if p.is_file() and 'build_01' not in p.parts:z.write(p,p.relative_to(RUN))
            for n2 in ['validation.json','editability.json','fonts.json','scene.resolved.json']:
                z.write(job/'build_01'/n2,(job/'build_01'/n2).relative_to(RUN))
    with ZipFile(bundle) as z:assert z.testzip() is None
    manifest={'task':'T-FIGURE-EDITORIAL-20260924','version':'20260924-editorial','status':'author comparison candidate',
              'source_reference':'Legacy 53-page visual narrative, current graph-price scientific mechanism',
              'files':[{'name':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(D.iterdir()) if p.is_file()],
              'native_objects':475,'visible_rasters':0,'historical_retention':'All preceding versions and generated attempts retained.'}
    (D/'manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
