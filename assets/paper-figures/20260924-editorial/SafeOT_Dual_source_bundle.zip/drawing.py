"""Semantic reconstruction of the generated revision, using SuperImg2PPT native scenes.

The generated sketches remain unchanged visual references. This separate candidate
corrects their scientific defects and applies the user's requested common hierarchy.
"""
from pathlib import Path
from contextlib import contextmanager
import argparse
import json
import math
import shutil
import logging
import re
from PIL import Image
from super_img2ppt.fonts import FontCatalog, measure, ink_bounds
from super_img2ppt.mathtext import compose_file

ROOT = Path(__file__).resolve().parent
INK = '#29343E'
TEAL = '#007F85'
GRAY = '#77858D'
PALE = '#EEF6F5'
SOFT = '#F5F7F8'
LINE = '#CDD7DC'
WHITE = '#FFFFFF'
FAMILY = 'Liberation Serif'
logging.getLogger('fontTools.ttLib.tables._h_e_a_d').setLevel(logging.ERROR)

def save(p, value):
    p.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

class Drawing:
    def __init__(self, number, dest):
        self.number, self.dest = number, dest
        dest.mkdir(parents=True, exist_ok=False)
        (dest/'pages/page_001').mkdir(parents=True)
        source = ROOT/'outputs/generated'/f'Figure{number}_v01.png'
        shutil.copy2(source, dest/'pages/page_001/source.png')
        self.w, self.h = Image.open(source).size
        self.scale = self.w/2000
        self.height = self.h/self.scale
        self.elements, self.groups, self.type = [], [], []
        self.cat = FontCatalog()
        self.container = None

    def add(self,e):
        e['z']=len(self.elements)
        if self.container and 'container' not in e:
            e['container']=self.container
        self.elements.append(e)
        return e['id']

    def shape(self,id,box,fill=None,stroke=None,sw=1.8,shape='round_rect',radius=8,background=False):
        e={'id':id,'kind':'shape','shape':shape,'box':[v*self.scale for v in box]}
        if fill:e['fill']=fill
        if stroke:e.update(stroke=stroke,stroke_width=sw*self.scale)
        if shape=='round_rect':e['radius']=radius*self.scale
        if background:e['role']='background'
        return self.add(e)

    def line(self,id,a,b,color=GRAY,sw=2.1,arrow=False,dash=None):
        e={'id':id,'kind':'line','points':[[v*self.scale for v in a],[v*self.scale for v in b]],'stroke':color,'stroke_width':sw*self.scale}
        if arrow:e.update(arrow=True,arrow_head={'length':12*self.scale,'width':9*self.scale})
        else:e['line_cap']='round'
        if dash:e['dash']=[v*self.scale for v in dash]
        return self.add(e)

    def join(self,a,b,why):
        e=next(x for x in self.elements if x['id']==a)
        e.setdefault('allow_overlap_with',[]).append(b)
        e['overlap_reason']=why

    def route(self,id,points,color=GRAY,sw=2.1,arrow=True):
        ids=[]
        for i,(a,b) in enumerate(zip(points,points[1:])):
            n=self.line(f'{id}_{i}',a,b,color,sw,arrow and i==len(points)-2)
            if ids:self.join(n,ids[-1],'Adjacent native segments are joined into one explicitly specified connector.')
            ids.append(n)
        if len(ids)>1:self.groups.append({'id':id,'members':ids,'description':'One editable routed connector; fixed endpoints.'})
        return ids

    def txt(self,id,text,x,y,size=37,bold=False,italic=False,color=INK,center=False):
        face=self.cat.resolve(text,'Liberation Sans','Liberation Sans',bold,italic)
        s=size*self.scale
        width,asc,desc=measure(face,text,s)
        ink=ink_bounds(face,text,s)
        px=x*self.scale-(width/2 if center else 0)
        py=y*self.scale
        pad=max(0,-ink[0])+2
        e={'id':id,'kind':'text','box':[px-pad,py-asc-2,width+pad+5,max(asc+desc,s*1.18)+5],
           'padding':[2,0,0,pad],'text':text,'font_family':'Liberation Sans','cjk_font_family':'Liberation Sans',
           'font_size':s,'bold':bold,'italic':italic,'color':color,'fit':'strict','wrap':False,'role':'content'}
        self.type.append({'id':id,'text':text,'font_pt_at_5_5in':size*396/2000,'role':'ordinary'})
        return self.add(e)

    def math(self,id,tokens,x,y,size=40,center=False,color=INK):
        """Explicit native parts with measured advances; tuples are (text, sub, sup)."""
        parts=[]; dx=0; special=[]; expanded=[]
        for token in tokens:
            if isinstance(token,str): token=(token,'','')
            text,sub,sup=token
            chunks=[c for c in re.split(r'([⟨⟩∥])',text) if c]
            for i,c in enumerate(chunks):expanded.append((c,sub if i==len(chunks)-1 else '',sup if i==len(chunks)-1 else ''))
        for token in expanded:
            text,sub,sup=token
            if text in ['⟨','⟩','∥']:
                special.append((text,dx))
                dx+=size*.3
                continue
            if not text.strip():
                if text:
                    face=self.cat.resolve(text,FAMILY,FAMILY,False,False)
                    dx+=measure(face,text,size*self.scale)[0]/self.scale
                continue
            italic=any(c.isalpha() for c in text) and text not in ['KL','min','max','s.t.']
            face=self.cat.resolve(text,FAMILY,FAMILY,False,italic)
            width=measure(face,text,size*self.scale)[0]/self.scale
            parts.append({'text':text,'offset':[dx*self.scale,0],'italic':italic})
            dx+=width
            scriptwidth=0
            for script,dy in [(sub,size*.24),(sup,-size*.48)]:
                if script:
                    if '_' in script:
                        head,tail=script.split('_',1)
                        face=self.cat.resolve(head,FAMILY,FAMILY,False,False)
                        headwidth=measure(face,head,size*self.scale*.66)[0]/self.scale
                        parts.append({'text':head,'offset':[dx*self.scale,dy*self.scale],'size_scale':.66,'italic':False})
                        parts.append({'text':tail,'offset':[(dx+headwidth)*self.scale,(dy+size*.18)*self.scale],'size_scale':.48,'italic':False})
                        face=self.cat.resolve(tail,FAMILY,FAMILY,False,False)
                        sw=headwidth+measure(face,tail,size*self.scale*.48)[0]/self.scale
                        scriptwidth=max(scriptwidth,sw)
                        continue
                    face=self.cat.resolve(script,FAMILY,FAMILY,False,False)
                    sw=measure(face,script,size*self.scale*.66)[0]/self.scale
                    parts.append({'text':script,'offset':[dx*self.scale,dy*self.scale],
                                  'size_scale':.66,'italic':False})
                    scriptwidth=max(scriptwidth,sw)
            dx+=scriptwidth+size*.03
        left=x-dx/2 if center else x
        origin=[left*self.scale,y*self.scale]
        spec={'id':id,'origin':origin,'font_family':FAMILY,'font_size':size*self.scale,
              'color':color,'parts':parts,'z':len(self.elements)}
        if self.container:spec['container']=self.container
        p=self.dest/f'{id}.math.json';save(p,spec)
        output=self.dest/'math'/id
        compose_file(p,output)
        elements=json.loads((output/'elements.json').read_text())
        for e in elements:
            e['role']='content'
            self.add(e)
        members=[e['id'] for e in elements]
        for i,(symbol,offset) in enumerate(special):
            px=left+offset; top=y-size*.72;bottom=y+size*.08;middle=(top+bottom)/2
            if symbol=='∥':
                for j in range(2):members.append(self.line(f'{id}_parallel_{i}_{j}',[px+size*(.08+j*.14),top],[px+size*(.08+j*.14),bottom],color,max(1.4,size*.04)))
            else:
                pts=([[px+size*.22,top],[px+size*.06,middle],[px+size*.22,bottom]] if symbol=='⟨' else [[px+size*.06,top],[px+size*.22,middle],[px+size*.06,bottom]])
                self.route(f'{id}_angle_{i}',pts,color,max(1.4,size*.04),False)
                members.append(f'{id}_angle_{i}')
        if len(members)>1:self.groups.append({'id':id,'members':members,'description':'Editable formula parts and native mathematical delimiters.'})
        self.type.append({'id':id,'font_pt_at_5_5in':size*396/2000,'role':'formula_base','text':str(tokens)})
        return dx

    @contextmanager
    def module(self,id,box=None,fill=None,stroke=None,sw=1.8):
        start=len(self.elements);gstart=len(self.groups); previous=self.container
        if box:
            self.shape(id+'_panel',box,fill,stroke,sw)
            self.container=id+'_panel'
        yield
        self.container=previous
        newgroups=self.groups[gstart:]
        children={m for g in newgroups for m in g['members']}
        members=[e['id'] for e in self.elements[start:] if e['id'] not in children]
        members += [g['id'] for g in newgroups if g['id'] not in children]
        if len(members)>1:self.groups.append({'id':id,'members':members,'description':id.replace('_',' ')})

    def graph(self,id,x,y,w,h,color=TEAL):
        # A repeated directed schematic topology; no measured flow values are implied.
        coords={1:(x,y+h*.5),2:(x+w*.26,y),3:(x+w*.72,y),4:(x+w,y+h*.5),5:(x+w*.26,y+h),6:(x+w*.72,y+h)}
        edges=[(1,2),(2,3),(3,4),(1,5),(5,6),(6,4),(2,5),(3,6)]
        r=17
        with self.module(id):
            for j,(a,b) in enumerate(edges):
                a,b=coords[a],coords[b]
                length=math.dist(a,b);vx=(b[0]-a[0])/length;vy=(b[1]-a[1])/length
                self.line(f'{id}_edge{j}',(a[0]+(r+3)*vx,a[1]+(r+3)*vy),(b[0]-(r+3)*vx,b[1]-(r+3)*vy),color if j<6 else GRAY,3.2 if j<3 else 2.3,True)
            for j,(a,b) in coords.items():self.shape(f'{id}_node{j}',[a-r,b-r,r*2,r*2],WHITE,color,2,'ellipse')

    def prices(self,id,x,y):
        with self.module(id):
            for j,text in enumerate(['1','2','…','K']):
                self.shape(id+f'_cell{j}',[x+j*80,y,80,56],WHITE,LINE,1.6,shape='rect')
                previous=self.container;self.container=id+f'_cell{j}'
                if text=='…':self.txt(id+f'_txt{j}',text,x+j*80+40,y+39,37,center=True)
                else:self.math(id+f'_txt{j}',[('λ',text,'')],x+j*80+40,y+37,39,center=True,color=TEAL)
                self.container=previous

    def rollout(self,id,x,y,w):
        with self.module(id):
            for row in range(2):
                for j in range(4):
                    cx=x+j*w/3;cy=y+row*65
                    if j<3:self.line(f'{id}_r{row}_e{j}',[cx+17,cy],[cx+w/3-17,cy],GRAY,2,True)
                    self.shape(f'{id}_r{row}_n{j}',[cx-13,cy-13,26,26],PALE,TEAL,1.8,'ellipse')

    def policy_formula(self,id,x,y,size=44):
        with self.module(id):
            self.math(id+'_numerator',[('A','r',''),' − ',('∑','k',''),' ',('λ','k',''),('A','c_k','')],x,y,size,center=True)
            self.line(id+'_bar',[x-190,y+18],[x+190,y+18],INK,1.8)
            self.math(id+'_denominator',['1 + ',('∑','k',''),' ',('λ','k','')],x,y+49,size,center=True)

