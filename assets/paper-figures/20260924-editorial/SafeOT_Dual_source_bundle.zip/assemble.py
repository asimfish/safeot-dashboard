from pathlib import Path
from copy import deepcopy
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib
import json
import re
import shutil
import subprocess
import fitz
from pptx import Presentation

RUN=Path(__file__).resolve().parent
ROOT=RUN.parents[1]
D=RUN/'delivery'
QA=RUN/'outputs/qa'
SELECTED=['figure1_r04','figure2_r02']

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')

def main():
    assert not (QA/'native-verification.json').exists(), 'Assembly already completed; inspect artifacts before retrying.'
    D.mkdir(exist_ok=True);QA.mkdir(exist_ok=True)
    records=[];decks=[]
    for i,name in enumerate(SELECTED,1):
        job=RUN/'outputs/native'/name;b=job/'build_01'
        v=json.loads((b/'validation.json').read_text());assert v['status']=='pass'
        files={'pptx':b/'editable.pptx','pdf':b/'render/editable.pdf','png':b/'render/page_001.png','svg':b/'svg/page_001.svg'}
        for ext,p in files.items():
            target=D/f'Figure{i}_SafeOT_Dual.{ext}'
            if target.exists():assert sha(target)==sha(p), 'Existing delivery differs: '+str(target)
            else:shutil.copy2(p,target)
        pdf=fitz.open(files['pdf']);assert len(pdf)==1 and not pdf[0].get_images()
        font_refs={f[0]:f for f in pdf[0].get_fonts(full=True)}
        assert all(pdf.extract_font(x)[3] for x in font_refs)
        colors=sorted({span['color'] for bl in pdf[0].get_text('dict')['blocks'] for line in bl.get('lines',[]) for span in line['spans']})
        assert set(colors)<={int(x,16) for x in ['29343E','007F85','77858D','536F8E','B78129','FFFFFF']}
        edit=json.loads((b/'editability.json').read_text())['slides'][0]
        deck=Presentation(files['pptx']);decks.append(deck)
        with ZipFile(files['pptx']) as z:assert not any(n.startswith('ppt/media/') for n in z.namelist())
        records.append({'figure':i,'selected':name,'native_leaves':edit['native_leaf_objects'],'groups':len(edit['groups']),
                        'raster_images':0,'font_objects':len(font_refs),'pdf_fonts_embedded':True,
                        'all_four_automated_checks':'pass','text_colors':[f'#{c:06X}' for c in colors],
                        'min_ordinary_label_pt_at_5_5in':min(x['font_pt_at_5_5in'] for x in json.loads((job/'typography.json').read_text()) if x['role']=='ordinary')})
    combined=Presentation();combined.slide_width=decks[0].slide_width;combined.slide_height=max(d.slide_height for d in decks)
    for original in decks:
        sl=combined.slides.add_slide(combined.slide_layouts[6])
        for sh in original.slides[0].shapes:sl.shapes._spTree.insert_element_before(deepcopy(sh._element),'p:extLst')
    combined_path=D/'SafeOT_Dual_Figures_editable.pptx'
    if not combined_path.exists():combined.save(combined_path)
    cp=QA/'SafeOT_Dual_Figures_editable.pdf'
    if not cp.exists():
        result=subprocess.run(['soffice','-env:UserInstallation='+ (QA/'lo-profile').as_uri(),'--headless','--convert-to','pdf','--outdir',str(QA),str(combined_path)],capture_output=True,text=True)
        (QA/'combined-render.log').write_text(result.stdout+result.stderr);assert result.returncode==0
    doc=fitz.open(cp);assert len(doc)==2
    for i,p in enumerate(doc,1):
        original=fitz.open(D/f'Figure{i}_SafeOT_Dual.pdf')
        assert ''.join(p.get_text().split())==''.join(original[0].get_text().split())
        assert not p.get_images()
    shutil.copy2(cp,D/'SafeOT_Dual_Figures_vector.pdf')

    # Exercise actual native object editing in a duplicate, without touching originals.
    edits=[]
    for i,deck in enumerate(decks,1):
        groupname='penalty_view' if i==1 else 'empirical_graph'
        group=next(s for s in deck.slides[0].shapes if s.name==groupname)
        before=group.left;group.left+=45720
        def leaves(shapes):
            for s in shapes:
                if s.shape_type==6:yield from leaves(s.shapes)
                else:yield s
        text=next(s for s in leaves(group.shapes) if s.has_text_frame and s.text.strip())
        old=text.text;next(p for p in text.text_frame.paragraphs if p.runs).runs[0].text='Editable check'
        test=QA/f'Figure{i}_edit_test.pptx';deck.save(test)
        reread=Presentation(test);g=next(s for s in reread.slides[0].shapes if s.name==groupname)
        assert g.left==before+45720 and any(s.has_text_frame and 'Editable check' in s.text for s in leaves(g.shapes))
        edits.append({'figure':i,'group':groupname,'move_inches':.05,'original_label':old,'label_edit_verified':True})
    save(QA/'native-verification.json',{'status':'PASS','figures':records,'edit_tests':edits,
          'visual_review':'Both actual PPTX renders inspected; no clipped formulas or accidental arrows to price junction.',
          'limitations':['Formulas are grouped editable text/lines, not OMML.','Connectors are editable fixed geometry; moving a module does not auto-reroute.','LibreOffice actual rendering checked, PowerPoint/WPS not separately available.']})

    # Isolated paper preview: only the two assets and their display width change.
    preview=RUN/'paper-preview';preview.mkdir(exist_ok=False)
    package=ROOT/'paper_rewriting_output/unified_price_20260923/revisions/r2_evidence_refresh/SafeOT_Dual_r2_sources_and_code.zip'
    with ZipFile(package) as z:
        for n in z.namelist():
            if n.startswith('manuscript/') and not n.endswith('/'):
                rel=Path(n).relative_to('manuscript');assert '..' not in rel.parts
                out=preview/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(z.read(n))
    for i in (1,2):shutil.copy2(D/f'Figure{i}_SafeOT_Dual.pdf',preview/f'figures/unified_price_20260923/Figure{i}_SafeOT_Dual.pdf')
    (preview/'main.tex').write_bytes((preview/'main_safeot_dual.tex').read_bytes())
    for name,width in [('01_introduction.tex','0.90'),('04_algorithm.tex','0.94')]:
        p=preview/'sections_safeot_dual'/name;s=p.read_text();needle='width='+width+r'\linewidth'
        assert needle in s;p.write_text(s.replace(needle,r'width=0.98\linewidth',1))
    save(QA/'paper-preview-provenance.json',{'base':'Frozen R2 selected by the referenced canonical main.pdf, not active R4/R5 writing work.',
         'changes':['Figure1 PDF','Figure2 PDF','Both figure widths 0.98 linewidth'],
         'canonical_main_pdf_sha256_before':sha(ROOT/'iclr_2027_v2/main.pdf'),'source_package_sha256':sha(package)})
    print(json.dumps({'status':'PASS','native_objects':sum(r['native_leaves'] for r in records),'figures':records},indent=2))

if __name__=='__main__':main()
