"""Native semantic redraw of the inspected legacy-led generated references."""
from pathlib import Path
import argparse,json,math
from PIL import Image
from drawing import Drawing,save,INK,TEAL,GRAY,LINE,WHITE

BLUE='#536F8E';GOLD='#B78129';BT='#EDF1F6';TT='#ECF5F4';GT='#F8F1E4'

def matrix(d,id,x,y,w=110,h=65,color=TEAL,tint=TT):
    # Symbolic cost-map tiles, without measured values or a numerical color scale.
    with d.module(id):
        for r in range(3):
            for c in range(4):
                d.shape(f'{id}_{r}_{c}',[x+c*w/4,y+r*h/3,w/4-1.2,h/3-1.2],color if (r,c) in [(0,1),(1,2),(2,0)] else tint,None,shape='rect')

def panel(d,id,box,color,title,tx,ty):
    return d.module(id,box,WHITE,color,1.8)

def graph(d,id,x,y,w,h,color=TEAL):
    d.graph(id,x,y,w,h,color)
    # Native node fills add figure-ground hierarchy while leaving nodes individually editable.
    for e in d.elements:
        if e['id'] in (id+'_node2',id+'_node4',id+'_node5'):
            e['fill']=TT if color==TEAL else BT

def hard_edge(d,id,x,y):
    with d.module(id):
        d.shape(id+'_a',[x,y,24,24],WHITE,GRAY,1.8,'ellipse')
        d.shape(id+'_b',[x+140,y,24,24],WHITE,GRAY,1.8,'ellipse')
        d.line(id+'_l',[x+29,y+12],[x+61,y+12],GRAY,2)
        d.line(id+'_r',[x+103,y+12],[x+135,y+12],GRAY,2)
        d.line(id+'_x1',[x+72,y+2],[x+92,y+22],GRAY,2.6)
        d.line(id+'_x2',[x+72,y+22],[x+92,y+2],GRAY,2.6)
        d.join(id+'_x2',id+'_x1','The two strokes form a single exclusion mark on the hard-support edge.')

def prices(d,id,x,y,color=TEAL):
    with d.module(id):
        for j,k in enumerate(['1','2','…','K']):
            with d.module(id+f'_cell{j}',[x+j*64,y,62,55],TT,None):
                if k=='…':d.txt(id+'_dots','…',x+j*64+31,y+36,34,center=True,color=color)
                else:d.math(id+f'_label{j}',[('λ',k,'')],x+j*64+31,y+37,38,center=True,color=color)

def figure1(d):
    # Three views retain the legacy composition, with a visibly dominant shared construction.
    with panel(d,'penalty_view',[24,30,411,755],BLUE,'',0,0):
        d.txt('penalty_title','Penalty view',229,90,42,True,color=BLUE,center=True)
        d.math('penalty_objective',[('max','π',''),' ',('J','r',''),'(π)'],229,159,39,center=True)
        d.math('penalty_subtract',['− ',('λ','','T'),('J','c',''),'(π)'],229,208,39,center=True)
        d.line('penalty_sep',[47,239],[412,239],LINE,1.4)
        d.txt('weighted_label','Weighted costs',58,283,35,True,color=BLUE)
        for j,k in enumerate(['1','2','K']):
            y=335+j*88
            with d.module(f'cost_term{j}',[57,y-29,146,51],BT,None):
                d.math(f'jc{j}',[('J','c_'+k,''),'(π)'],130,y+6,37,center=True,color=BLUE)
            d.math(f'weight{j}',[('λ',k,'')],237,y+6,37,center=True,color=BLUE)
            d.line(f'weighted_path{j}',[263,y],[306,419 if j==0 else 431 if j==1 else 443],BLUE,2,True)
        with d.module('sum_cost',[309,404,59,59],WHITE,BLUE,1.8):
            d.txt('sum_symbol','Σ',338,444,38,center=True,color=BLUE)
        d.line('sum_output',[339,467],[339,532],BLUE,2,True)
        d.math('scalar_cost',[('λ','','T'),('J','c','')],339,583,39,center=True,color=BLUE)
        d.line('setting_rule',[47,611],[412,611],LINE,1.4)
        d.txt('exact_label','Exact settings · c = 0',57,653,35,True,color=BLUE)
        d.txt('fixed_setting','fixed β → fixed penalty',57,697,34)
        d.txt('adaptive_setting','adaptive β → Lagrangian',49,743,33)
    with panel(d,'shared_construction',[459,30,1082,755],TEAL,'',0,0):
        d.txt('method_title','SafeOT-Dual',1000,89,44,True,color=TEAL,center=True)
        d.txt('method_subtitle','One shared price construction',1000,137,35,color=GRAY,center=True)
        d.line('shared_header_rule',[482,165],[1518,165],LINE,1.4)
        for id,txt,x in [('constraints','Joint budgets',596),('graph','Shared graph',911),('prices','Safety price',1340)]:
            d.txt(id+'_heading',txt,x,210,36,True,color=TEAL,center=True)
        for j,k in enumerate(['1','2','K']):
            y=274+j*100
            matrix(d,'costmap'+str(j),516,y,114,63,GOLD,GT)
            d.math('costmap_name'+str(j),[('C',k,'')],489,y+40,34,center=True,color=GOLD)
            d.math('budget_name'+str(j),[('b',k,'')],673,y+40,35,center=True,color=GOLD)
        d.txt('hard_label','Hard support H',596,600,34,center=True)
        hard_edge(d,'hard_support',514,625)
        d.math('hard_flow',[('F','H',''),' = 0'],596,699,38,center=True)
        graph(d,'shared_graph',777,293,284,153)
        next(e for e in d.elements if e['id']=='shared_graph_node4')['fill']=TEAL
        d.math('objective_1',[('min','F',''),' − ⟨A,F⟩'],919,524,40,center=True)
        d.math('objective_2',['+ ε KL(F ∥ F̂)'],919,574,39,center=True)
        d.txt('flow_balance','flow balance',919,634,35,center=True)
        d.math('budget_constraint',[('⟨C','k',''),',F⟩ ≤ ',('b','k','')],919,693,38,center=True)
        d.line('inputs_to_graph',[706,370],[752,370],TEAL,2.5,True)
        d.line('graph_to_prices',[1086,370],[1137,370],TEAL,2.5,True)
        d.math('graph_price',[('λ','','*')],1340,269,43,center=True,color=TEAL)
        d.line('price_to_filter',[1340,286],[1340,300],TEAL,2.1,True)
        with d.module('filter',[1172,304,326,63],TT,None):
            d.txt('filter_text','Clip + filter',1335,347,36,center=True,color=TEAL)
        d.line('filter_output',[1335,372],[1335,404],TEAL,2.1,True)
        d.math('filtered_price',[('λ̄','','*')],1335,446,42,center=True,color=TEAL)
        d.line('filtered_to_plus',[1335,465],[1335,483],TEAL,2.1,True)
        with d.module('price_sum',[1307,486,56,56],WHITE,TEAL,1.7):
            d.txt('price_plus','+',1335,526,39,center=True,color=TEAL)
        d.math('feedback_beta',['β'],1468,504,39,center=True,color=GOLD)
        d.line('beta_to_plus',[1430,514],[1367,514],GOLD,2.1,True)
        d.line('sum_down',[1335,546],[1335,573],TEAL,2.1,True)
        d.math('total_price',[('λ','k',''),' = ',('λ̄','k','*'),' + ',('β','k','')],1335,617,40,center=True,color=TEAL)
        prices(d,'price_vector',1207,659)
    with panel(d,'constraint_view',[1565,30,411,755],GOLD,'',0,0):
        d.txt('constraint_title','Constraint view',1770,90,42,True,color=GOLD,center=True)
        d.math('constraint_objective',[('max','π',''),' ',('J','r',''),'(π)'],1770,159,39,center=True)
        d.math('constraint_objective2',['s.t. ',('J','c',''),'(π) ≤ B'],1770,208,39,center=True)
        d.line('constraint_sep',[1588,239],[1953,239],LINE,1.4)
        d.txt('geometry_label','Joint budgets',1598,270,35,True,color=GOLD)
        with d.module('budget_geometry'):
            d.shape('feasible_area',[1648,333,179,165],GT,None,shape='rect')
            d.line('budget_x',[1648,501],[1913,501],GRAY,1.8,True)
            d.line('budget_y',[1645,501],[1645,315],GRAY,1.8,True)
            d.join('budget_y','budget_x','The horizontal and vertical coordinate axes share the origin.')
            d.line('budget_bound_x',[1830,498],[1830,332],GOLD,2,dash=[7,5])
            d.line('budget_bound_y',[1650,330],[1830,330],GOLD,2,dash=[7,5])
            d.join('budget_bound_y','budget_bound_x','Two unit budget boundaries meet at the upper feasible corner.')
            prior=d.container;d.container='feasible_area'
            d.txt('feasible_text','feasible',1739,409,34,center=True,color=GOLD)
            d.txt('feasible_text2','region',1739,450,34,center=True,color=GOLD)
            d.container=prior
            d.txt('origin','0',1620,531,31,center=True,color=GRAY)
            d.txt('unit_x','1',1830,535,31,center=True,color=GRAY)
            d.txt('unit_y','1',1616,339,31,center=True,color=GRAY)
            d.math('cost_y',[('J','c2',''),'/',('B','2','')],1900,315,32,center=True)
            d.math('cost_x',[('J','c1',''),'/',('B','1','')],1740,553,32,center=True)
        d.txt('schematic_note','schematic',1855,580,30,color=GRAY,center=True)
        d.line('limits_rule',[1588,611],[1953,611],LINE,1.4)
        d.txt('limits_title','Graph-price limits',1598,645,34,True,color=GOLD)
        d.txt('limits_qualifier','under assumptions',1598,684,31,color=GRAY)
        d.math('limit_zero',['ε → 0'],1598,726,33)
        d.txt('limit_lp','LP-derived price',1720,725,31)
        d.math('limit_infty',['ε → ∞'],1598,770,33,color=GOLD)
        d.txt('limit_infty_text','clipped active-set',1720,769,30,color=GRAY)
    d.route('central_to_update',[[1335,789],[1335,803],[1020,803],[1020,823]],TEAL,2.3)
    with d.module('common_interface',[24,827,1952,86],WHITE,LINE,1.6):
        d.txt('interface_label','One policy-update interface',279,879,36,True,color=BLUE,center=True)
        d.math('advantage',[('Ã','',''),' = (',('A','r',''),' − ',('∑','k',''),' ',('λ','k',''),('A','c_k',''),') / (1 + ',('∑','k',''),' ',('λ','k',''),')'],1097,880,40,center=True)
        d.line('to_ppo',[1603,866],[1640,866],TEAL,2.2,True)
        d.txt('optimizer','PPO / TRPO',1800,879,38,True,color=TEAL,center=True)

def figure2(d):
    # Light rules establish spaces; white modules contain recognisable native miniatures.
    d.txt('graph_space','Graph space',32,53,38,True,color=TEAL)
    d.line('graph_space_rule',[291,41],[1968,41],LINE,1.5)
    with d.module('empirical_graph',[34,94,365,339],WHITE,BLUE,1.6):
        d.txt('empirical_title','Empirical graph',216,139,38,True,color=BLUE,center=True)
        graph(d,'empirical_network',76,200,277,132,BLUE)
        d.math('empirical_symbols',['F̂, A, ',('C','k','')],216,399,38,center=True)
    with d.module('joint_solver',[460,94,990,339],WHITE,TEAL,1.8):
        d.txt('solver_title','One constrained graph problem',955,139,38,True,color=TEAL,center=True)
        for j,k in enumerate(['1','2','K']):
            x=493+j*137
            matrix(d,f'solver_matrix{j}',x,192,98,55,GOLD,GT)
            d.math('solver_matrix_name'+str(j),[('C',k,'')],x+49,183,32,center=True,color=GOLD)
        d.math('per_step_budget',[('b','k',''),' = ',('B','k',''),'/L'],1061,224,37,center=True,color=GOLD)
        d.math('hard_support',[('F','H',''),' = 0'],1312,224,37,center=True)
        d.line('solver_rule',[483,267],[1427,267],LINE,1.3)
        d.math('objective',[('min','F',''),' − ⟨A,F⟩ + ε KL(F ∥ F̂)'],763,329,37,center=True)
        d.txt('solver_balance','flow balance',604,394,34,center=True)
        d.math('solver_constraint',[('⟨C','k',''),',F⟩ ≤ ',('b','k','')],859,394,35,center=True)
        with d.module('newton_step',[1050,313,158,91],TT,None):
            d.txt('newton_text','Newton',1129,348,34,center=True)
            d.math('newton_u',['in u'],1129,389,34,center=True)
        with d.module('bisection_step',[1256,313,164,91],TT,None):
            d.txt('bisection_text','Bisection',1338,348,34,center=True)
            d.math('bisection_lambda',['in λ'],1338,389,34,center=True)
        d.line('alternating_forward',[1213,344],[1251,344],TEAL,2,True)
        d.line('alternating_back',[1251,374],[1213,374],TEAL,2,True)
        d.txt('solver_method','Dual solver',1235,301,32,color=GRAY,center=True)
    with d.module('filter',[1516,94,450,339],WHITE,TEAL,1.6):
        d.txt('filter_title','Clip + filter',1741,139,38,True,color=TEAL,center=True)
        d.math('filter_rule1',[('λ̄','','*'),' ← (1−α)',('λ̄','','*')],1741,206,38,center=True)
        d.math('filter_rule2',['+ α clip(',('λ','','*'),',0,c)'],1741,252,38,center=True)
        d.line('clip_x',[1620,382],[1903,382],GRAY,1.6,True)
        d.line('clip_y',[1618,382],[1618,288],GRAY,1.6,True)
        d.join('clip_y','clip_x','Analytical clipping axes share the origin.')
        d.route('clipping',[[1624,379],[1789,311],[1870,311]],TEAL,2.8,False)
        d.math('cap',['c'],1580,322,33,center=True,color=GOLD)
        d.math('clip_input',[('λ','','*')],1885,420,33,center=True,color=TEAL)
    d.line('graph_to_solver',[404,284],[454,284],BLUE,2.3,True)
    d.line('solver_to_filter',[1456,284],[1510,284],TEAL,2.5,True)
    d.math('solver_price',[('λ','','*')],1483,260,35,center=True,color=TEAL)
    d.txt('policy_space','Policy space',32,521,38,True,color=BLUE)
    d.line('policy_rule_a',[291,510],[424,510],LINE,1.5)
    d.line('policy_rule_b',[444,510],[1731,510],LINE,1.5)
    d.line('policy_rule_c',[1751,510],[1968,510],LINE,1.5)
    d.txt('transfer_note','Graph prices; rollout advantages',1000,482,34,color=GRAY,center=True)
    with d.module('policy_rollout',[34,566,436,235],WHITE,BLUE,1.6):
        d.txt('rollout_title','Policy rollout',252,610,38,True,color=BLUE,center=True)
        for j,k in enumerate(['0','1','…','T']):
            x=105+j*95
            if j<3:d.line('trajectory_edge'+str(j),[x+23,653],[x+72,653],BLUE,2,True)
            with d.module('state'+str(j),[x-22,631,44,44],BT,None):
                if k=='…':d.txt('ellipsis','…',x,662,30,center=True,color=BLUE)
                else:d.math('state_label'+str(j),[('s',k,'')],x,663,31,center=True,color=BLUE)
        for row,(label,color,tint) in enumerate([('rewards',BLUE,BT),('K costs',GOLD,GT)]):
            y=714+row*54
            d.txt('observation_label'+str(row),label,60,y+7,32,color=color)
            for j in range(4):d.shape(f'observation_{row}_{j}',[222+j*60,y-20,24,24],tint,color,1,shape='rect')
    with d.module('cost_feedback',[684,606,478,154],WHITE,GOLD,1.6):
        d.txt('feedback_title','Cost feedback',923,650,37,True,color=GOLD,center=True)
        d.math('feedback_equation',['β ← [β + η(J̄ − B)',(']','+','')],923,714,38,center=True)
    with d.module('policy_update',[1462,566,350,234],WHITE,TEAL,1.8):
        d.txt('update_title','Priced policy update',1637,610,35,True,color=TEAL,center=True)
        # Shorter fraction rule keeps the full formula inside a compact panel.
        d.math('update_numerator',[('A','r',''),' − ',('∑','k',''),' ',('λ','k',''),('A','c_k','')],1637,670,35,center=True)
        d.line('fraction_bar',[1482,686],[1792,686],INK,1.7)
        d.math('update_denominator',['1 + ',('∑','k',''),' ',('λ','k','')],1637,726,35,center=True)
        d.txt('optimizer','PPO / TRPO',1637,776,35,True,color=TEAL,center=True)
    with d.module('updated_policy',[1860,603,106,156],WHITE,None):
        d.txt('updated_label','policy',1913,633,32,color=BLUE,center=True)
        d.shape('updated_policy_disc',[1872,659,81,81],BLUE,None,shape='ellipse')
        previous=d.container;d.container='updated_policy_disc'
        d.math('policy_token',[('π','t+1','')],1913,709,34,center=True,color=WHITE)
        d.container=previous
    # Direct graph input, with no accidental relay through cost feedback.
    d.route('data_to_graph',[[434,560],[434,466],[216,466],[216,439]],BLUE,2.2)
    d.txt('data_label','transitions, rewards, costs',480,555,32,color=BLUE)
    d.line('episode_costs',[476,682],[678,682],GOLD,2.2,True)
    d.math('episode_cost_label',['Episode J̄'],576,655,35,center=True,color=GOLD)
    d.route('graph_price_transfer',[[1741,439],[1741,537],[1291,537],[1291,649]],TEAL,2.6)
    d.math('filtered_price_label',[('λ̄','','*')],1333,621,37,center=True,color=TEAL)
    with d.module('price_sum',[1258,652,66,66],WHITE,TEAL,1.8):
        d.txt('sum_symbol','+',1291,698,39,center=True,color=TEAL)
    d.line('feedback_to_sum',[1168,684],[1252,684],GOLD,2.2,True)
    d.math('feedback_price',['β'],1209,653,35,center=True,color=GOLD)
    d.line('price_to_update',[1330,684],[1456,684],TEAL,2.5,True)
    d.math('total_price',['λ'],1393,653,36,center=True,color=TEAL)
    d.route('gae_bypass',[[476,756],[514,756],[514,841],[1522,841],[1522,806]],BLUE,2.2)
    d.math('gae_label',['GAE: ',('A','r',''),', ',('A','c','')],1000,825,35,center=True,color=BLUE)
    d.line('updated_policy_edge',[1818,690],[1855,690],BLUE,2.2,True)
    d.route('next_rollout',[[1913,765],[1913,899],[252,899],[252,807]],BLUE,2.2)
    d.txt('next_rollout_text','next rollout',1100,886,33,color=BLUE,center=True)

def write(d):
    scene={'version':1,'slide_width_inches':5.5,'slides':[{'id':'page_001','width':d.w,'height':d.h,'source':'pages/page_001/source.png','background':WHITE,'reviewed':True,'notes':'Legacy-led semantic redraw; diagrams are analytic/schematic, not empirical data. Native text/line math, not OMML.','elements':d.elements,'groups':d.groups}]}
    save(d.dest/'scene.json',scene);save(d.dest/'typography.json',d.type)
    regions=[{'id':'white','slide':'page_001','roi':[2,2,4,4],'actual_roi':[2,2,4,4],'kind':'solid','mode':'target','target_color':WHITE,'reason':'White publication background.'}]
    # Recoloring is requested: document deliberate semantic target colors and actual native patches.
    im=Image.open(d.dest/'pages/page_001/source.png').convert('RGB')
    for color in [BLUE,TEAL,GOLD]:
        eligible=[e for e in d.elements if e.get('fill')==color and e['kind']=='shape']
        if not eligible:continue
        e=eligible[0];x,y,w,h=e['box'];actual=[int(x+w*.4),int(y+h*.4),3,3]
        rgb=tuple(bytes.fromhex(color[1:]));best=None
        for yy in range(5,im.height-5,5):
            for xx in range(5,im.width-5,5):
                patch=[im.getpixel((xx+dx,yy+dy)) for dx in range(3) for dy in range(3)]
                if max(max(p[k] for p in patch)-min(p[k] for p in patch) for k in range(3))>4:continue
                score=sum((patch[4][k]-rgb[k])**2 for k in range(3))
                if best is None or score<best[0]:best=(score,xx,yy)
        regions.append({'id':'semantic_'+color[1:],'slide':'page_001','roi':[best[1],best[2],3,3],'actual_roi':actual,'kind':'solid','mode':'target','target_color':color,'reason':'Author-requested restrained semantic palette, matched against an identified native filled object: '+e['id']})
    save(d.dest/'appearance-plan.json',{'version':1,'regions':regions})
    save(d.dest/'redraw-changes.json',{'source':f'Figure{d.number}_v01.png','preserved':'Old53 and previous09-24 layouts remain unchanged; source raster retained.','intentional_changes':['Sans labels with serif mathematics','Lighter titles and white figure ground','Fixed blue-policy/teal-price/ochre-budget roles','Cost-map, graph, trajectory and budget geometry miniatures','Scientific formula repair and independent GAE path'],'fidelity':'Semantic redraw, not pixel-faithful tracing','formula_type':'Native grouped text/lines, not OMML','raster_objects':0})
    print(json.dumps({'scene':str(d.dest/'scene.json'),'objects':len(d.elements)}))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('figure',type=int);p.add_argument('--out',required=True);a=p.parse_args()
    d=Drawing(a.figure,Path(a.out));(figure1 if a.figure==1 else figure2)(d);write(d)
