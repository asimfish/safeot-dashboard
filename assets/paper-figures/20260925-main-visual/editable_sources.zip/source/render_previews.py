"""Style-only rendering of producer summaries; statistics are never recomputed."""
from pathlib import Path
import csv
import hashlib
import json
import shutil
import xml.etree.ElementTree as ET

import fitz
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.text import Text
from matplotlib.ticker import FixedLocator, FixedFormatter, NullLocator
import numpy as np

RUN = Path(__file__).resolve().parent
INPUT = RUN / 'inputs'
OUT = RUN / 'outputs'
STYLE = RUN / 'style'
for p in [OUT, STYLE]:
    p.mkdir(exist_ok=True)
plt.style.use(STYLE / 'safeot.mplstyle')
PALETTE = json.loads((STYLE / 'palette.json').read_text())


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def rows(name):
    with (INPUT / name).open() as f:
        return list(csv.DictReader(f))


def axes(fig, x, y, w, h):
    fw, fh = fig.get_size_inches() * 72
    return fig.add_axes([x/fw, 1-(y+h)/fh, w/fw, h/fh])


def text(fig, x, y, s, **kw):
    fw, fh = fig.get_size_inches() * 72
    return fig.text(x/fw, 1-y/fh, s, va='center', **kw)


def point(ax, r, y, color, marker, filled=True, point_key='point', lo_key='lo', hi_key='hi'):
    """Compare plotted point and interval endpoints to original producer values."""
    x = float(r[point_key])
    line, = ax.plot([x], [y], marker=marker, color=color, markersize=3.6,
                    markeredgewidth=.8, markerfacecolor=color if filled else 'white',
                    linestyle='none', zorder=4)
    assert float(line.get_xdata()[0]) == x
    audit = {'point': x, 'point_matches_csv': True, 'interval': None}
    if r[lo_key] and r[hi_key]:
        lo, hi = float(r[lo_key]), float(r[hi_key])
        assert lo <= x <= hi
        interval = ax.hlines(y, lo, hi, color=color, linewidth=.85, zorder=3)
        segment = interval.get_segments()[0]
        assert segment[0, 0] == lo and segment[1, 0] == hi
        ax.vlines([lo, hi], y-.047, y+.047, color=color, linewidth=.65, zorder=3)
        assert ax.get_xlim()[0] <= lo <= hi <= ax.get_xlim()[1]
        audit['interval'] = [lo, hi]
        audit['interval_matches_csv'] = True
    else:
        assert not r[lo_key] and not r[hi_key]
    assert ax.get_xlim()[0] <= x <= ax.get_xlim()[1]
    return audit


def export(fig, name, report):
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    outside = []
    for t in fig.findobj(Text):
        if not t.get_visible() or not t.get_text().strip():
            continue
        bb = t.get_window_extent(renderer)
        if bb.x0 < -.25 or bb.y0 < -.25 or bb.x1 > fig.bbox.x1+.25 or bb.y1 > fig.bbox.y1+.25:
            outside.append(t.get_text())
    assert not outside, outside
    p = OUT / name
    raw = p.with_suffix('.raw.pdf')
    fig.savefig(raw, metadata={'Creator': None, 'Producer': None, 'CreationDate': None})
    with fitz.open(raw) as doc:
        doc.set_metadata({})
        doc.del_xml_metadata()
        doc.save(p.with_suffix('.pdf'), garbage=4, deflate=True)
    raw.unlink()
    svg = p.with_suffix('.svg')
    fig.savefig(svg, metadata={'Creator': None, 'Date': None})
    tree = ET.parse(svg)
    root = tree.getroot()
    for parent in root.iter():
        for child in list(parent):
            if child.tag.split('}')[-1] == 'metadata':
                parent.remove(child)
    tree.write(svg, encoding='utf-8', xml_declaration=True)
    with fitz.open(p.with_suffix('.pdf')) as d:
        page = d[0]
        spans = [s for b in page.get_text('dict')['blocks'] if 'lines' in b
                 for l in b['lines'] for s in l['spans'] if s['text'].strip()]
        report.update(minimum_font_pt=min(s['size'] for s in spans),
                      size_in=[page.rect.width/72, page.rect.height/72],
                      raster_images=len(page.get_images()),
                      all_fonts_embedded=all(d.extract_font(f[0])[3] for f in page.get_fonts()),
                      metadata=d.metadata, text_outside_page=[s['text'] for s in spans
                          if not page.rect.contains(fitz.Rect(s['bbox']))])
        assert report['minimum_font_pt'] >= 7
        assert not report['raster_images'] and report['all_fonts_embedded']
        assert not report['text_outside_page']
        assert not any(v for k, v in d.metadata.items() if k not in ['format', 'encryption'])
        for suffix, colorspace in [('300dpi', fitz.csRGB), ('grayscale', fitz.csGRAY)]:
            pm = page.get_pixmap(matrix=fitz.Matrix(300/72, 300/72), colorspace=colorspace, alpha=False)
            pm.set_dpi(300, 300)
            pm.save(p.with_name(p.name+'_'+suffix+'.png'))
    p.with_suffix('.report.json').write_text(json.dumps(report, indent=2))
    plt.close(fig)
    print(name, report['size_in'], report['minimum_font_pt'])


def forest():
    name = 'cross_suite_forest'
    rr = rows('cross_suite_tidy.csv')
    selected = [r for r in rr if r['metric'] in ['V_ratio', 'R_diff_norm']]
    assert len(selected) == 28
    assert {r['suite'] for r in selected} == {'SafePO-10', 'Bullet-6'}
    assert any(r['suite']=='SafePO-B2' and r['metric']=='NOT_RUN' for r in rr)
    comps = ['TRPO-Lag', 'PPO-Lag', 'CPO', 'PPO-PID (CPPO-PID)', 'TRPO-PID', 'FOCOPS', 'CUP']
    lookup = {(r['suite'], r['comparator'], r['metric']): r for r in selected}
    assert len(lookup) == len(selected)
    fig = plt.figure(figsize=(5.5, 3.35))
    panels = [axes(fig, 87, 54, 135, 143), axes(fig, 248, 54, 137, 143)]
    text(fig, 87, 39, '(a) Learning-time violation', fontsize=8.5, fontweight='bold')
    text(fig, 248, 39, '(b) Final reward', fontsize=8.5, fontweight='bold')
    handles = [Line2D([], [], color=PALETTE['suites'][s]['color'],
                       marker=PALETTE['suites'][s]['marker'], linestyle='none',
                       markersize=4, label=s) for s in ['SafePO-10', 'Bullet-6']]
    fig.legend(handles=handles, loc='upper left', bbox_to_anchor=(.202, .995), ncol=2,
               columnspacing=1.8, borderaxespad=0)
    text(fig, 277, 10, 'SafePO-B2: not admitted', fontsize=7.2, color='#59636A')
    for ax in panels:
        ax.set_ylim(6.65, -.65)
        ax.set_yticks(range(7))
        ax.tick_params(axis='y', length=0, pad=7)
        for j in range(7):
            if j%2==0:
                ax.axhspan(j-.5, j+.5, color='#F4F6F7', zorder=0)
        ax.spines['left'].set_visible(False)
        ax.grid(axis='x', zorder=0)
    panels[0].set_yticklabels([c.replace(' (CPPO-PID)', '') for c in comps], fontsize=7.7)
    panels[1].set_yticklabels([])
    panels[0].set_xscale('log')
    panels[0].set_xlim(.12, 4.8)
    panels[0].xaxis.set_major_locator(FixedLocator([.2, .5, 1, 2, 4]))
    panels[0].xaxis.set_major_formatter(FixedFormatter(['0.2', '0.5', '1', '2', '4']))
    panels[0].xaxis.set_minor_locator(NullLocator())
    panels[1].set_xlim(-.75, .6)
    panels[1].set_xticks([-.5, 0, .5], ['−0.5', '0', '0.5'])
    for ax, x in zip(panels, [1, 0]):
        ax.axvline(x, color='#59636A', linestyle=(0, (3, 2)), linewidth=.8, zorder=1)
    audit = []
    for j, c in enumerate(comps):
        for s, dy in [('SafePO-10', -.16), ('Bullet-6', .16)]:
            st = PALETTE['suites'][s]
            for ax, metric in zip(panels, ['V_ratio', 'R_diff_norm']):
                r = lookup[s, c, metric]
                assert int(r['n_tasks']) == (10 if s == 'SafePO-10' else 6)
                a = point(ax, r, j+dy, st['color'], st['marker'])
                audit.append(dict(suite=s, comparator=c, metric=metric, **a))
    panels[0].set_xlabel('V(SafeOT-Dual) / V(baseline)', labelpad=3)
    panels[1].set_xlabel('Normalized reward difference', labelpad=3)
    text(fig, 154, 235, '← SafeOT-Dual lower | baseline lower →', fontsize=7.2, ha='center')
    text(fig, 318, 235, '← baseline higher | SafeOT-Dual higher →', fontsize=7.2, ha='center')
    caption = ('Learning-time violation and final reward across two independently evaluated suites. '
        'Each row compares SafeOT-Dual with the named baseline. Points and 95% hierarchical-bootstrap '
        'intervals are supplied by the cross-suite producer and are shown without re-aggregation. '
        'The left panel reports the median across tasks of seed-mean violation ratios; values below '
        'one favor SafeOT-Dual. The right panel reports the median normalized final-reward difference; '
        'values above zero favor SafeOT-Dual. Reward and final cost use the same evaluated policy. '
        'The producer normalizes the reward difference by the larger of the absolute baseline return '
        'and the task reward range across methods and seeds. SafePO-10 uses B=25; Bullet-6 uses B=10. '
        'PPO-PID denotes CPPO-PID on SafePO and PID-Lag on Bullet. Suites are not pooled. '
        'SafePO-B2 has no admitted data in this snapshot and contributes no plotted estimates. '
        'The SafePO source contains 686 admitted rows; this is a different cohort from the earlier '
        '534-row learning-curve and task-win-count snapshot, which is not combined with this figure.')
    (OUT/(name+'_caption.txt')).write_text(caption+'\n')
    export(fig, name, dict(source_sha256=sha(INPUT/'cross_suite_tidy.csv'),
                          plotted_points=audit, omitted_suite='SafePO-B2: NOT_RUN; no admitted estimates'))


def realization():
    name = 'realization_terms'
    rr = rows('figure3a_v3_task_metrics.csv')
    provenance = json.loads((INPUT/'figure3a_v3_sources.json').read_text())
    assert len(rr) == 50 and provenance['cohort'] == 'partial'
    tasks = sorted({r['task_short'] for r in rr})
    lookup = {(r['task_short'], r['metric']): r for r in rr}
    assert len(lookup) == 50
    blue = PALETTE['suites']['SafePO-10']['color']
    fig = plt.figure(figsize=(5.5, 3.65))
    a = axes(fig, 78, 64, 179, 164)
    b = axes(fig, 288, 64, 98, 164)
    text(fig, 78, 11, '(a) Signed budget-error terms', fontsize=8.5, fontweight='bold')
    text(fig, 288, 11, '(b) Occupancy direction', fontsize=8.5, fontweight='bold')
    text(fig, 7, 48, 'SafePO-10', fontsize=7.7, color=blue, fontweight='bold')
    text(fig, 7, 59, 'task (seeds)', fontsize=7.2, color='#59636A')
    for ax in [a, b]:
        ax.set_ylim(9.65, -.65)
        ax.set_yticks(range(10))
        ax.tick_params(axis='y', length=0, pad=5)
        ax.spines['left'].set_visible(False)
        for j in range(10):
            if j%2==0:
                ax.axhspan(j-.5, j+.5, color='#F4F6F7', zorder=0)
        ax.grid(axis='x')
        ax.axvline(0, color='#59636A', linestyle=(0, (3, 2)), linewidth=.8, zorder=1)
    a.set_xlim(-.14, 1.96)
    a.set_xticks([0, .5, 1, 1.5], ['0', '0.5', '1', '1.5'])
    b.set_xlim(-.10, .67)
    b.set_xticks([0, .3, .6], ['0', '0.3', '0.6'])
    a.set_yticklabels([f"{t} ({lookup[t, 'target_residual']['n_seeds']})" for t in tasks], fontsize=7.4)
    b.set_yticklabels([])
    styles = [('target_residual', 'o', False, -.22, 'Target residual'),
              ('flow_realization', 's', True, 0, 'Flow realization'),
              ('edge_cost_drift', '^', False, .22, 'Edge-cost drift')]
    handles = [Line2D([], [], color=blue, marker=m, markerfacecolor=blue if filled else 'white',
                      linestyle='none', markersize=3.6, label=label)
               for _, m, filled, _, label in styles]
    a.legend(handles=handles, loc='lower left', bbox_to_anchor=(-.04, 1.04), ncol=1,
             handlelength=1, labelspacing=.13, borderaxespad=0, fontsize=7.2)
    b.legend(handles=[Line2D([], [], color=blue, marker=m, markerfacecolor='white',
                             linestyle='none', markersize=3.6, label=label)
                      for m, label in [('o', 'Alignment cosine'), ('D', 'Projection fraction')]],
             loc='lower left', bbox_to_anchor=(-.04, 1.06), handlelength=1,
             labelspacing=.3, borderaxespad=0, fontsize=7.2)
    audit = []
    for j, t in enumerate(tasks):
        for metric, marker, filled, dy, _ in styles:
            r = lookup[t, metric]
            q = point(a, r, j+dy, blue, marker, filled,
                      point_key='median', lo_key='ci95_lo', hi_key='ci95_hi')
            audit.append(dict(task=t, metric=metric, **q))
        for metric, marker, dy in [('occupancy_alignment', 'o', -.12), ('occupancy_projection', 'D', .12)]:
            r = lookup[t, metric]
            q = point(b, r, j+dy, blue, marker, False,
                      point_key='median', lo_key='ci95_lo', hi_key='ci95_hi')
            audit.append(dict(task=t, metric=metric, **q))
    a.set_xlabel('Median signed term / b', labelpad=3)
    b.set_xlabel('Dimensionless', labelpad=3)
    text(fig, 78, 258, f"Partial cohort: {provenance['n_runs']} runs · {provenance['n_violating_pairs']} violating epoch pairs", fontsize=7.2, color='#59636A')
    original = (INPUT/'figure3a_v3_caption.txt').read_text().strip()
    original = original.replace('Figure 3(a), partial v3 intake:', 'Partial v3 intake:')
    original = original.replace('Dots show occupancy alignment and projection on the upper dimensionless axis,',
                                'The separate right panel shows occupancy alignment and projection on a dimensionless axis,')
    (OUT/(name+'_caption.txt')).write_text(original+' Point shapes distinguish components; all rows belong to SafePO-10. The task labels give the number of contributing training seeds.\n')
    export(fig, name, dict(source_sha256=sha(INPUT/'figure3a_v3_task_metrics.csv'),
                          source_provenance=provenance, plotted_points=audit,
                          missing_intervals=[{'task':r['task_short'], 'metric':r['metric']} for r in rr if not r['ci95_lo']]))


def mechanism():
    name = 'mechanism_frozen'
    rr = rows('mechanism_frozen_points.csv')
    assert len(rr) == 50
    expected = {'E033/solve_unc': 15, 'E033/solve_c1': 15, 'K2/solve': 10, 'K3/solve': 10}
    assert {k: sum(r['group']==k for r in rr) for k in expected} == expected
    fig = plt.figure(figsize=(5.5, 2.15))
    ax = axes(fig, 123, 33, 260, 83)
    ax.set_xscale('log')
    ax.set_xlim(.25, 3.3)
    ax.set_ylim(-.55, 3.55)
    ax.set_yticks([3, 2, 1, 0], ['Grid · unclipped (15)', 'Grid · clip 1 (15)', 'K2 Goal2 · clip 1 (10)', 'K3 Button · clip 1 (10)'])
    ax.tick_params(axis='y', length=0, pad=7)
    ax.spines['left'].set_visible(False)
    ax.xaxis.set_major_locator(FixedLocator([.3, .5, 1, 2, 3]))
    ax.xaxis.set_major_formatter(FixedFormatter(['0.3', '0.5', '1', '2', '3']))
    ax.xaxis.set_minor_locator(NullLocator())
    for j in [0, 2]:
        ax.axhspan(j-.5, j+.5, color='#F4F6F7', zorder=0)
    ax.axvline(1, color='#59636A', linestyle=(0, (3, 2)), linewidth=.8, zorder=1)
    ax.grid(axis='x')
    audit = []
    for r in rr:
        x, y = float(r['V_ratio']), float(r['plot_y'])
        line, = ax.plot([x], [y], marker=r['marker'], markersize=3.3,
                        color=PALETTE['method_semantics']['graph'], alpha=.85,
                        markeredgewidth=.5, linestyle='none')
        assert line.get_xdata()[0] == x and line.get_ydata()[0] == y
        assert ax.get_xlim()[0] < x < ax.get_xlim()[1]
        assert ax.get_ylim()[0] < y < ax.get_ylim()[1]
        audit.append(dict(group=r['group'], task=r['task'], seed=r['seed'],
                          x=x, y=y, marker=r['marker'], matches_source=True))
    text(fig, 123, 12, 'Paired solve–switch comparisons', fontweight='bold', fontsize=8.5)
    ax.set_xlabel('V(solve) / V(switch)', labelpad=2)
    text(fig, 253, 150, '← solve accumulates less violation | switch less →', ha='center', fontsize=7.2)
    caption = ('Frozen paired comparisons from the currently admitted manuscript evidence. Each dot '
        'is one producer-supplied task–seed violation ratio; smaller than one favors solving. '
        'The original ratios, task marker shapes and vertical offsets are preserved exactly. '
        'Counts are shown in parentheses. Grid compares unclipped and clip-1 graph prices with '
        'the switch on 15 cells each; K2 Goal2 and K3 Button each have 10 cells. Studies have '
        'different tasks and definitions of violation and are not pooled. Measured weak residual '
        'coupling applies to K2 only; it is not measured for K3. Both K2 and K3 fail the registered '
        'joint solve-benefit criterion; this is not an equivalence result. A lower violation ratio '
        'does not establish reward–safety dominance. No E034 or E037 outcomes are included. '
        'This existing-evidence comparison is a fallback, not the requested expanded local-budget figure.')
    (OUT/(name+'_caption.txt')).write_text(caption+'\n')
    export(fig, name, dict(source_sha256=sha(INPUT/'mechanism_frozen_points.csv'),
                          plotted_points=audit, pending_studies=['E034', 'E037'],
                          scope='admitted frozen fallback; not expanded local-budget evidence'))


if __name__ == '__main__':
    forest()
    realization()
    mechanism()
