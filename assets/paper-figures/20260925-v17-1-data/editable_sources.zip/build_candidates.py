"""Versioned style-only renders from frozen W2 exports; no experimental imputation."""
from pathlib import Path
import csv,json,hashlib
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import v17_helpers as h
R=Path(__file__).resolve().parent;OUT=R/'outputs';OUT.mkdir(exist_ok=True)
GRAY='#92989D';DARK='#59636A';BLUE='#0072B2';TEAL='#167C80';ORANGE='#D55E00'
METHODS=['TRPO-Lag','PPO-Lag','CPO','PCPO','FOCOPS','CUP','CPPO-PID','TRPO-PID','switch']
PAL=json.loads((R/'palette.json').read_text())['methods']
def rows(n):return list(csv.DictReader((R/n).open()))
def save(fig,name,checks):
 h.export(fig,OUT/name,checks)
def legend_pending(fig,x,y,label='pending'):
 h.text_bp(fig,x+8,y,label,color=DARK,fontsize=7.2)
 fw,fh=fig.get_size_inches()*72
 fig.add_artist(Line2D([x/fw],[1-y/fh],color=GRAY,marker='D',markerfacecolor='none',markersize=3.4,linestyle='none',markeredgewidth=.7))
def curves():
 ans={}
 for r in rows('figure3c_alltask_aggregate.csv'):
  for k in ['progress_pct']+[m+'_'+q for m in ['cost_over_budget','normalized_return'] for q in ['q25','median','q75']]:r[k]=float(r[k])
  ans.setdefault((r['suite'],r['method']),[]).append(r)
 return ans
def curve_handles():
 return [Line2D([],[],label=('CPPO-PID' if m=='PID-Lag' else m),color=PAL[m]['color'],linestyle=PAL[m]['linestyle'],marker=PAL[m]['marker'],markersize=2.5) for m in h.METHODS]
def figure3():
 f=rows('figure3_forest_candidate.csv');task=rows('figure3_task_ratios.csv')
 wpath=R/'figure3_win_counts.csv'
 assert wpath.exists(),'W2 same-cohort win counts are required'
 ws=rows(wpath.name);wins={(r['suite'],r['comparator']):r for r in ws}
 fig=plt.figure(figsize=(5.5,4.4));av=h.axes_bp(fig,55,54,98,112);ar=h.axes_bp(fig,280,54,108,112)
 h.text_bp(fig,2,9,'(a) Learning-time violation',fontweight='bold',fontsize=8.8);h.text_bp(fig,255,9,'(b) Final return',fontweight='bold',fontsize=8.8)
 for x in [55,280]:h.text_bp(fig,x,22,'better for SafeOT-Dual →',fontsize=7.2)
 h.text_bp(fig,196,29,'Tasks with lower V',ha='center',fontsize=7.2)
 h.text_bp(fig,176,47,'of 10',ha='center',fontsize=7.2);h.text_bp(fig,215,47,'of 6',ha='center',fontsize=7.2)
 fig.legend(handles=[Line2D([],[],label=s,color=DARK,marker=m,linestyle='none',markersize=3) for s,m in [('SafePO','o'),('Bullet','D')]],loc='center',bbox_to_anchor=(.24,1-36/316.8),ncol=2,columnspacing=.7,handletextpad=.3)
 yy=[j if j<8 else 8.9 for j in range(9)];ylim=(-.5,9.5);ybp=lambda v:54+(v+.5)/10*112
 checks=[];missing=[]
 for y in yy:fig.add_artist(Line2D([2/396,390/396],[1-ybp(y)/316.8]*2,color='#E8EAEB',linewidth=.45,zorder=-2))
 for ax,metric,ref in [(av,'V_ratio',1),(ar,'R_diff_norm',0)]:
  for j,m in enumerate(METHODS):
   for suite,delta,marker in [('SafePO-10',-.16,'o'),('Bullet-6',.16,'D')]:
    rr=[r for r in f if (r['suite'],r['comparator'],r['metric'])==(suite,m,metric)];assert len(rr)==1
    r=rr[0]
    if r['point']=='':
     assert r['status']=='pending' and r['lo']==r['hi']==''
     missing.append(dict(suite=suite,comparator=m,metric=metric,numeric_position=None));continue
    p,lo,hi=[float(r[k]) for k in ['point','lo','hi']];pending=r['status']!='observed'
    c=GRAY if pending else PAL[m]['color']
    eb=ax.errorbar(p,yy[j]+delta,xerr=[[p-lo],[hi-p]],fmt=marker,color=c,markerfacecolor='none' if pending else c,markeredgecolor=DARK,markersize=3.2,elinewidth=.7,capsize=1.3,markeredgewidth=.35)
    assert eb.lines[0].get_xdata()[0]==p and np.allclose(eb.lines[2][0].get_segments()[0][:,0],[lo,hi],atol=1e-14,rtol=0)
    if suite=='Bullet-6' and metric=='R_diff_norm' and m in ['TRPO-Lag','PPO-Lag']:
     ax.annotate('†',(p,yy[j]+delta),xytext=(4,3),textcoords='offset points',fontsize=7.2,color=DARK)
    checks.append(dict(suite=suite,comparator=m,metric=metric,point=p,lo=lo,hi=hi,source_status=r['status'],artist_matches_source=True))
  ax.axvline(ref,color=DARK,ls='--',lw=.7);ax.set_ylim(ylim[1],ylim[0]);ax.set_yticks(yy,METHODS);ax.tick_params(axis='y',length=0,pad=3);ax.tick_params(axis='x',pad=2);ax.grid(axis='x');ax.set_facecolor('none')
 av.set_xscale('log');av.set_xlim(5.5,.12);av.set_xticks([4,2,1,.5,.25],['4','2','1','.5','.25']);av.minorticks_off()
 ar.set_xlim(-.75,.75);ar.set_xticks([-.5,0,.5],['−.5','0','.5'])
 for r in checks:
  lim=sorted((av if r['metric']=='V_ratio' else ar).get_xlim());assert lim[0]<=r['lo']<=r['hi']<=lim[1],('CI clipped',r)
 for j,m in enumerate(METHODS):
  for suite,x in [('SafePO-10',176),('Bullet-6',215)]:
   w=wins.get((suite,m));assert w is not None,('missing count',suite,m)
   if w.get('wins','')!='':h.text_bp(fig,x,ybp(yy[j]),str(w['wins']),ha='center',fontsize=7.2)
   else:legend_pending(fig,x-17,ybp(yy[j]),'pending')
 h.text_bp(fig,2,ybp(8.0),'ablation',fontsize=7.2,color=DARK);h.text_bp(fig,235,ybp(8.0),'ablation',fontsize=7.2,color=DARK)
 h.text_bp(fig,103,179,'V(SafeOT) / V(baseline), log',ha='center',fontsize=7.2);h.text_bp(fig,334,179,'Normalized return difference',ha='center',fontsize=7.2)
 h.text_bp(fig,2,190,'(c) All-task learning curves',fontweight='bold',fontsize=8.8)
 fig.legend(handles=curve_handles(),loc='center',bbox_to_anchor=(.58,1-201/316.8),ncol=4,columnspacing=1.1)
 curves_checks=h.curve_panel(fig,curves(),top=219,first=45,last=242,width=146,height=30,gap=15)
 legend_pending(fig,240,190,'pending: SafePO-B2')
 save(fig,'Figure3',dict(forest_artists=checks,pending_no_numeric_position=missing,curve_artists=curves_checks,source_hashes={n:h.sha(R/n) for n in ['figure3_forest_candidate.csv','figure3_task_ratios.csv',wpath.name,'figure3c_alltask_aggregate.csv']},effects_or_intervals_recomputed=False,win_counts='exact count of supplied task ratios below 1',cohort_note='W2 recomputed forest export; historical all-task curve cohort retained and declared separately'))

def curve_only():
 fig=plt.figure(figsize=(5.5,2.3));fig.legend(handles=curve_handles(),loc='center',bbox_to_anchor=(.53,.945),ncol=4,columnspacing=1.4)
 checks=h.curve_panel(fig,curves(),top=38,first=45,last=242,width=146,height=43,gap=20)
 save(fig,'Figure3c_all_tasks',dict(curve_artists=checks,source_sha256=h.sha(R/'figure3c_alltask_aggregate.csv'),numeric_data_unchanged=True))
 # Preserve the established 16-task grid; replace display labels only.
 s=(R/'v17_helpers.py').read_text();part=s[s.index('    # One printable appendix figure'):s.index("\nif __name__=='__main__'")]
 ns=dict(h.__dict__);ns.update(handles=curve_handles());exec('def appendix():\n'+part+'\n',ns);ns['appendix']()

def figure5():
 fig=plt.figure(figsize=(2.65,4.4));checks=[]
 specs=[('figure5a_a3_cell_ratios.csv','(a) Exact tabular · K = 1 / 4 / 8',25,59,['lag','pid','switch','warm']),('figure5b_e034_cells.csv','(b) Neural grid · K = 4 / 8',111,87,['lag','pid','switch_c1','switch_c4','warm','solve_c1']),('figure5c_e037_primary_cells.csv','(c) Joint speed · primary 3 seeds',226,60,['lag','pid','switch_c1','solve_c1'])]
 colors={'lag':'#A0467E','pid':ORANGE,'switch':'#56B4E9','switch_c1':'#56B4E9','switch_c4':'#3188B5','warm':'#999999','solve_c1':TEAL}
 labels={'lag':'Lag rule','pid':'PID rule','switch':'switch','switch_c1':'switch c=1','switch_c4':'switch c=4','warm':'warm start','solve_c1':'clip c=1'}
 for file,title,top,height,rules in specs:
  rr=rows(file);ax=h.axes_bp(fig,49,top,135,height)
  h.text_bp(fig,2,top-15,title,fontweight='bold',fontsize=8.3)
  ks=sorted({int(r['K']) for r in rr});markers={k:m for k,m in zip(ks,['o','D','s'])}
  for j,rule in enumerate(rules):
   ax.axhline(j,color='#EBEDEF',lw=.45,zorder=0)
   for k in ks:
    subset=[r for r in rr if r['rule']==rule and int(r['K'])==k]
    offsets=np.linspace(-.15,.15,len(subset))+(ks.index(k)-(len(ks)-1)/2)*.18
    for r,dy in zip(subset,offsets):
     # This exact producer ratio is retained across all three panels.
     value=float(r['V_rule_over_V_solve']);assert value>0
     bad=r.get('reward_retention_0p9','1')=='0'
     artist=ax.scatter([value],[j+dy],s=7 if file.startswith('figure5a') else 11,marker=markers[k],facecolor=colors[rule],edgecolor=colors[rule],linewidths=.35,alpha=.48 if file.startswith('figure5a') else .72)
     if bad:ax.scatter([value],[j+dy],s=13,marker='x',color=DARK,linewidths=.55,zorder=4)
     assert artist.get_offsets()[0,0]==value
     checks.append(dict(file=file,rule=rule,K=k,value=value,reward_retention=r.get('reward_retention_0p9'),artist_matches_source=True))
  if file=='figure5c_e037_primary_cells.csv':
   for row in rows('provisional_observed.csv'):
    if not row['panel'].startswith('Figure5c:secondary:'):continue
    rule=row['panel'].split(':')[-1];value=float(row['point'])
    ax.scatter([value],[rules.index(rule)+.31],s=20,marker='D',facecolor='white',edgecolor=GRAY,linewidths=.8,zorder=6)
    checks.append(dict(file='provisional_observed.csv',rule=rule,value=value,status='partial',n_observed=row['n_observed'],n_planned=row['n_planned'],artist_matches_source=True))
  ax.set_xscale('log');ax.set_xlim(.08,120);ax.set_xticks([.1,1,10,100],['.1','1','10','100']);ax.minorticks_off();ax.axvline(1,color=DARK,lw=.65,ls='--');ax.grid(axis='x');ax.set_ylim(len(rules)-.5,-.5);ax.set_yticks(range(len(rules)),[labels[r] for r in rules]);ax.tick_params(axis='y',length=0,pad=2);ax.tick_params(axis='x',pad=1)
  if top==226:ax.set_xlabel('V(rule) / V(solve), log   → solve lower',fontsize=7.2,labelpad=2)
  else:ax.tick_params(axis='x',labelbottom=False)
  # K labels and marker shapes are explicit and independent of method colors.
  handles=[Line2D([],[],color=DARK,marker=markers[k],markersize=2.4,linestyle='none',label=f'K={k}') for k in ks]
  fig.legend(handles=handles,loc='center right',bbox_to_anchor=(.98,1-(top-4)/316.8),ncol=len(ks),columnspacing=.8,handletextpad=.2,handlelength=.8,fontsize=7.2)
 legend_pending(fig,6,313,'pending secondary: 6/10 cells observed')
 save(fig,'Figure5',dict(cell_artists=checks,source_hashes={s[0]:h.sha(R/s[0]) for s in specs},numeric_data_unchanged=True,ratio_orientation='V_rule / V_solve, above 1 favors solve',secondary_no_numeric_imputation=True))

def figure4():
 rr=rows('figure3a_v3_task_metrics.csv');wide=rows('figure3a_v3_task_wide.csv');tasks=[r['task'] for r in wide];short={r['task']:r['task_short'] for r in wide};fig=plt.figure(figsize=(2.65,4.4));checks=[]
 specs=[(34,130,['target_residual','flow_realization','edge_cost_drift'],['Target','Realization','Drift'],['o','s','^'],[-.22,0,.22],(-.4,2.4),'Signed component / b'),(213,77,['occupancy_alignment','occupancy_projection'],['Alignment','Projection'],['o','D'],[-.15,.15],(-.1,1.1),'Occupancy alignment / projection')]
 h.text_bp(fig,2,10,'(a) Realization · observed 24 / 30 runs',fontweight='bold',fontsize=8.3)
 h.text_bp(fig,2,187,'(b) Realized occupancy change',fontweight='bold',fontsize=8.3)
 for top,height,metrics,names,markers,offs,xlim,xlabel in specs:
  ax=h.axes_bp(fig,49,top,135,height)
  for j,t in enumerate(tasks):
   ax.axhline(j,color='#E6E8EA',lw=.4,zorder=0)
   for metric,marker,off in zip(metrics,markers,offs):
    r=next(x for x in rr if x['task']==t and x['metric']==metric);p,lo,hi=[float(r[k]) for k in ['median','ci95_lo','ci95_hi']]
    eb=ax.errorbar(p,j+off,xerr=[[p-lo],[hi-p]],fmt=marker,color=GRAY,markerfacecolor='none',markersize=2.8,elinewidth=.55,capsize=1.1,markeredgewidth=.6)
    assert eb.lines[0].get_xdata()[0]==p and np.allclose(eb.lines[2][0].get_segments()[0][:,0],[lo,hi],atol=1e-14,rtol=0)
    checks.append(dict(task=t,metric=metric,point=p,lo=lo,hi=hi,status='partial',artist_matches_source=True))
  lo=min(c['lo'] for c in checks if c['metric'] in metrics);hi=max(c['hi'] for c in checks if c['metric'] in metrics)
  ax.set_xlim(min(xlim[0],lo-.08),max(xlim[1],hi+.08));ax.axvline(0,color=DARK,lw=.6,ls='--');ax.set_ylim(9.6,-.6);ax.set_yticks(range(10),[short[t] for t in tasks]);ax.tick_params(axis='y',length=0,pad=2);ax.tick_params(axis='x',pad=1);ax.grid(axis='x');ax.set_xlabel(xlabel,fontsize=7.2,labelpad=2)
  fig.legend(handles=[Line2D([],[],color=GRAY,marker=m,markerfacecolor='none',markersize=2.7,linestyle='none',label=n) for n,m in zip(names,markers)],loc='center',bbox_to_anchor=(.55,1-(top-9)/316.8),ncol=len(names),columnspacing=.65,handletextpad=.3,handlelength=.8,fontsize=7.2)
 legend_pending(fig,6,313,'pending: final 30-run cohort')
 save(fig,'Figure4_realization_pending',dict(median_and_interval_artists=checks,source_hashes={n:h.sha(R/n) for n in ['figure3a_v3_task_metrics.csv','figure3a_v3_task_wide.csv','figure3a_v3_sources.json']},all_partial_points_gray=True,aggregation_performed_by_drawing=False,interpretation='Available-run observations, not expected final values'))

def pending_overview():
 # Literal supplied values and counts: no invented positions for unobserved cells.
 rr=rows('provisional_observed.csv');chosen=[r for r in rr if not r['panel'].startswith('Figure4a:') or r['panel'].startswith('Figure4a:realization:')]
 fig=plt.figure(figsize=(5.5,6.3));h.text_bp(fig,4,10,'Pending evidence · observed snapshots only',fontweight='bold',fontsize=9)
 legend_pending(fig,5,25,'gray: final result pending; no extrapolation')
 h.text_bp(fig,4,41,'Panel / item',fontweight='bold');h.text_bp(fig,260,41,'Observed value',fontweight='bold');h.text_bp(fig,342,41,'Runs / cells',fontweight='bold')
 y=55;check=[]
 for r in chosen:
  name=r['panel'].replace('Figure4a:realization:Safety','F4: ').replace('-v0','').replace('-v1','').replace('Figure5c:secondary:','F5 secondary: ').replace('Figure3:Bullet-6:','F3 Bullet: ')
  name=name.replace('\\quad ','').replace('$','').replace('\\to','→').replace('{','').replace('}','')
  if len(name)>58:name=name[:56]+'…'
  h.text_bp(fig,4,y,name,fontsize=7.2,color=DARK)
  val=r['point'];label=(f'{float(val):.3g}' if val else 'pending')
  legend_pending(fig,263,y,label)
  h.text_bp(fig,351,y,f'{r["n_observed"]}/{r["n_planned"]}',fontsize=7.2,color=DARK)
  if val and name.startswith('F5'):h.text_bp(fig,303,y,'V ratio',fontsize=7.2,color=DARK)
  check.append(dict(panel=r['panel'],literal_source_point=val,n_observed=r['n_observed'],n_planned=r['n_planned'],numerical_imputation=False));y+=11.0
 h.text_bp(fig,4,443,'F4: run coverage. F5: V(rule)/V(solve). RG2: observed reward; B2: no admitted estimate.',fontsize=7.2,color=DARK)
 save(fig,'Pending_evidence',dict(rows=check,source_sha256=h.sha(R/'provisional_observed.csv'),no_forecast=True))

if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--which',default='all');a=p.parse_args()
 for name,fun in [('f3',figure3),('curves',curve_only),('f4',figure4),('f5',figure5),('pending',pending_overview)]:
  if a.which in ['all',name]:fun()
