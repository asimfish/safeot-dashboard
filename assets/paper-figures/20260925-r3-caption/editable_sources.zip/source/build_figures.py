"""Reproducible native TikZ diagrams. Caption-aligned conceptual figures; schematic curves are not measured data."""
from pathlib import Path
import csv, json, math, hashlib, os, re, subprocess
import fitz
from anonymize import clean_pdf
R=Path(__file__).resolve().parent
ROOT=R.parent
O=ROOT/'outputs';B=ROOT/'build';Q=ROOT/'qa'
for p in (O,B,Q):p.mkdir(exist_ok=True)
PRE=r'''\documentclass[border=0bp]{standalone}
\usepackage{newtxtext,newtxmath}
\usepackage{tikz}
\usetikzlibrary{arrows.meta,calc}
\definecolor{teal}{HTML}{167C80}
\definecolor{orange}{HTML}{D55E00}
\definecolor{blue}{HTML}{0072B2}
\definecolor{purple}{HTML}{8064A2}
\definecolor{gray}{HTML}{59636A}
\definecolor{ink}{HTML}{23343B}
\definecolor{midgray}{HTML}{7C858B}
\DeclareMathSizes{7.2}{7.2}{7.2}{7.2}
\DeclareMathSizes{7.5}{7.5}{7.2}{7.2}
\DeclareMathSizes{8}{8}{7.2}{7.2}
\DeclareMathSizes{8.5}{8.5}{7.2}{7.2}
\DeclareMathSizes{9}{9}{7.2}{7.2}
\newcommand{\bodyfont}{\fontsize{7.5}{8.7}\selectfont}
\newcommand{\smallfont}{\fontsize{7.2}{8.2}\selectfont}
\newcommand{\titlefont}{\fontsize{8.5}{9.7}\selectfont\bfseries}
\newcommand{\mathfont}{\fontsize{9}{10}\selectfont}
\tikzset{every node/.style={font=\bodyfont,text=ink,inner sep=0pt,outer sep=0pt},
 module/.style={rounded corners=3bp,line width=.6bp},
 flow/.style={line width=.8bp,-{Stealth[length=3bp,width=2.6bp]}},
 title/.style={font=\titlefont},formula/.style={font=\mathfont}}
\begin{document}
\begin{tikzpicture}[x=1bp,y=-1bp]
'''
END='\\end{tikzpicture}\n\\end{document}\n'
class Scene:
 def __init__(self,h):self.h=h;self.s=[f'\\path[use as bounding box] (0,0) rectangle (396,{h});'];self.labels=[]
 def raw(self,s):self.s.append(s)
 def text(self,x,y,t,opt='',kind='label'):
  self.s.append(f'\\node[{opt}] at ({x},{y}) {{{t}}};');self.labels.append({'text':t,'kind':kind})
 def box(self,x,y,w,h,stroke='gray!55',fill='white',opt=''):
  self.raw(f'\\draw[module,draw={stroke},fill={fill},{opt}] ({x},{y}) rectangle ({x+w},{y+h});')
 def line(self,pts,opt='draw=gray,line width=.65bp',close=False):
  self.raw('\\draw['+opt+'] '+' -- '.join(f'({x:.4f},{y:.4f})' for x,y in pts)+(' -- cycle' if close else '')+';')
 def arrow(self,pts,col='gray',opt=''):self.line(pts,f'flow,draw={col},{opt}')
 def circle(self,x,y,r=1.8,col='gray',fill='white'):
  self.raw(f'\\filldraw[draw={col},fill={fill},line width=.55bp] ({x},{y}) circle ({r}bp);')
 def graph(self,x,y,w,h,target=False):
  pts=[(x,y+h/2),(x+w*.29,y),(x+w*.68,y),(x+w,y+h/2),(x+w*.68,y+h),(x+w*.29,y+h)]
  edges=[(0,1),(1,2),(2,3),(0,5),(5,4),(4,3)]
  col='teal' if target else 'midgray'
  for j,(i,k) in enumerate(edges):
   thick=j>=3 if target else j<3
   self.line([pts[i],pts[k]],f'draw={col},line width={1.8 if thick else .5}bp')
  for j,(xx,yy) in enumerate(pts):self.circle(xx,yy,1.55,col,col if j==3 else 'white')
 def build(self):return PRE+'\n'.join(self.s)+'\n'+END


def figure1():
 c=Scene(208.8)
 c.box(3,3,91,169,'gray!42','gray!2')
 c.box(101,3,194,169,'teal','teal!5')
 c.box(302,3,91,169,'gray!42','gray!2')
 c.text(48.5,18,r'Fixed penalty','title')
 c.text(48.5,34,'Budget leakage','font=\\smallfont')
 c.text(347.5,18,'Lagrangian','title')
 c.text(347.5,34,r'Violation-driven\\oscillation','align=center,font=\\smallfont')
 # Illustrative curves only. The two channels are separately labeled;
 # vertical magnitudes are schematic and are not experimental observations.
 for x,right in [(17,False),(316,True)]:
  y=58;w=66;h=75
  c.line([(x,y),(x,y+h),(x+w,y+h)],'draw=gray,line width=.55bp')
  budget=y+h*.48
  c.line([(x,budget),(x+w,budget)],'draw=gray,line width=.65bp,dashed')
  c.text(x-3,budget,'$B$','anchor=east,font=\\smallfont')
  ts=[i/120 for i in range(121)]
  if not right:
   cost=[.25+.50*(1-math.exp(-6*t)) for t in ts]
   price=[.15 for t in ts]
  else:
   cost=[.52-.28*math.cos(3.2*math.pi*t)*math.exp(-.35*t) for t in ts]
   price=[.27-.17*math.cos(3.2*math.pi*t-.8) for t in ts]
  cp=[(x+t*w,y+h*(1-v)) for t,v in zip(ts,cost)]
  pp=[(x+t*w,y+h*(1-v)) for t,v in zip(ts,price)]
  poly=[(x+t*w,min(budget,yy)) for t,(xx,yy) in zip(ts,cp)]+[(x+w,budget),(x,budget)]
  c.line(poly,'fill=gray!15,draw=none',True)
  c.line(cp,'draw=gray,line width=1.15bp')
  c.line(pp,'draw=purple,line width=1.1bp,dashed')
  c.text(x+w/2,145,'training','font=\\smallfont')
  c.text(x+w/2,158,r'cost\quad {\color{purple}price}','font=\\smallfont')
 # The center is the only colored module: one flow, all soft budgets.
 c.text(198,16,'SafeOT','font=\\fontsize{9}{10}\\selectfont\\bfseries,text=teal')
 c.text(198,29,'One flow solve prices all budgets','font=\\fontsize{8}{9}\\selectfont\\bfseries,text=teal')
 c.text(198,43,r'$\langle C_k,F\rangle\leq b_k\quad\forall k$','font=\\smallfont')
 c.text(138,56,r'$\widehat F$','formula')
 c.text(258,56,r'$F^\star$','formula,text=teal')
 c.graph(114,65,47,20)
 c.graph(235,65,47,20,True)
 # A zero-capacity hard edge is removed, never assigned a finite price.
 c.line([(114,75),(161,75)],'draw=red!65!black,dashed,line width=.65bp')
 c.text(137.5,75,r'$\boldsymbol\times$','text=red!65!black,fill=white,font=\\mathfont')
 c.box(172,60,51,30,'teal','teal!12')
 c.text(197.5,75,r'Entropic\\projection','align=center,text=teal,font=\\smallfont')
 c.arrow([(161,75),(172,75)],'teal')
 c.arrow([(223,75),(235,75)],'teal')
 c.text(141,105,r'hard events:\\remove edges','align=center,font=\\smallfont')
 c.line([(137.5,81),(137.5,93)],'draw=gray!70,line width=.5bp')
 c.arrow([(197.5,90),(197.5,115)],'teal')
 c.text(204,103,r'duals $\lambda^\star$','anchor=west,font=\\smallfont,text=teal')
 c.text(222,122,r'clip + EMA $\to\bar\lambda^\star$','font=\\smallfont,text=teal')
 c.arrow([(222,128),(222,134)],'teal')
 c.text(212,144,r'$\lambda=\bar\lambda^\star+{\color{orange}\beta}$','formula')
 c.text(136,138,r'observed-cost\\feedback','font=\\smallfont,align=center,text=orange')
 c.arrow([(166,141),(177,144)],'orange')
 c.arrow([(212,151),(212,157)],'teal')
 c.text(198,165,r'Actor: priced advantages','font=\\smallfont')
 # A summary rule, not a numeric continuum: settings and conditional limits
 # are explicitly separated, as in the confirmed introduction caption.
 c.box(3,179,390,27,'gray!30','gray!2')
 c.line([(198,182),(198,203)],'draw=gray!35,line width=.5bp')
 c.text(100.5,186,'Exact settings','font=\\smallfont\\bfseries')
 c.text(100.5,199,r'$c=0$: fixed penalty $\cdot$ Lagrangian','font=\\smallfont')
 c.text(295.5,186,'Conditional limits','font=\\smallfont\\bfseries')
 c.text(295.5,199,r'LP $(\varepsilon\to0)$ $\cdot$ Active-set (clip saturated)','font=\\smallfont')
 return c

def figure2():
 c=Scene(165.6)
 # Five numbered modules, with inputs/budgets stacked to free projection space.
 c.box(3,3,65,126,'gray!55','gray!2')
 c.box(76,3,78,69,'gray!55','white')
 c.box(76,79,78,50,'gray!55','white')
 c.box(163,3,123,126,'teal','teal!7')
 c.box(295,3,98,126,'gray!55','white')
 c.text(35.5,14,'1  Rollout','title,text=gray')
 c.text(115,14,'2  Rollout graph','title')
 c.text(115,89,'3  Soft budgets','title')
 c.text(220,14,'4  SafeOT projection','title,text=teal')
 c.text(280,23,'new','anchor=east,text=teal,font=\\smallfont')
 c.text(344,14,'5  Actor update','title,text=gray')
 # Standard RL source.
 c.text(35.5,35,r'$\pi_t$','formula,text=gray')
 for a,b in [((17,51),(31,51)),((36,51),(51,51))]:c.arrow([a,b])
 for x in (15,33,53):c.circle(x,51,2,'gray')
 c.box(11,69,49,34,'gray!50','white')
 c.text(35.5,78,'GAE','title,text=gray')
 c.text(35.5,94,r'$\widehat A_r,\ \widehat A_{c_k}$')
 c.text(35.5,117,r'Costs $\bar J_k$')
 # Top graph input card, all labels associated with graph semantics.
 c.graph(96,26,38,12)
 c.text(115,45,'nodes = state clusters','font=\\smallfont')
 c.text(115,54,'edges = transitions','font=\\smallfont')
 c.text(115,65,r'per edge: $\widehat F, A, C_k$','font=\\smallfont')
 c.arrow([(68,42),(76,42)])
 c.arrow([(154,42),(163,42)],'teal')
 # Budget card: one equation, not an extra forbidden-edge story.
 c.text(115,108,r'$b_k=B_k/L$','formula')
 c.text(115,121,'one bound per cost','font=\\smallfont')
 c.arrow([(154,101),(163,101)],'teal')
 # Complete benchmark projection (H is empty), with real stacked math.
 c.text(224.5,35,r'$\displaystyle\min_{F\geq0}\ -\langle A,F\rangle$')
 c.text(224.5,49,r'$+\,\varepsilon\,\mathrm{KL}(F\,\|\,\widehat F)$')
 c.text(224.5,66,r'$\begin{gathered}\text{s.t. }F\mathbf1-\gamma F^\top\mathbf1\\=(1-\gamma)\mu_0\end{gathered}$')
 c.text(224.5,85,r'$\langle C_k,F\rangle\leq b_k\quad\forall k$')
 c.graph(174,99,35,13)
 c.graph(242,99,35,13,True)
 c.arrow([(214,105.5),(237,105.5)],'teal')
 c.text(192,94,r'$\widehat F$','font=\\smallfont')
 c.text(261,94,r'$F^\star$','font=\\smallfont,text=teal')
 c.text(224.5,122,r'$F^\star$: target, not executed','font=\\smallfont,text=teal')
 # Solved multipliers cross into policy space; graph target does not.
 c.arrow([(280,105.5),(290,105.5),(290,33),(300,33)],'teal')
 c.text(306,33,r'clip $c$ + EMA','anchor=west,font=\\smallfont,text=teal')
 c.text(285,97,r'$\lambda_k^\star$','anchor=east,font=\\smallfont,text=teal')
 c.arrow([(344,39),(344,45)],'teal')
 c.text(344,54,r'$\lambda_k=\bar\lambda_k^\star+{\color{orange}\beta_k}$','formula')
 c.arrow([(344,62),(344,67)],'gray')
 c.text(344,81,r'$\displaystyle\widetilde A=\frac{\widehat A_r-\sum_k\lambda_k\widehat A_{c_k}}{1+\sum_k\lambda_k}$')
 c.arrow([(344,94),(344,100)],'gray')
 c.box(313,102,65,16,'gray!45','gray!3')
 c.text(345.5,110,'PPO / TRPO','text=gray')
 c.text(345.5,124,r'$\pi_{t+1}$','font=\\smallfont,text=gray')
 # Two distinct standard channels; no large feedback box.
 c.arrow([(60,95),(72,95),(72,136),(303,136),(303,84),(308,84)],'gray')
 c.text(167,136,r'GAE advantages $\widehat A_r,\widehat A_{c_k}$','fill=white,inner xsep=4bp,font=\\smallfont')
 c.arrow([(35.5,122),(35.5,148),(389,148),(389,54),(383,54)],'gray')
 c.text(212,148,r'${\color{orange}\beta_k}\!\leftarrow\![\beta_k+\eta(\bar J_k-B_k)]_+$','fill=white,inner xsep=4bp,font=\\smallfont')
 c.arrow([(345.5,129),(345.5,160),(7,160),(7,35),(23,35)],'gray')
 c.text(163,160,'next rollout','fill=white,inner xsep=4bp,font=\\smallfont')
 return c

CAPTIONS={
'Figure1':r'SafeOT unifies cost weighting through flow-derived prices. Schematic side panels show penalty leakage and multiplier oscillation. Center: soft budgets constrain one rollout flow; hard events delete edges. Projection duals $\lambda^\star$ become $\bar\lambda^\star$ after clipping and filtering; observed-cost feedback $\beta$ completes the actor prices. Bottom: fixed penalty and Lagrangian are settings; LP and active-set prices are conditional limits (Table~\ref{tab:unify}, Proposition~\ref{prop:endpoints}).',
'Figure2':r'SafeOT supplies budget shadow prices to a standard actor update. Gray modules perform standard RL; teal projects target visitation, never executed. Here $L$ is episode length, $\varepsilon$ the KL weight, $\eta$ the illustrative feedback step, $c$ the price cap, and $B_k$ the episode budget. Benchmark hard-edge masks $H$ are empty; otherwise $F_H=0$ excludes graph edges and action exclusion requires an executor. Clipping and EMA produce $\bar\lambda^\star$.'}

def build(name,c):
 tex=O/f'{name}.tex';tex.write_text(c.build())
 env=dict(os.environ,PATH='/usr/bin:/bin:'+os.environ.get('PATH',''))
 res=subprocess.run(['/usr/bin/pdflatex','-halt-on-error','-interaction=nonstopmode','-output-directory',str(B),str(tex)],env=env,capture_output=True,text=True)
 (Q/f'{name}_compile.txt').write_text(res.stdout+res.stderr)
 if res.returncode:raise RuntimeError(res.stdout[-4500:])
 clean_pdf(B/f'{name}.pdf',O/f'{name}.pdf')
 with fitz.open(O/f'{name}.pdf') as d:
  p=d[0]
  for suf,cs,dpi in [('300dpi',fitz.csRGB,300),('grayscale',fitz.csGRAY,300),('print96',fitz.csRGB,96)]:
   pm=p.get_pixmap(matrix=fitz.Matrix(dpi/72,dpi/72),colorspace=cs,alpha=False);pm.set_dpi(dpi,dpi);pm.save(O/f'{name}_{suf}.png')
  (O/f'{name}.svg').write_text(p.get_svg_image(text_as_path=True))
  spans=[s for b in p.get_text('dict')['blocks'] if 'lines' in b for l in b['lines'] for s in l['spans'] if s['text'].strip()]
  fonts=[{'name':f[3],'type':f[2],'embedded_bytes':len(d.extract_font(f[0])[3])} for f in p.get_fonts()]
  report={'figure':name,'size_in':[p.rect.width/72,p.rect.height/72],'min_font_pt':min(s['size'] for s in spans),'font_sizes':sorted(set(round(s['size'],4) for s in spans)),'fonts':fonts,'raster_images':len(p.get_images()),'outside':[s for s in spans if not p.rect.contains(fitz.Rect(s['bbox']))],'metadata':d.metadata,'xmp':bool(d.get_xml_metadata()),'text':p.get_text(),'label_count':len(c.labels),'non_tick_labels':sum(x['kind']!='tick' for x in c.labels),'labels':c.labels,'sha256':hashlib.sha256((O/f'{name}.pdf').read_bytes()).hexdigest()}
  report['mechanical_pass']=report['min_font_pt']>=7 and not report['outside'] and not report['raster_images'] and all(f['embedded_bytes'] for f in fonts) and abs(p.rect.width-396)<.02 and (name!='Figure1' or p.rect.height<=208.82)
 (O/f'{name}_font_report.json').write_text(json.dumps(report,indent=2))
 (O/f'{name}_caption.tex').write_text(CAPTIONS[name]+'\n')
 print(name,json.dumps({k:report[k] for k in ['size_in','min_font_pt','label_count','non_tick_labels','mechanical_pass']}),flush=True)
 return report
if __name__=='__main__':
 reports=[build('Figure1',figure1()),build('Figure2',figure2())]
 (O/'captions.json').write_text(json.dumps(CAPTIONS,indent=2)+'\n')
 (O/'font_report.json').write_text(json.dumps(reports,indent=2)+'\n')
 (O/'conceptual_receipt.json').write_text(json.dumps({'Figure1':'Schematic only; no experimental data plotted.','Figure2':'Benchmark H empty; gray feedback line illustrates fixed-step update.'},indent=2)+'\n')
