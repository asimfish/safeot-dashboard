"""Native vector method schematic. Navigation arrows are qualitative, not data."""
from pathlib import Path
import sys,json,math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle, FancyArrowPatch, PathPatch
from matplotlib.path import Path as MPath
import fitz
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parents[1]/'style'))
from safeot_style import apply_style,save_anonymous

INK='#26343D'; BLUE='#0072B2'; LIGHT='#56B4E9'; ORANGE='#D55E00'; GRAY='#64727A'; RULE='#CDD6DB'; WASH='#EDF5FA'; SOFT='#FBF0E9'; WHITE='#FFFFFF'
W,H=396,373
FONTS=[]

def main():
    apply_style()
    fig=plt.figure(figsize=(W/72,H/72));ax=fig.add_axes([0,0,1,1]);ax.set(xlim=(0,W),ylim=(H,0));ax.axis('off')
    def text(s,x,y,size=8,bold=False,color=INK,ha='left',**kw):
        t=ax.text(x,y,s,fontsize=size,fontweight='bold' if bold else 'normal',color=color,ha=ha,va='center',**kw)
        FONTS.append(t);return t
    def line(x1,y1,x2,y2,color=RULE,lw=.65,ls='-'):
        ax.plot([x1,x2],[y1,y2],color=color,lw=lw,ls=ls,solid_capstyle='round',zorder=2)
    def arrow(a,b,color=GRAY,lw=.8,ls='-',ms=5):
        ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=ms,color=color,lw=lw,linestyle=ls,shrinkA=0,shrinkB=0,zorder=3))
    def route(points,color=GRAY,lw=.75,ls='-',head=True):
        for a,b in zip(points[:-2],points[1:-1]):line(*a,*b,color,lw,ls)
        if head:arrow(points[-2],points[-1],color,lw,ls)
        else:line(*points[-2],*points[-1],color,lw,ls)
    def box(x,y,w,h,fill=WHITE,stroke=RULE,lw=.65):
        ax.add_patch(Rectangle((x,y),w,h,facecolor=fill,edgecolor=stroke,linewidth=lw,zorder=0))
    def cross(x,y,r=3,color=INK):
        line(x-r,y-r,x+r,y+r,color,1);line(x-r,y+r,x+r,y-r,color,1)
    def nav(x,y,w,h,kind='observed'):
        # Identical node coordinates and directed topology in all three views.
        pts=[(x+.05*w,y+.50*h),(x+.39*w,y+.08*h),(x+.78*w,y+.08*h),
             (x+.39*w,y+.92*h),(x+.78*w,y+.92*h),(x+.97*w,y+.50*h)]
        box(x+.29*w,y-.05*h,.55*w,.35*h,SOFT,'none')
        # Soft-cost route remains in support, with less qualitative target mass.
        for a,b in ((0,1),(1,2),(2,5),(0,3),(3,4),(4,5)):
            upper=a in (1,2) or b==1
            thick=(.85 if upper else 2.4) if kind=='target' else ((1.65 if upper else 1.1) if kind=='realized' else (2.4 if upper else 1.05))
            pa,pb=pts[a],pts[b];dx=pb[0]-pa[0];dy=pb[1]-pa[1];dist=math.hypot(dx,dy)
            st=(pa[0]+dx*3.1/dist,pa[1]+dy*3.1/dist);en=(pb[0]-dx*3.1/dist,pb[1]-dy*3.1/dist)
            arrow(st,en,BLUE,thick,ms=4)
        if kind!='target':
            pa,pb=pts[1],pts[4]
            line(*pa,*pb,GRAY,.6,'--')
            cross((pa[0]+pb[0])/2,(pa[1]+pb[1])/2,2.4)
        for j,(px,py) in enumerate(pts):
            ax.add_patch(Circle((px,py),2.8,facecolor=BLUE if j==5 else WHITE,edgecolor=BLUE,linewidth=.8,zorder=4))
        return pts

    # Five aligned stages; two colors carry meaning, neutral rules provide structure.
    columns=[(4,65,'Safety','requirements'),(77,69,'Visitation','allocation'),(155,90,'Constrained','projection'),(254,58,'Budget','prices'),(321,71,'Policy','learning')]
    for x,w,a,b in columns:
        text(a,x+2,11,9,True);text(b,x+2,22,9,True)
        line(x,32,x+w,32,BLUE if x in (155,254) else RULE,.95)
    text('Soft budgets',6,47,8.5,True,color=ORANGE)
    box(7,57,13,10,SOFT,ORANGE,.55)
    text('Costly visits',24,63,8)
    text(r'$b_k = B_k / L$',6,80,11.5)
    text('Total cost',6,95,8)
    line(5,105,65,105)
    text('Hard events',6,118,8.5,True)
    for x in (11,60):ax.add_patch(Circle((x,133),3,facecolor=WHITE,edgecolor=INK,linewidth=.7))
    line(15,133,28,133,INK,.8);line(43,133,56,133,INK,.8);cross(35,133,3.1)
    text('Zero capacity',6,149,8)
    text('Delete edges',6,161,8)
    text('Not priced',6,177,8,bold=True)

    nav(80,57,62,45)
    text('Width = mass',80,118,8)
    text('Reward directs',80,135,8)
    text('useful visits',80,146,8)
    text('Flow balance',80,163,8)
    text('links decisions',80,174,8)
    arrow((69,91),(75,91),BLUE);arrow((147,91),(153,91),BLUE)

    line(5,188,145,188,RULE,.5)
    ax.add_patch(Circle((11,201),2.8,facecolor=BLUE,edgecolor=BLUE,linewidth=.7))
    text('Rewarding goal',23,201,8)
    box(7,211,8,7,SOFT,ORANGE,.45)
    text('Soft-cost region',23,215,8)
    line(6,229,17,229,GRAY,.65,'--');cross(11.5,229,2.3)
    text('Forbidden transition',23,229,8)

    box(155,40,90,96,WASH,BLUE,.8)
    text('Reward + KL',162,53,9,True,color=BLUE)
    line(162,64,238,64)
    text('Flow balance',162,76,8)
    text('Soft total-cost',162,93,8)
    text('budgets',162,104,8)
    text('Hard support mask',162,122,8)
    text('Target flow q*',159,155,8.5,True,color=BLUE)
    arrow((200,137),(200,144),BLUE)
    nav(162,171,69,32,'target')

    arrow((246,51),(254,51),BLUE)
    text('Graph λ*',280,49,9,True,color=BLUE,ha='center')
    arrow((280,55),(280,61),BLUE)
    box(261,62,45,17,WASH,'none');text('Clip',283.5,70.5,8,ha='center')
    arrow((283.5,80),(283.5,84),BLUE)
    box(261,85,45,17,WASH,'none');text('Filter',283.5,93.5,8,ha='center')
    arrow((283.5,103),(283.5,108),BLUE)
    ax.add_patch(Circle((283.5,114),5,facecolor=WHITE,edgecolor=BLUE,linewidth=.7))
    text('+',283.5,114,10,ha='center',color=BLUE)
    arrow((283.5,120),(283.5,126),BLUE)
    text('Applied λ',283.5,133,8.5,True,ha='center',color=BLUE)
    arrow((309,133),(320,133),BLUE)

    box(321,118,71,30,WASH,BLUE,.7)
    text('Priced',356.5,128,8.5,True,color=BLUE,ha='center')
    text('advantage',356.5,139,8.5,True,color=BLUE,ha='center')
    arrow((356.5,149),(356.5,155),BLUE)
    box(321,156,71,19,WHITE,BLUE,.75)
    text('Actor update',356.5,165.5,8.5,True,ha='center')
    arrow((356.5,176),(356.5,183),BLUE)
    text('New rollouts',325,190,8.5,True)
    nav(328,202,57,28,'realized')
    text('PPO / TRPO',356,52,8,ha='center',color=GRAY)
    text('Prices enter',324,75,8)
    text('the advantage;',324,87,8)
    text('flow is a target.',324,99,8)

    box(254,179,58,44,SOFT,ORANGE,.7)
    text('Feedback β',283,188,8,True,ha='center')
    text('Actual costs',283,201,8,ha='center')
    text(r'$\bar J_k - B_k$',283,214,11.5,ha='center')
    route([(254,194),(250,194),(250,114),(278.5,114)],ORANGE,.85)
    arrow((325,216),(313,216),ORANGE,.85)
    route([(200,208),(200,238),(356,238),(356,233)],GRAY,.7,'--',False)
    text('Realization gap',276,238,8,ha='center',color=GRAY,bbox=dict(facecolor=WHITE,edgecolor='none',pad=1.5))

    line(4,250,392,250,RULE,.6)
    text('Priced advantage',7,264,8.5,True,color=BLUE)
    text(r'$(A_r-\sum_k\lambda_k A_{c,k})/(1+\sum_k\lambda_k)$',185,264,11.5,ha='center')
    text('→ actor',350,264,8.5,True,color=BLUE)

    box(4,278,388,40,'#F6F7F8','none')
    text('Same soft λ → replay objective',9,287,8)
    text('Hard cost → feasibility critic',9,301,8)
    arrow((132,293),(145,293),GRAY)
    text('Typed executor',199,287,8.5,True,ha='center')
    text('SAC + FDPI',199,300,8,ha='center')
    line(255,283,255,308,RULE)
    arrow((258,293),(272,293),GRAY)
    text('Candidate selector',331,287,8.5,True,ha='center')
    text('Optional; learned',331,300,8,ha='center')
    text('Exact graph mask ≠ learned execution; no zero-contact certificate.',9,314,8,color=GRAY)

    text('Conditional price limits',6,330,8.5,True)
    text('ε → 0: LP dual price.',98,330,8)
    text('ε → ∞: scaled information-projection price.',6,342,8)
    text('Clip → saturated active-set price. A realized-cost switch additionally needs',6,353,8)
    text('matching active sets, equal saturation and matching filter/feedback states.',6,364,8)
    return fig,ax

if __name__=='__main__':
    fig,ax=main()
    save_anonymous(fig,HERE/'F1.pdf');save_anonymous(fig,HERE/'F1.svg')
    fig.savefig(HERE/'F1.png',dpi=240,metadata={'Software':None})
    # Preserve editable text and path objects; PDF image count must remain zero.
    with fitz.open(HERE/'F1.pdf') as doc:
        p=doc[0]
        spans=[s for b in p.get_text('dict')['blocks'] if 'lines'in b for l in b['lines'] for s in l['spans']]
        report={'width_pt':p.rect.width,'height_pt':p.rect.height,'raster_images':len(p.get_images()),'font_sizes':sorted(set(round(s['size'],3) for s in spans)),'fonts':[],'metadata':doc.metadata}
        for row in p.get_fonts(full=True):
            report['fonts'].append({'name':row[3],'type':row[2],'embedded_bytes':len(doc.extract_font(row[0])[3])})
        (HERE/'F1.verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report))
