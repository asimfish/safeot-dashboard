# F1 — safety as visitation allocation

`F1.pdf` is a native vector candidate for the method figure. `F1.svg` retains editable text and paths; `build_f1.py` is the reproducible source. No bitmap is embedded in either publication file. `F1.png` is a viewing preview only. `F1_grayscale.png` and `F1_final_width_72dpi.png` are inspection previews. Keep the adjacent `style/` directory two levels above this directory when rebuilding.

```bash
python build_f1.py
python verify_f1.py
```

The candidate is **5.5 × 5.181 inches**, using the full ICLR text width. All extracted PDF text, including mathematical subscripts, is at least 8 pt; prose is 8–9 pt. Fonts are embedded. PDF information/XMP and SVG metadata are empty. Text is inside the canvas and no pair of text objects overlaps. `F1.acceptance.json` records dimensions and file hashes. This complete five-stage schematic is relatively tall; it needs deliberate space in the nine-page main text. Do not shrink it below its native width: that would reduce the smallest text below 8 pt. Page-count admission is a manuscript-layout check, not established by this standalone export.

The main chain is requirements → visitation → projection → graph prices → learning. Soft budgets constrain total weighted cost; hard transitions are deleted without a finite price. Target flow and graph prices are separate projection outputs. Applied prices enter the normalized advantage; actual rollout episode costs drive feedback. The target–realized-flow link is dashed and has no policy-extraction arrow. The learned typed executor and optional candidate selector are separate from exact support removal.

`caption_short.tex` is a concise placement caption; `caption.tex` is the detailed semantic specification. Both state the conditional limits, including the unscaled-price condition for an off state. The large-epsilon statement concerns scaled prices and accumulation points under the assumptions of the price-properties proposition. Neither file claims recovery of an external policy algorithm or certified policy safety.

The native navigation graphs use the same node geometry and qualitative topology. Their widths illustrate mass, not measurements; no numerical results, intervals or safety rates are invented. All final manuscript replacement and evidence admission remain with the manuscript owner. The existing manuscript figure was not replaced.
