"""Check native geometry, embedded fonts, editable SVG and text collision bounds."""
from pathlib import Path
import json,xml.etree.ElementTree as ET,hashlib
import fitz
import matplotlib
matplotlib.use('Agg')
import build_f1
HERE=Path(__file__).resolve().parent

def main():
    fig,ax=build_f1.main();fig.canvas.draw();r=fig.canvas.get_renderer();page=fig.bbox
    bounds=[];overlaps=[]
    for t in build_f1.FONTS:
        if not t.get_visible() or not t.get_text().strip():continue
        b=t.get_window_extent(r)
        assert b.x0>=page.x0-.1 and b.y0>=page.y0-.1 and b.x1<=page.x1+.1 and b.y1<=page.y1+.1, (t.get_text(),list(b.bounds))
        bounds.append((t.get_text(),b))
    for i,(ta,a) in enumerate(bounds):
        for tb,b in bounds[i+1:]:
            intersection=(min(a.x1,b.x1)-max(a.x0,b.x0),min(a.y1,b.y1)-max(a.y0,b.y0))
            if min(intersection)>.3:overlaps.append([ta,tb])
    assert not overlaps, overlaps
    svg=ET.parse(HERE/'F1.svg').getroot()
    tags=[x.tag.split('}')[-1] for x in svg.iter()]
    assert 'metadata' not in tags and 'image' not in tags
    assert tags.count('text')>=40
    with fitz.open(HERE/'F1.pdf') as d:
        p=d[0];spans=[s for b in p.get_text('dict')['blocks'] if 'lines'in b for l in b['lines'] for s in l['spans']]
        assert not p.get_images();assert len(p.get_drawings())>50
        assert min(s['size'] for s in spans)>=7.99
        assert p.rect.width==396 and p.rect.height==build_f1.H
        assert not any(v for k,v in d.metadata.items() if k not in ('format','encryption'))
        assert not d.get_xml_metadata()
        for row in p.get_fonts(full=True):assert d.extract_font(row[0])[3]
        text=p.get_text()
        for required in ('Soft budgets','Hard events','Not priced','Graph','Target flow','Actual costs','Realization gap','Priced advantage','Actor update','Typed executor','Candidate selector','Conditional price limits','matching active sets'):
            assert required in text,required
        report={'status':'PASS','width_in':p.rect.width/72,'height_in':p.rect.height/72,'minimum_extracted_font_pt':min(s['size'] for s in spans),'native_paths':len(p.get_drawings()),'raster_images':0,'editable_svg_text_elements':tags.count('text'),'text_overlap_pairs':overlaps,'text_in_canvas':True,'metadata_empty':True,'pdf_font_embedding_verified':True,'file_sha256':{n:hashlib.sha256((HERE/n).read_bytes()).hexdigest() for n in ('F1.pdf','F1.svg','build_f1.py','caption.tex','caption_short.tex')}}
        p.get_pixmap(matrix=fitz.Matrix(1,1)).save(str(HERE/'F1_final_width_72dpi.png'))
        p.get_pixmap(matrix=fitz.Matrix(2,2),colorspace=fitz.csGRAY).save(str(HERE/'F1_grayscale.png'))
    (HERE/'F1.acceptance.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report))
if __name__=='__main__':main()
