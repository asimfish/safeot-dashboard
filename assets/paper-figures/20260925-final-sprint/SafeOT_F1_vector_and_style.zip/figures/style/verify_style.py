"""Render method-identity swatches; verify anonymous export, fonts and geometry."""
from pathlib import Path
import json, hashlib
import fitz
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from safeot_style import *

def numeric_state(fig):
    # This fingerprint ignores appearance and covers line/collection point geometry.
    arrays=[]
    for ax in fig.axes:
        for line in ax.lines:
            arrays.extend([np.asarray(line.get_xdata(),float).tolist(),np.asarray(line.get_ydata(),float).tolist()])
        for collection in ax.collections:
            arrays.append(np.asarray(collection.get_offsets(),float).tolist())
            arrays.extend([p.vertices.tolist() for p in collection.get_paths()])
    return hashlib.sha256(json.dumps(arrays,sort_keys=True).encode()).hexdigest()

def main():
    apply_style(); report=[]; out=HERE/'proofs';out.mkdir(exist_ok=True)
    for width in ('single','iclr'):
        for gray in (False,True):
            fig=plt.figure(figsize=figure_size(width,2.45));ax=fig.add_axes([0,0,1,1]);ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off')
            ax.text(.055,.94,'Method identity / '+('grayscale' if gray else 'color'),weight='bold',fontsize=9)
            ax.text(.055,.87,'Appearance swatches; no experimental data.',fontsize=8)
            for j,name in enumerate(COLORS):
                y=.77-j*.088
                ax.plot([.06,.145,.23],[y]*3,**method_style(name,grayscale=gray))
                ax.text(.29,y,name,va='center',fontsize=8)
                ax.text(.70,y,COLORS[name],va='center',fontsize=8)
            before=numeric_state(fig)
            stem=out/f'palette_{width}_{"gray" if gray else "color"}'
            for suffix in ('.pdf','.svg'):save_anonymous(fig,stem.with_suffix(suffix))
            assert numeric_state(fig)==before
            with fitz.open(stem.with_suffix('.pdf')) as d:
                assert abs(d[0].rect.width-WIDTHS[width]*72)<.01
                assert not d[0].get_images()
                assert not any(v for k,v in d.metadata.items() if k not in ('format','encryption'))
                spans=[s for b in d[0].get_text('dict')['blocks'] if 'lines'in b for l in b['lines'] for s in l['spans']]
                assert min(s['size'] for s in spans)>=7.99
                fonts=[]
                for row in d[0].get_fonts(full=True):
                    data=d.extract_font(row[0]);assert data[3], row
                    fonts.append({'name':row[3],'embedded_bytes':len(data[3])})
                d[0].get_pixmap(matrix=fitz.Matrix(2,2)).save(str(stem.with_suffix('.png')))
                report.append({'artifact':stem.name,'width_in':WIDTHS[width],'min_font_pt':min(s['size'] for s in spans),'embedded_fonts':fonts,'native_vector':True,'metadata_empty':True,'line_and_collection_geometry_unchanged':True})
            plt.close(fig)
    (out/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'status':'PASS','proofs':len(report)}))
if __name__=='__main__':main()
