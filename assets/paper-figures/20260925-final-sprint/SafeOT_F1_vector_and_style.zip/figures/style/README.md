# Shared SafeOT figure style

`safeot.mplstyle` sets 8 pt labels/ticks/legends, 9 pt panel titles, a Times-compatible serif face, embedded TrueType PDF fonts and editable SVG text. `palette.json` / `palette.csv` define fixed method colors, markers and line patterns. SafeOT-Dual is #0072B2; switch is #56B4E9. Other method identities retain their existing colors. Use color plus line pattern/marker; the light switch color alone is insufficient on white or in grayscale. Outlined markers make it legible.

```python
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'style'))
from safeot_style import apply_style, figure_size, method_style, save_anonymous
apply_style()
fig, ax = plt.subplots(figsize=figure_size('iclr', 2.4))
ax.plot(steps, values, **method_style('SafeOT-Dual'))
save_anonymous(fig, 'figure.pdf')
```

Widths (inches): `single=3.6` preserves the current standalone data-panel size; `half=2.65` supports two panels in the ICLR text area; `iclr=double=5.5` is the full ICLR text width. ICLR uses a single text column; `double` is a convenience alias, not a two-column template. Rebuild at the intended printed width; never shrink an 8 pt source into a smaller placement. A 3.6 in source placed at 2.65 in produces only 5.89 pt text. Export helper preserves explicit dimensions and performs no automatic tight crop. The accompanying integration patch retains W2's existing tight-crop call; audit its resulting size before placement or explicitly choose a fixed canvas in the producer script.

`w2_plot_common_style_only.patch` is a proposed owner/W2 integration; original numerical scripts were not edited. It changes style imports and PDF export only. It leaves all cohort selection, point identities, numerical helpers, bootstrap seeds, intervals and pairing untouched. Individual scripts should use `method_style()` or the explicit `LINESTYLES` map when drawing lines. Where markers already encode cap, clip, selector or evaluation mode, preserve that mapping and explain it in the legend. Do not replace protocol markers with method markers blindly.

`verify_style.py` renders color and grayscale identity swatches at both 3.6 and 5.5 in. They are style samples, not experiment plots. It verifies empty metadata, exact width, embedded fonts, 8 pt minimum ordinary text, native vector content and unchanged line/collection coordinates during export. Run `python verify_style.py` from any directory. Output is in `proofs/`.

`anonymize.py` clears document metadata on PDF copies and removes SVG metadata elements. `save_anonymous()` applies this automatically. Identifying text, hyperlinks, personal paths in source manifests, image content and later manuscript metadata still need a separate final-bundle audit. Keep internal provenance records separate from the anonymous submission bundle.

Dependencies: Python, Matplotlib, NumPy, PyMuPDF; Liberation Serif (fallback Times New Roman or DejaVu Serif). No data transformation is implemented in this style package.
