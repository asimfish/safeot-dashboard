# Section 5 figure layout handoff

The main-paper numbering follows the Section 5 skeleton. Legacy producer filenames are mapped in `figure_registry.json`; do not rename old F2/F3/F4 files into the new slots without checking their content.

| Figure | Native size | Arrangement | Legend |
|---|---|---|---|
| 2 | 5.50 × 4.50 in | Paired forests above two task columns, each with cost above return | Suite marker key above forests; shared four-method key above curves |
| 3 | 2.65 × 3.90 in | Realization scatter above horizontal deployment violins | Family labels above violins; method names on rows |
| 4 | 2.65 × 3.90 in | Mechanism boundary, unchanged estimates and intervals | Outside plotting area, above axes |

Place Figures 3 and 4 alongside each other on the 5.5-inch text width. Dimensions include axes labels and legends, but exclude captions. Do not scale below the native dimensions: ordinary plot text is 8 pt, task titles 8.5 pt and panel titles 9 pt. A denser dataset requires a reviewed taller layout, not smaller type. `placement.tex` is an owner integration snippet; its filenames and caption macros must be connected to admitted assets.

## Reproducible appearance

Import `style/section5_layout.py` for axes geometry and `style/section5_methods.json` for method identities. Both read the shared `safeot.mplstyle` and `palette.json`.

- SafeOT-Dual: blue `#0072B2`; switch: light blue `#56B4E9`.
- Lagrangian family: green; PID family: vermilion; CPO/PCPO: dark gray; other comparators: gray. Preserve the canonical marker/line differences within families.
- Forest colors identify comparators. Circle/diamond identify evaluation suites, so row labels retain method identity in grayscale. Reference lines are neutral.
- Curves use both line style and markers; confidence bands use the method hue with low opacity. Retain every producer interval and missing observation.
- Realization scatter is a single-method diagnostic: use SafeOT blue, with task/family distinctions only if required by the caption. Do not introduce a task rainbow.
- Deployment split violins use method hue and distinguish navigation/velocity by labeled halves and outline treatment. Preserve the producer's sample membership, density coordinates, bandwidth, transform, tails and missing methods. Reorienting existing density coordinates is a layout change; silently replacing the estimator is not.
- The regime map must retain study/setting identities and their original uncertainty. Do not join unrelated settings into a causal trend. Conditional endpoint statements remain conditional.

All production plots must preserve the same policy/checkpoint pairing, numerical points, confidence intervals, scales, limits and source hashes. New analysis, statistics or scientific selection belongs to the producer and owner. Plot files must be vector PDF/SVG with embedded PDF fonts, no identifying metadata, and no internal dashboard links.

## Current deliveries

`CURRENT.json` identifies the current *style-reviewed candidate*, not automatic manuscript admission. The F2 delivery retains producer caveats, unmeasured comparisons and existing smoothing. Its `verification.json` records an exact reproduction of the producer's original rasterization before reflow and exact before/after numeric-artist equality.

`F2_layout_only.*`, `F3_layout_only.*` and `F4_layout_only.*` are empty layout proofs. **They are not empirical figures and must not enter the manuscript.** F3 requires both producer components; the available standalone scatter alone does not complete Figure 3.

For new exports set `section5_figure` to `F2`, `F3` or `F4` in the source manifest (top level or `cohort_seed_counts`). Keep legacy IDs for appendix outputs. The producer may import the geometry helpers directly, which avoids shrinking existing full-width plots into unreadable half-width figures.
