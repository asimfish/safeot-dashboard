"""Empty panel maps for layout review, with no invented measurements or curves."""
from pathlib import Path
import sys,json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from matplotlib.lines import Line2D
from matplotlib.text import Text
import fitz
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parents[1]/'style'))
from section5_layout import make_f2,make_f3,make_f4,f2_curve_legend,f4_legend,method_identity
from safeot_style import save_anonymous


def main():
    report=[]
    specs=[('F2',make_f2(['TRPO-Lag','PPO-Lag','CPO','PCPO','FOCOPS','CUP','PID-Lag','switch','Comparator 9','Comparator 10'])),('F3',make_f3()),('F4',make_f4())]
    notes={'a':'Producer points + unchanged CI','b':'Producer values + unchanged CI','c_pg1_cost':'Cost + budget','c_hopper_cost':'Cost + budget','c_pg1_reward':'Return + CI','c_hopper_reward':'Return + CI','main':'Ratios + unchanged CIs'}
    for name,(fig,axes) in specs:
        for key,ax in axes.items():
            ax.set_facecolor('#F3F6F8');ax.set_xticks([])
            if name!='F2' or key not in ('a','b'):ax.set_yticks([])
            ax.text(.5,.5,'No data\nLayout proof',ha='center',va='center',transform=ax.transAxes,fontsize=8,color='#64727A')
        if name=='F2':
            methods=['SafeOT-Dual','TRPO-Lag','CPO','PID-Lag']
            handles=[Line2D([],[],**method_identity(n),markersize=3) for n in methods]
            f2_curve_legend(fig,handles,methods)
        if name=='F3':
            axes['b'].set_yticks(range(8),['SafeOT-Dual','TRPO-Lag','PPO-Lag','CPO','PCPO','FOCOPS','CUP','PID-Lag']);axes['b'].set_ylim(7.5,-.5)
            fig.text(.95,150/280.8,'Nav. / Vel.',ha='right',fontsize=8,color='#64727A',va='center')
        if name=='F4':
            handles=[Line2D([],[],**method_identity(n),markersize=3) for n in ['switch','PID-Lag','TRPO-Lag']]
            f4_legend(fig,handles,['switch','PID','Lag'])
            axes['main'].set_xticks(range(6),['Exact','Bridge','K4','K8','Clip 1','SafePO'],rotation=55,ha='right');axes['main'].set_xlim(-.5,5.5)
        save_anonymous(fig,HERE/f'{name}_layout_only.pdf');save_anonymous(fig,HERE/f'{name}_layout_only.svg')
        fig.savefig(HERE/f'{name}_layout_only.png',dpi=180,metadata={'Software':None})
        fig.canvas.draw();ren=fig.canvas.get_renderer();box=fig.bbox
        outside=[]
        for t in fig.findobj(match=Text):
            if not t.get_visible() or not t.get_text().strip():continue
            b=t.get_window_extent(ren)
            if b.x0<box.x0-.1 or b.y0<box.y0-.1 or b.x1>box.x1+.1 or b.y1>box.y1+.1:outside.append(t.get_text())
        assert not outside,(name,outside)
        with fitz.open(HERE/f'{name}_layout_only.pdf') as doc:
            p=doc[0];spans=[s for b in p.get_text('dict')['blocks'] if 'lines'in b for l in b['lines'] for s in l['spans']]
            assert min(s['size'] for s in spans)>=7.99
            assert not p.get_images()
            assert not any(v for k,v in doc.metadata.items() if k not in ('format','encryption'))
            for f in p.get_fonts(full=True):assert doc.extract_font(f[0])[3]
            report.append({'figure':name,'layout_only':True,'dimensions_in':[p.rect.width/72,p.rect.height/72],'min_font_pt':min(s['size'] for s in spans),'out_of_canvas_text':outside,'metadata_empty':True,'embedded_fonts':True,'raster_images':0})
        plt.close(fig)
    (HERE/'layout_proof_verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report))
if __name__=='__main__':main()
