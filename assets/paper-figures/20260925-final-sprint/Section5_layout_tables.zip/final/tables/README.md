# Compact ICLR table templates

Table 1 is a six-column evaluation-suite table. Table 2 uses a method column and three task columns, with two lines per task cell: reward and its reported interval; contact percentage and its reported interval or upper bound, followed by hazard cost. No empirical values are supplied by these templates.

## Integration

Load `booktabs`, `array` and `tabularx` in the preamble, then `\input{table_style}`. Populate a separate values file with `\SafeOTDeclare{key}{value}` entries listed in `required_keys.json`. Load that values file before `\input{table1_suite}` and `\input{table2_typed}`. `table_values.example.tex` contains syntax examples only.

For a typed task cell, use `\SafeOTTypedCell{reward}{reported reward interval}{contact percentage}{reported contact interval or upper bound}{hazard cost}`. Preserve asymmetric endpoints and one-sided bounds exactly; do not synthesize a missing endpoint or convert them to a symmetric ± value. If the original strings need more room, use `\SafeOTTypedCellTall` for a three-line cell at the same font size.

The required `typed/notes` value must disclose the exact task settings, contact denominator and uncertainty unit, selector/checkpoint protocol, and any unmeasured cells. Reward and costs must refer to the same policy, checkpoint and evaluation episodes. The owner determines which completed results are admissible. The current uniform-setting requirement must be expressed explicitly; historical mixed task settings are not an implicit default.

Production mode rejects missing values with a LaTeX error. Do not enable `\SafeOTTableProoftrue` in the manuscript. Deliberate unavailable cells must be declared with a truthful label and explained in the notes.

## Typesetting and checks

- Table body: 8.1 TeX pt, 9.4 pt leading. Captions inherit the ICLR template.
- No page-geometry changes, negative spacing or whole-table scaling.
- The supplied placeholder preview fits both tables on one page under the project's unmodified ICLR style, with no overfull boxes. Actual populated tables must be checked again; this does not establish whole-manuscript page compliance.
- PDF uses bp (72/in); TeX pt is 72.27/in. The verifier converts these units, including the template's native 8 pt margin labels.

Run:

```sh
python3 build_preview.py --iclr-template PATH/TO/iclr2027_conference.sty \
  --work-dir PATH/TO/ISOLATED_BUILD --data PATH/TO/filled_values.tex \
  --output PATH/TO/verified_tables.pdf
```

Without `--data`, the script produces an explicitly labeled layout proof. It uses system pdfLaTeX without shell escape, checks font embedding and overflow, and clears PDF metadata. Reuse the original conference style file unchanged.
