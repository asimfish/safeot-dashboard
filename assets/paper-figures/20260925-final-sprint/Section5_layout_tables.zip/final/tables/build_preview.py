"""Compile table layout with the project's ICLR style, then anonymize the PDF."""
from pathlib import Path
import argparse,os,subprocess,sys,json,re,tempfile
import fitz
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parents[1]/'style'))
from anonymize import clean_pdf

def main():
    p=argparse.ArgumentParser();p.add_argument('--iclr-template',type=Path,required=True);p.add_argument('--work-dir',type=Path,required=True);p.add_argument('--data',type=Path);p.add_argument('--output',type=Path,default=HERE/'tables_layout_proof.pdf');a=p.parse_args()
    work=a.work_dir.resolve();work.mkdir(parents=True,exist_ok=True)
    if a.data:
        source=(HERE/'preview.tex').read_text().replace('\\SafeOTTableProoftrue',r'\input{'+a.data.resolve().as_posix()+'}').replace('Table layout proof','Table typesetting verification').replace('This page checks the template only. Dashes and interval labels are placeholders, not empirical results. Production builds reject missing values.','')
    else:source=(HERE/'preview.tex').read_text()
    (work/'preview.tex').write_text(source)
    env=os.environ.copy();env['PATH']='/usr/bin:'+env.get('PATH','');env['TEXINPUTS']=str(work)+os.pathsep+str(HERE)+os.pathsep+str(a.iclr_template.resolve().parent)+os.pathsep+env.get('TEXINPUTS','')
    runs=[]
    for _ in range(2):
        r=subprocess.run(['/usr/bin/pdflatex','-no-shell-escape','-interaction=nonstopmode','-halt-on-error',str(work/'preview.tex')],cwd=work,env=env,text=True,capture_output=True,timeout=90)
        runs.append(r.returncode)
        if r.returncode:print(r.stdout[-5000:]);raise SystemExit(r.returncode)
    log=(work/'preview.log').read_text(errors='replace')
    problems=[l for l in log.splitlines() if re.search(r'Overfull \\[hv]box|Undefined control sequence|LaTeX Error',l)]
    assert not problems,problems
    clean_pdf(work/'preview.pdf',a.output)
    with fitz.open(a.output) as d:
        fonts=[];sizes=[]
        for i,page in enumerate(d):
            spans=[s for b in page.get_text('dict')['blocks'] if 'lines'in b for l in b['lines'] for s in l['spans']]
            sizes.extend(s['size'] for s in spans if s['text'].strip())
            for f in page.get_fonts(full=True):
                data=d.extract_font(f[0]);assert data[3];fonts.append(f[3])
            page.get_pixmap(matrix=fitz.Matrix(1.5,1.5)).save(str(a.output.with_name(a.output.stem+f'_p{i+1}.png')))
        assert min(sizes)*72.27/72>=7.999,min(sizes)
        report={'status':'PASS','mode':'verified values' if a.data else 'layout proof only; no empirical values','pages':len(d),'minimum_pdf_font_bp':min(sizes),'minimum_font_TeX_pt':min(sizes)*72.27/72,'table_body_TeX_pt':8.1,'embedded_fonts':sorted(set(fonts)),'overfull_boxes':problems,'metadata_empty':not any(v for k,v in d.metadata.items() if k not in ('format','encryption')),'page_geometry':'unmodified project ICLR style; full-width tables','compiler_runs':runs}
    a.output.with_suffix('.verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
if __name__=='__main__':main()
