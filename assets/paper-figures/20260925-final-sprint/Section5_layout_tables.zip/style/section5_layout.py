"""Section 5 axes geometry only. Producer supplies all data, CIs and identities."""
from pathlib import Path
import json
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
from safeot_style import apply_style,method_style
HERE=Path(__file__).resolve().parent

def method_identity(name):
    spec=json.loads((HERE/'section5_methods.json').read_text())['methods'][name]
    style=method_style(spec['palette_key'])
    style.update(marker=spec['marker'],linestyle=spec['linestyle'])
    return style

def _fig(w,h):
    apply_style();return plt.figure(figsize=(w,h))

def _axis(fig,rect):
    w,h=fig.get_size_inches()*72
    ax=fig.add_axes([rect[0]/w,rect[1]/h,rect[2]/w,rect[3]/h])
    ax.xaxis.set_major_locator(MaxNLocator(3));ax.yaxis.set_major_locator(MaxNLocator(3))
    return ax

def _label(fig,text,x,y):
    w,h=fig.get_size_inches()*72
    return fig.text(x/w,y/h,text,fontsize=9,weight='bold',va='center')

def make_f2(comparators=None):
    """5.5 x 4.5 in: paired forests above a 2-task x 2-metric curve grid.

    Pass the producer's fixed comparator order; this function never sorts by
    measured outcome. Values, limits, scales and statistical estimators belong
    to the producer. Same ordered rows must be used in both forests.
    """
    if comparators is not None and len(comparators)>10:
        raise ValueError('More than ten rows needs an explicitly reviewed taller layout.')
    fig=_fig(5.5,4.5)
    axes={'a':_axis(fig,(76,192,115,111)), 'b':_axis(fig,(253,192,133,111)),
          'c_pg1_cost':_axis(fig,(43,91,145,42)), 'c_hopper_cost':_axis(fig,(241,91,145,42)),
          'c_pg1_reward':_axis(fig,(43,28,145,42)), 'c_hopper_reward':_axis(fig,(241,28,145,42))}
    _label(fig,'(a) Learning-time violation',4,314)
    _label(fig,'(b) Final return',214,314)
    _label(fig,'(c) Learning curves',4,160)
    for title,x in [('PointGoal1',115.5),('Hopper',313.5)]:
        fig.text(x/396,143/324,title,ha='center',fontsize=8.5,weight='bold')
    if comparators is not None:
        for key in ('a','b'):
            axes[key].set_yticks(range(len(comparators)),comparators if key=='a' else ['']*len(comparators))
            axes[key].set_ylim(len(comparators)-.5,-.5)
    axes['a'].set_xlabel('V ratio (ours / comparator)')
    axes['b'].set_xlabel('Normalized return difference')
    for task in ('pg1','hopper'):
        axes[f'c_{task}_cost'].set_ylabel('Cost')
        axes[f'c_{task}_cost'].tick_params(axis='x',labelbottom=False)
        axes[f'c_{task}_reward'].set_ylabel('Return')
        axes[f'c_{task}_reward'].set_xlabel('Steps (M)')
    return fig,axes

def f2_curve_legend(fig,handles,labels):
    """One shared four-method curve legend; budget reference explained in caption."""
    if len(handles)>4:raise ValueError('Main curves specify four methods; keep others in appendix.')
    return fig.legend(handles,labels,loc='center right',bbox_to_anchor=(.988,160/324),
                      ncol=4,fontsize=8,handlelength=1.6,columnspacing=.7,handletextpad=.4)

def make_f3():
    """2.65 x 3.9 in. Two stacked panels; horizontal split violins in panel b."""
    fig=_fig(2.65,3.9)
    axes={'a':_axis(fig,(43,186,139,76)), 'b':_axis(fig,(63,30,119,108))}
    _label(fig,'(a) Target to policy',4,274)
    _label(fig,'(b) Deployed cost',4,150)
    axes['a'].set_xlabel('Target cost / B');axes['a'].set_ylabel('Next-policy cost / B')
    axes['b'].set_xlabel('Final cost / B')
    return fig,axes

def make_f4():
    """2.65 x 3.9 in. Regime points/CIs only; no cross-study connecting curve."""
    fig=_fig(2.65,3.9)
    axes={'main':_axis(fig,(39,72,143,173))}
    _label(fig,'Mechanism boundary',4,274)
    axes['main'].set_ylabel('V ratio (solve / rule)')
    return fig,axes

def f4_legend(fig,handles,labels):
    return fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.56,.948),
                      ncol=3,fontsize=8,handlelength=1.2,columnspacing=.6,handletextpad=.35)
