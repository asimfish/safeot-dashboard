"""Deterministic figure appearance and anonymous export; no numerical processing."""
from pathlib import Path
import json
import tempfile
import matplotlib.pyplot as plt
from anonymize import clean_pdf, clean_svg, PDF_METADATA, SVG_METADATA

HERE = Path(__file__).resolve().parent
PALETTE = json.loads((HERE / 'palette.json').read_text())
COLORS = {name: v['color'] for name, v in PALETTE['methods'].items()}
MARKERS = {name: v['marker'] for name, v in PALETTE['methods'].items()}
LINESTYLES = {name: v['linestyle'] for name, v in PALETTE['methods'].items()}
WIDTHS = {'single': 3.6, 'half': 2.65, 'iclr': 5.5, 'double': 5.5}


def apply_style():
    plt.style.use(HERE / 'safeot.mplstyle')


def figure_size(width='iclr', height=2.4):
    """Inches. 'double' means the full 5.5 in ICLR text width, not 7 in."""
    return (WIDTHS[width] if isinstance(width, str) else float(width), float(height))


def method_style(method, *, grayscale=False, filled=True):
    """Use explicit method identity; never depend on plotting order.

    For a selector/cap/clip comparison whose markers encode protocol, keep that
    marker mapping explicit and use this color/linestyle. Do not overwrite it.
    """
    spec = PALETTE['methods'][method]
    color = spec['gray'] if grayscale else spec['color']
    return dict(color=color, marker=spec['marker'], linestyle=spec['linestyle'],
                markeredgecolor='#333333', markeredgewidth=0.65,
                markerfacecolor=color if filled else 'white')


def save_anonymous(fig, path, **kwargs):
    """Strip document metadata and retain caller's geometry/data unchanged.

    No implicit tight crop or rescaling. Pass bbox_inches only deliberately;
    inspect resulting PDF width and effective font sizes after LaTeX placement.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    suffix = path.suffix.lower()
    if suffix not in ('.pdf', '.svg'):
        raise ValueError('Publication export must be PDF or SVG.')
    kwargs = dict(kwargs)
    kwargs.pop('metadata', None)
    with tempfile.TemporaryDirectory(prefix='anonymous-figure-') as td:
        raw = Path(td) / ('figure' + suffix)
        fig.savefig(raw, metadata=PDF_METADATA if suffix == '.pdf' else SVG_METADATA, **kwargs)
        (clean_pdf if suffix == '.pdf' else clean_svg)(raw, path)
    return path
