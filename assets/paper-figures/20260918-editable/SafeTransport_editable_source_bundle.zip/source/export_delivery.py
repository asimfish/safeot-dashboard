"""Export the validated editable figures; inspect actual PDF, not synthetic previews."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import zipfile
import xml.etree.ElementTree as ET
import fitz
from pptx import Presentation

HERE = Path(__file__).resolve().parent
RUN = HERE / 'run'
OUT = HERE / 'delivery'
SOURCE = HERE.parent / 'unified-algorithm-revision'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    assert json.loads((RUN / 'final/validation.json').read_text())['passed']
    OUT.mkdir(exist_ok=True)
    deck = OUT / 'SafeTransport_Fig1_Fig2_editable.pptx'
    shutil.copyfile(RUN / 'final/Figure1_unified_v01_edited.pptx', deck)
    original_names = ['Figure1_unified_v01.png', 'Figure2_framework_v03.png']
    summaries = []
    ns = {'p': 'http://schemas.openxmlformats.org/presentationml/2006/main',
          'a': 'http://schemas.openxmlformats.org/drawingml/2006/main'}
    prs = Presentation(deck)
    assert len(prs.slides) == 2
    with zipfile.ZipFile(deck) as z:
        assert z.testzip() is None
        assert not any(name.startswith('ppt/media/') and name.endswith(('.png', '.jpg', '.jpeg')) for name in z.namelist()), 'Unexpected bitmap in native reconstruction'
        for index, slide in enumerate(prs.slides, 1):
            page_dir = RUN / f'pages/page_{index:03}'
            manifest = json.loads((page_dir / 'manifest.json').read_text())
            assert json.loads((page_dir / 'validation.json').read_text())['passed']
            shutil.copyfile(page_dir / 'page.pptx', OUT / f'Figure{index}_editable.pptx')
            assert sha(SOURCE / original_names[index - 1]) == sha(RUN / 'input' / original_names[index - 1])
            xml = ET.fromstring(z.read(f'ppt/slides/slide{index}.xml'))
            text = [node.text or '' for node in xml.findall('.//a:t', ns)]
            assert any(('SafeTransport' if index == 1 else 'PPO') in t for t in text)
            fonts = [run.font.size.pt for s in slide.shapes if s.has_text_frame
                     for p in s.text_frame.paragraphs for run in p.runs if run.font.size]
            scale = 396 / (prs.slide_width / 12700)
            summaries.append({'figure': index,
                'native_text_objects': sum(s.has_text_frame and bool(s.text.strip()) for s in slide.shapes),
                'native_structural_shapes': len(manifest['shapes']),
                'formula_svg_instances': len(manifest['images']),
                'native_text_size_at_396pt': sorted({round(size * scale, 2) for size in fonts}),
                'native_fonts': sorted({run.font.name for s in slide.shapes if s.has_text_frame
                                       for p in s.text_frame.paragraphs for run in p.runs if run.font.name}),
                'source_sha256': sha(SOURCE / original_names[index - 1])})

    profile = HERE / 'export-profile'
    process = subprocess.run(['libreoffice', f'-env:UserInstallation={profile.as_uri()}',
                              '--headless', '--convert-to', 'pdf', '--outdir', str(OUT), str(deck)],
                             capture_output=True, text=True, timeout=90)
    (HERE / 'export.log').write_text(process.stdout + process.stderr)
    assert process.returncode == 0, process.stderr
    pdf = OUT / 'SafeTransport_Fig1_Fig2_editable.pdf'
    with fitz.open(pdf) as document:
        assert len(document) == 2
        print_pages = fitz.open()
        for index, page in enumerate(document, 1):
            assert not page.get_images(), 'Raster image found in expected vector PDF'
            scale = 1860 / page.rect.width
            page.get_pixmap(matrix=fitz.Matrix(scale, scale), alpha=False).save(OUT / f'Figure{index}_editable_preview.png')
            (OUT / f'Figure{index}_editable.svg').write_text(page.get_svg_image(text_as_path=True))
            with fitz.open() as one:
                one.insert_pdf(document, from_page=index-1, to_page=index-1)
                one.save(OUT / f'Figure{index}_editable.pdf')
            # QA sheet with an exact 396pt-wide figure; preserves the normal page template.
            check = print_pages.new_page(width=612, height=792)
            check.insert_text((108, 68), f'Figure {index}: 396 pt / 5.5 in paper-width check', fontsize=10)
            fig_height = 396 * page.rect.height / page.rect.width
            check.show_pdf_page(fitz.Rect(108, 92, 504, 92 + fig_height), document, index-1)
            note = 'Faithful editable reconstruction. Small labels remain below the internal 7 pt readability target. This is a typography inspection sheet, not an ICLR compliance certificate.'
            check.insert_textbox(fitz.Rect(108, 110 + fig_height, 504, 220 + fig_height), note, fontsize=10, lineheight=1.4)
            summaries[index-1]['vector_pdf_raster_images'] = 0
        print_pages.save(OUT / 'Paper_width_check_396pt.pdf')
        print_pages.close()
    (OUT / 'README.md').write_text('''# SafeTransport editable figures

The combined PPTX has two slides; individual Figure1/2 PPTX files are also provided. Text, graph nodes, edges, capacity matrix cells, boxes and lines are native editable objects. Mathematical expressions are separate SVG objects with retained LaTeX under source/pages; they are not native Office equations.

The PDF, SVG and PNG previews were exported from the actual combined PPTX with LibreOffice. The PDF is vector content with no raster image objects. Original generated PNGs are preserved separately on the dashboard.

## Print-size limitation

The conversion keeps the current source composition and text scale. At the manuscript text width of 396 pt / 5.5 in, many native labels are about 3–6 pt. The 7 pt threshold used in the report is an internal readability target, not an asserted official ICLR minimum. Paper_width_check_396pt.pdf places each figure at the exact target width on a letter page. These files have not replaced the manuscript or passed a full ICLR page-count/font audit.

## Source

The source bundle contains per-page manifests, formula SVG/TeX files and reconstruction scripts. The manifests use relative formula asset paths. Rendering/building uses the image-to-editable-ppt skill runtime. Source normalization, structural validation and actual page rendering passed. Configured external OCR timed out; local ink measurements and source reading were used.

Install the included Liberation Sans regular/bold fonts before editing on a machine where they are absent. They are bundled unmodified with their SIL Open Font License to reduce font substitution and layout changes.
''')
    report = {'status': 'PASS', 'scope': 'editable structure, source preservation and actual vector rendering',
              'slides': summaries, 'formulas_native_office_equations': False,
              'source_raster_overlay': False, 'full_manuscript_iclr_audit': 'not_performed',
              'print_readability': 'source-sized small labels remain; see 396pt sheet'}
    (OUT / 'validation.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')

    selected = [(path, path.name) for path in sorted(OUT.iterdir()) if path.is_file() and path.suffix != '.zip']
    for index in (1, 2):
        page_dir = RUN / f'pages/page_{index:03}'
        for filename in ['manifest.json', 'author_manifest.py', 'validation.json', 'page_result.json']:
            selected.append((page_dir / filename, f'source/pages/page_{index:03}/{filename}'))
        for asset in sorted((page_dir / 'assets').iterdir()):
            if asset.is_file() and asset.suffix in ('.svg', '.tex', '.json'):
                selected.append((asset, f'source/pages/page_{index:03}/assets/{asset.name}'))
    selected.append((HERE / 'reconstruction-contract.md', 'source/reconstruction-contract.md'))
    selected.append((Path(__file__), 'source/export_delivery.py'))
    for style in ['Regular', 'Bold']:
        path = Path('/usr/share/fonts/truetype/liberation2') / f'LiberationSans-{style}.ttf'
        assert path.is_file()
        selected.append((path, f'fonts/{path.name}'))
    selected.append((Path('/usr/share/doc/fonts-liberation2/copyright'), 'fonts/LICENSE.txt'))
    bundle = OUT / 'SafeTransport_editable_source_bundle.zip'
    with zipfile.ZipFile(bundle, 'w', zipfile.ZIP_DEFLATED) as z:
        for path, name in selected:
            z.write(path, name)
    with zipfile.ZipFile(bundle) as z:
        assert z.testzip() is None
        for path, name in selected:
            assert hashlib.sha256(z.read(name)).hexdigest() == sha(path)
    (HERE / 'package-checks.json').write_text(json.dumps({'status': 'PASS', 'members': len(selected),
        'bundle_sha256': sha(bundle), 'files': {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p)}
                                            for p in OUT.iterdir() if p.is_file()}}, indent=2) + '\n')
    print(json.dumps({'status': 'PASS', 'slides': summaries, 'bundle_members': len(selected)}, ensure_ascii=False))

if __name__ == '__main__':
    main()
