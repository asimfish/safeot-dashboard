"""Author a manifest of native Figure 2 structure; build only through editppt.

The script uses source pixels solely for solid-color measurements. Mathematical
assets are rendered through the required editppt CLI; all other objects remain
native shapes and text in the authoritative manifest.
"""
from __future__ import annotations

import hashlib
import json
import math
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

import numpy as np
from PIL import Image, ImageFont

PAGE = Path(__file__).resolve().parent
ROOT = PAGE.parents[6]
CLI = ROOT / "figure-studio-runs/safetransport-iclr27-teaserfig/recovery/editppt-venv/bin/editppt"
REQUEST = json.loads((PAGE / "page_request.json").read_text())
SOURCE = np.array(Image.open(PAGE / "source.png").convert("RGB"))
PT_PER_PX = REQUEST["content_box"]["width"] * 72 / SOURCE.shape[1]
FONT = "/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf"
FONT_BOLD = "/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf"

INK = "#0A1530"
TEAL = "#04949E"
GREY = "#85919C"
FRAME = "#98B3BD"
ORANGE = "#AA420A"

shapes, texts, images, provenance, formulas = [], [], [], [], []
formula_cache = {}


def dump(name, payload):
    (PAGE / name).write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n")


def shape(name, kind, box, fill="none", stroke="none", width=1, z=15, **extra):
    item = {"id": name, "type": kind, "box_px": box, "fill": fill,
            "stroke": stroke, "stroke_width": width * PT_PER_PX, "z_index": z, **extra}
    shapes.append(item)
    return item


def line(name, start, end, color=GREY, width=1.4, dash=None, z=18):
    item = {"id": name, "type": "line", "points_px": [*start, *end],
            "stroke": color, "stroke_width": width * PT_PER_PX, "z_index": z}
    if dash:
        item["dash"] = dash
    shapes.append(item)


def polygon(name, points, fill, stroke="none", width=1, z=20):
    xs, ys = zip(*points)
    return shape(name, "polygon", [min(xs), min(ys), max(xs)-min(xs), max(ys)-min(ys)],
                 fill, stroke, width, z, polygon_px=points)


def arrow(name, start, end, color=GREY, width=1.5, head=8, dash=None, z=19):
    vx, vy = end[0]-start[0], end[1]-start[1]
    norm = math.hypot(vx, vy)
    ux, uy = vx/norm, vy/norm
    base = (end[0]-ux*head, end[1]-uy*head)
    if dash and abs(vx) > .01 and abs(vy) > .01:
        length = max(0, norm-head)
        for j in range(math.ceil(length/8)):
            a, b = j*8, min(j*8+5, length)
            if b > a:
                line(f"{name}_dash_{j}", (start[0]+ux*a,start[1]+uy*a),
                     (start[0]+ux*b,start[1]+uy*b), color, width, z=z)
    else:
        line(name+"_shaft", start, base, color, width, dash, z)
    polygon(name+"_head", [end, (base[0]-uy*head*.49, base[1]+ux*head*.49),
                            (base[0]+uy*head*.49, base[1]-ux*head*.49)], color, z=z+1)


def route(name, points, color=GREY, width=2.5, head=12, dash=None, z=15):
    for i, (a, b) in enumerate(zip(points[:-2], points[1:-1])):
        line(f"{name}_seg_{i}", a, b, color, width, dash, z)
    arrow(name+"_end", points[-2], points[-1], color, width, head, dash, z)


def txt(name, text, box, tier="body", bold=False, align="left", color=INK, **extra):
    px = {"title": 23, "body": 17, "minor": 15}[tier]
    item = {"id": name, "text": text, "box_px": box, "font": "Liberation Sans",
            "preview_font": FONT_BOLD if bold else FONT,
            "font_size": round(px * PT_PER_PX, 5), "font_size_source": "measured",
            "font_measurement": "Source ink bounds; builtin-ink hints contained zero lines.",
            "fit_text": False,
            "fit_text_note": "Manually calibrated after the first build: measured Liberation Sans widths and line heights fit every local box; actual LibreOffice export inspected. This keeps exact shared tier sizes.",
            "size_group": tier, "color": color, "bold": bold,
            "align": align, "valign": "middle", "wrap": "none", "z_index": 50,
            **extra}
    texts.append(item)
    return item


def formula(name, tex, box, asset=None):
    asset = asset or name
    if asset not in formula_cache:
        svg = PAGE / "assets" / (asset+".svg")
        frag = PAGE / "assets" / (asset+".fragment.json")
        document = ("\\documentclass[border=0pt]{standalone}\n"
                    "\\usepackage{amsmath,amssymb,mathtools,bm,xcolor}\n"
                    "\\begin{document}\n$\\color[HTML]{0A1530}"+tex+"$\n"
                    "\\end{document}\n")
        source = PAGE / "assets" / (asset+".input.tex")
        source.parent.mkdir(exist_ok=True)
        source.write_text(document)
        signature = hashlib.sha256(document.encode()).hexdigest()
        stamp = svg.with_suffix(".signature")
        if not (svg.exists() and frag.exists() and stamp.exists() and stamp.read_text() == signature):
            result = subprocess.run([str(CLI), "formula", "render-latex", str(PAGE),
                        "--tex-file", str(source), "--full-document", "--engine", "/usr/bin/pdflatex",
                        "--out", str(svg), "--box", ",".join(map(str, box)),
                        "--id", asset, "--fragment", str(frag)], capture_output=True, text=True)
            if result.returncode:
                raise RuntimeError(result.stdout + result.stderr)
            stamp.write_text(signature)
            print("Rendered formula", asset, flush=True)
        fragment = json.loads(frag.read_text())
        root = ET.parse(svg).getroot()
        view = [float(x) for x in root.attrib["viewBox"].split()]
        formula_cache[asset] = (fragment, view[2]/view[3])
        provenance.extend(fragment["asset_provenance"])
        record = dict(fragment["formula_inventory"][0])
        record["latex"] = tex
        formulas.append(record)
    fragment, aspect = formula_cache[asset]
    x, y, w, h = box
    if w/h > aspect:
        actual_w, actual_h = h*aspect, h
    else:
        actual_w, actual_h = w, w/aspect
    item = dict(fragment["images"][0])
    item.update(id=name, box_px=[x+(w-actual_w)/2, y+(h-actual_h)/2, actual_w, actual_h], z_index=55)
    images.append(item)
    return item


def cell_color(x, y, w, h):
    patch = SOURCE[int(y+h*.3):int(y+h*.7), int(x+w*.3):int(x+w*.7)]
    rgb = np.median(patch.reshape(-1, 3), axis=0).astype(int)
    return "#"+"".join(f"{c:02X}" for c in rgb)


def matrix(name, x, y, w, h):
    cw, ch = w/4, h/4
    for row in range(4):
        for col in range(4):
            cx, cy = x+col*cw, y+row*ch
            shape(f"{name}_{row}_{col}", "rect", [cx,cy,cw,ch], cell_color(cx,cy,cw,ch), "#5D8A90", .8, 23)
    shape(name+"_outline", "rect", [x,y,w,h], "none", "#223A43", 1.25, 24)


def stacked_capacities():
    for plane, x in enumerate((753, 780, 807)):
        y, w, h, skew = 125, 54, 82, 19
        for row in range(4):
            for col in range(4):
                def pos(u, v):
                    return [x+u*w, y+v*h-u*skew]
                u0,u1,v0,v1 = col/4,(col+1)/4,row/4,(row+1)/4
                points=[pos(u0,v0),pos(u1,v0),pos(u1,v1),pos(u0,v1)]
                fill=("#DCEFF0", "#ECF7F7", "#CFE6E8")[(row+col+plane)%3]
                polygon(f"capacity_plane{plane}_cell{row}_{col}",points,fill,"#94B8BD",.55,22+plane)
        polygon(f"capacity_plane{plane}_outline",[[x,y],[x+w,y-skew],[x+w,y+h-skew],[x,y+h]],
                "none","#76949E",.9,25+plane)


def graph(name, coords, radius):
    edges = [(1,2,TEAL),(2,3,GREY),(1,4,GREY),(2,5,TEAL),(3,6,TEAL),
             (4,5,TEAL),(5,6,GREY),(5,1,GREY),(5,3,TEAL),(3,5,TEAL)]
    for a,b,color in edges:
        ax,ay=coords[a-1]; bx,by=coords[b-1]
        vx,vy=bx-ax,by-ay; dist=math.hypot(vx,vy); ux,uy=vx/dist,vy/dist
        # The opposed diagonal edges are separate, parallel directed connectors.
        offset=2.2 if {a,b}=={3,5} else 0
        start=(ax+ux*radius-uy*offset,ay+uy*radius+ux*offset)
        end=(bx-ux*(radius+1)-uy*offset,by-uy*(radius+1)+ux*offset)
        arrow(f"{name}_s{a}_s{b}",start,end,color,2 if color==TEAL else 1.3,
              8 if radius>=17 else 7,z=31)
    for i,(x,y) in enumerate(coords,1):
        shape(f"{name}_node_s{i}","ellipse",[x-radius,y-radius,2*radius,2*radius],"#FCFEFE",INK,1.4,35)
        h=15 if radius>=17 else 14
        formula(f"{name}_label_s{i}",f"s_{{{i}}}",[x-8,y-h/2,16,h],asset=f"node_s{i}")


def bezier_arrow(name, points, color=TEAL, width=2):
    p0,p1,p2,p3=points
    samples=[]
    for j in range(29):
        t=j/28; u=1-t
        samples.append([u**3*p0[k]+3*u*u*t*p1[k]+3*u*t*t*p2[k]+t**3*p3[k] for k in (0,1)])
    for j,(a,b) in enumerate(zip(samples[:-3],samples[1:-2])):
        line(f"{name}_curve_{j}",a,b,color,width,z=30)
    arrow(name+"_tip",samples[-3],samples[-1],color,width,11,z=30)


def build():
    dump("source_analysis.json", {
        "page_type":"execution-framework diagram", "page_size_px":[1836,857],
        "decision_order":["solid white background and native panel fills", "all visual objects are native diagram structure", "native text plus CLI formula assets"],
        "background_strategy":{"mode":"native-or-script","white_canvas":True,"repair_required":False},
        "foreground_assets_requiring_separation":[],
        "native_structure":["trajectory sample nodes and arrow edges", "four directed transition graphs sharing the same ten-edge topology", "capacity stack cell polygons", "three four-by-four matrices", "station panels", "Sinkhorn iteration arcs", "main and diagnostic routing"],
        "source_ink_measurements":{"rollout_title":[24,142,231,22],"compile_title":[712,62,346,23],"ppo_title":[1330,145,206,22],"body_rollout":[39,205,134,17],"body_graph":[281,203,188,17],"diagnostic_title":[1034,611,346,23]},
        "text_hints":{"backend":"builtin-ink","lines":0,"paddle_ocr":"configured service upload timed out during parent prepare"},
        "typography_basis":"Direct dark-ink measurement and Liberation Sans glyph metrics; source level heights preserved with three native tiers."})

    # White and lightly tinted native panels retain the source composition.
    shape("canvas","rect",[0,0,1836,857],"#FFFFFF",z=0)
    shape("rollout_panel","rect",[20,175,474,275],"#FFFFFF",FRAME,1.2,10)
    shape("solver_panel","roundRect",[628,272,605,278],"#E9F5F4",TEAL,2.1,10,
          source_corner_radius_px=4,corner_category="small-radius",corner_reason="Source corners have a slight four-pixel radius.")
    shape("ppo_panel","rect",[1320,175,493,265],"#F6FAFA",FRAME,1.2,10)
    shape("diagnostic_panel","rect",[1001,600,795,180],"#FFFFFF",FRAME,1.3,10)

    # The source rollout bypass and updated-policy loop remain separate.
    route("rollout_samples_to_ppo",[[494,208],[519,208],[519,34],[1580,34],[1580,175]],GREY,3,14)
    arrow("graph_statistics_to_solver",[494,374],[628,374],TEAL,2.8,14)
    arrow("capacity_to_solver",[1048,231],[1048,272],TEAL,2.6,13)
    arrow("entropy_to_solver",[1205,237],[1187,269],"#526678",1.4,8,"dash")
    arrow("target_to_ppo",[1233,376],[1320,376],TEAL,3,14)
    route("target_reference_to_diagnostic",[[1308,376],[1308,566],[1090,566],[1090,600]],TEAL,1.3,11,"dash")
    # Evaluation now branches explicitly from the updated policy output.
    route("policy_to_evaluation",[[1767,463],[1624,463],[1624,598]],GREY,2.6,14)
    route("policy_to_next_rollout",[[1767,337],[1767,582],[1814,582],[1814,823],[101,823],[101,450]],GREY,3,14)

    txt("rollout_title","Rollout → flow graph",[22,135,282,34],"title",True)
    txt("compile_title","Compile budgets into capacities",[697,54,385,35],"title",True,align="center")
    txt("ppo_title","Flow-weighted PPO",[1328,139,281,34],"title",True)
    txt("diagnostic_title","Measure target-to-policy transfer",[1031,606,455,33],"title",True)
    txt("samples_bypass_text","samples,",[1134,6,76,28])
    formula("samples_bypass_flow",r"\widehat F_{\mathrm{roll}}",[1207,5,39,28],asset="roll_flow")

    txt("trajectory_label","rollout trajectories",[37,198,205,29])
    txt("graph_label","empirical transition graph",[280,197,210,29])
    txt("samples_label","samples",[88,370,87,31],align="center")
    xnodes=[45,85,124,163,202]
    ynodes=[271,310,350]
    sample_colors=[['#C2DCE1','#BCD7DD','#BCD7DD','#B3D2D8','#2197A1'],
                   ['#BED9DE','#2799A3','#2396A0','#B1D1D7','#C4DFE2'],
                   ['#86AAB5','#C5DFE3','#BEDADE','#138D97','#BEDADE']]
    for row,y in enumerate(ynodes):
        for col in range(4):
            arrow(f"trajectory_{row}_edge_{col}",[xnodes[col]+10,y],[xnodes[col+1]-10,y],GREY,1.2,6,z=25)
        for col,x in enumerate(xnodes):
            shape(f"trajectory_{row}_sample_{col}","ellipse",[x-10,y-10,20,20],sample_colors[row][col],INK,1.2,30)
    arrow("samples_to_empirical_graph",[230,311],[269,311],GREY,2,14)
    graph("empirical",[(305,262),(382,262),(454,262),(305,355),(382,355),(454,355)],19)
    formula("empirical_statistics",r"D,\ \widehat\mu_0,\ \widehat F_{\mathrm{roll}}",[330,395,107,32])
    txt("statistics_label","graph\nstatistics",[512,322,86,49],align="center")
    formula("statistics_edge",r"D,\ \widehat\mu_0",[529,386,52,22])

    formula("budget_count",r"K",[657,131,22,22])
    txt("budgets_label","budgets",[683,127,76,30])
    stacked_capacities()
    formula("capacity_stack_label",r"S^{(1)},\ldots,S^{(K)}",[751,216,116,25])
    txt("hard_min_label","elementwise\nmin",[876,117,105,47],align="center")
    arrow("hard_min_composition",[874,165],[992,165],TEAL,2.6,13)
    matrix("capacity",1004,111,90,90)
    formula("capacity_label",r"S",[1040,210,17,19])
    formula("entropy_epsilon",r"\varepsilon",[1178,217,10,14])
    txt("entropy_label","(entropy)",[1190,209,86,30],"minor")

    # The only mathematical character in the editable station title is an SVG.
    title_left="Capacity-constrained"
    title_right="-flow Sinkhorn"
    f=ImageFont.truetype(FONT_BOLD,23)
    lw=f.getlength(title_left); rw=f.getlength(title_right); total=lw+22+rw
    tx=930.5-total/2
    txt("solver_title_left",title_left,[tx,283,lw+2,34],"title",True)
    formula("solver_title_gamma",r"\boldsymbol{\gamma}",[tx+lw+4,286,17,23])
    txt("solver_title_right",title_right,[tx+lw+21,283,rw+5,34],"title",True)
    matrix("iterative_flow",688,335,107,105)
    formula("iterative_flow_label",r"F^{(t)}",[727,448,36,22])
    bezier_arrow("sinkhorn_upper",[[849,362],[887,320],[937,323],[970,361]])
    bezier_arrow("sinkhorn_lower",[[971,417],[937,458],[883,457],[846,416]])
    txt("sinkhorn_label","Sinkhorn",[859,350,98,28],align="center")
    txt("scaling_label","scaling",[860,372,98,23],"minor",align="center")
    formula("gamma_flow_label",r"(\gamma\text{-flow,}",[884,394,51,17])
    txt("upper_bound_label","upper bound)",[850,406,119,28],"minor",align="center")
    graph("solver_target",[(1038,338),(1106,338),(1170,338),(1038,422),(1106,422),(1170,422)],17)
    formula("solver_target_label",r"F^\star",[1094,448,29,21],asset="target_flow")
    line("solver_divider",[671,481],[1199,481],"#819BA2",1.5,z=23)
    formula("solver_objective",r"\min\,\langle D,F\rangle-\varepsilon H(F)",[827,489,168,23])
    txt("flow_balance_label","discounted flow balance ·",[771,510,218,32])
    formula("capacity_bound",r"0\leq F\leq S",[984,519,81,18])
    formula("target_output",r"F^\star",[1257,347,33,25],asset="target_flow")
    txt("target_feasibility","feasible\ntarget",[1239,383,62,43],align="center")

    txt("weight_label","clipped flow-ratio weights",[1352,199,278,31])
    matrix("ppo_weights",1373,243,125,125)
    arrow("weights_to_ppo",[1510,312],[1560,312],TEAL,2.8,14,z=28)
    shape("ppo_block","roundRect",[1566,266,119,91],"#DCE4E8","#718996",1.2,25,
          source_corner_radius_px=4,corner_category="small-radius",corner_reason="Source PPO block has a slight corner radius.")
    txt("ppo_block_text","PPO",[1566,266,119,91],"title",True,align="center")
    arrow("ppo_to_policy",[1692,312],[1737,312],"#688690",2.7,13,z=28)
    formula("policy_output",r"\pi_\theta",[1750,300,39,35])
    txt("evaluation_label","evaluate",[1640,479,94,33])
    formula("evaluation_realized",r"\widehat F_\theta",[1654,515,30,31],asset="realized_flow")

    graph("diagnostic_target",[(1047,656),(1106,656),(1163,656),(1047,724),(1106,724),(1163,724)],16)
    graph("diagnostic_realized",[(1410,656),(1470,656),(1526,656),(1410,724),(1470,724),(1526,724)],16)
    formula("diagnostic_target_flow",r"F^\star",[1058,749,27,23],asset="target_flow")
    txt("target_caption","(target)",[1087,744,79,33])
    formula("diagnostic_realized_flow",r"\widehat F_\theta",[1421,747,30,28],asset="realized_flow")
    txt("realized_caption","(realized)",[1450,744,84,33])
    formula("transfer_gap",r"\Delta F=\lVert F^\star-\widehat F_\theta\rVert_1",[1201,675,165,29])
    txt("cost_audit_label","per-channel costs",[1220,709,164,31])
    line("recovery_divider",[1566,636],[1566,760],ORANGE,1.4,"dash",30)
    txt("recovery_condition","persistent gap → recovery",[1585,649,203,30],"minor",color=ORANGE)
    txt("recovery_name","SafeTransport-Safe",[1605,675,181,28],"body",color=ORANGE)
    txt("recovery_update","per-channel Lagrangian update",[1578,700,211,28],"minor")
    txt("next_rollout_label","next rollout",[850,790,139,31],align="center")

    manifest={
        "schema_version":1,"page_id":"page_002","slide":REQUEST["slide"],"content_box":REQUEST["content_box"],
        "source":{"path":"source.png","width_px":1836,"height_px":857},
        "page_strategy":"Native editable execution-framework structure with independent CLI-rendered mathematical SVGs and retained LaTeX.",
        "preview_scale":120,
        "text_inventory":[{"id":item["id"],"items":item["text"].splitlines(),"decision":"native-text"} for item in texts],
        "visual_inventory":[
            {"id":"background","description":"Native structural white background and lightly tinted station panels; source composition preserved.","decision":"native-structure"},
            {"id":"rollout_samples","description":"Native structural trajectory sample circles with directed arrow edges; three five-sample trajectories.","decision":"native-structure"},
            {"id":"graphs","description":"Native structural state circles and all ten directed transitions retained in each of four graph instances.","decision":"native-structure"},
            {"id":"capacity_stack","description":"Native structural skewed grid cells in three overlapping capacity planes.","decision":"native-structure"},
            {"id":"matrices","description":"Native structural four-by-four matrix cells with source-measured solid fill colors.","decision":"native-structure"},
            {"id":"routing","description":"Native structural main arrows, iteration arcs, policy return loop and dotted target-reference route.","decision":"native-structure"},
            {"id":"formula_labels","description":"Formula SVG assets generated from transcribed LaTeX through editppt formula render-latex.","decision":"latex-rendered-formula"}],
        "background_strategy":{"mode":"native-or-script","source_consistency_contract":"Preserve original white canvas, panel positions, native fills, and restrained teal/charcoal composition.","removed_foreground":[],"comparison_note":"Native white background and station fill geometry match source regions; no background image was required."},
        "quality_checks":{"font_size_calibrated":False,"visual_inventory_matched":True,"background_strategy_checked":True,"shape_corner_geometry_checked":True},
        "text_boxes":texts,"shapes":shapes,"images":images,"asset_provenance":provenance,"formula_inventory":formulas,
        "scientific_routing":{"budget_composition":"hard minimum only; K channel capacities feed S then solver", "rollout_bypass":"Raw rollout samples feed PPO along the top bypass", "target":"Feasible F* feeds PPO and a dotted diagnostic reference", "realized_flow":"Updated policy is evaluated independently; no target-to-realized arrow", "next_rollout":"Updated policy output wraps around the diagnostic panel into rollout", "recovery":"Persistent-gap conditional per-channel Lagrangian update"},
        "source_differences":["Liberation Sans replaces the source image's visually similar condensed lettering at matching glyph-height tiers.","Subtle source cell textures and panel gradients are represented by source-measured solid native fills.","Evaluation branches from the updated policy output in existing whitespace below PPO to make the required dependency explicit.","The dotted target reference is connected at the target edge and routed beside the feasible-target label.","Source antialiasing and line joins differ slightly in native structure."],
        "warnings":["PaddleOCR service upload timed out during prepare; builtin-ink returned no lines, so source ink was measured directly.","Formulas are independent SVG assets with retained LaTeX, not Office equation objects.","Source-faithful labels are below 7pt when the full slide is reduced to a 396pt paper width."]}
    dump("manifest.json",manifest)
    print(f"Authored {len(shapes)} native shapes, {len(texts)} native text boxes, {len(images)} formula instances from {len(formulas)} retained LaTeX sources",flush=True)


if __name__ == "__main__":
    build()
