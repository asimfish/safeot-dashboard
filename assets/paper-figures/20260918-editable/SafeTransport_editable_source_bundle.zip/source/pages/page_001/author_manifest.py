"""Author Figure1's declarative native-object manifest; build only with editppt."""
from __future__ import annotations

import json
import math
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

PAGE = Path(__file__).resolve().parent
CLI = Path('/home/dataset-local/liyufeng/SafeTransport/figure-studio-runs/safetransport-iclr27-teaserfig/recovery/editppt-venv/bin/editppt')
REQ = json.loads((PAGE / 'page_request.json').read_text())
INK = '#132D3A'
TEAL = '#117E84'
FLOW = '#278B8F'
CAPACITY = '#D9DEE1'
NODE = '#E5EBED'
FONT = '/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf'
BOLD_FONT = '/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf'

manifest = {
    'schema_version': 1, 'page_id': 'page_001',
    'page_strategy': 'native-structural-diagram-with-independent-latex-formulas',
    'slide': REQ['slide'], 'content_box': REQ['content_box'],
    'source': {'path': 'source.png', 'width_px': 1860, 'height_px': 845},
    'preview_scale': 96,
    'text_inventory': [], 'visual_inventory': [
        {'id': 'background', 'kind': 'background', 'description': 'Uniform white native background matching the source canvas.'},
        {'id': 'graphs', 'kind': 'native structural', 'description': 'Three native structural directed six-node graphs with identical topology, gray capacity segments and separate teal flow arrows; eighteen circular nodes and twenty-four directed edges.'},
        {'id': 'matrices', 'kind': 'native structural', 'description': 'Five stacked native structural four-by-four safety-budget matrices and one shared four-by-four matrix; independently editable straight-corner cells and lines.'},
        {'id': 'shared-span', 'kind': 'native structural', 'description': 'One native structural open span covers the three graph regimes, with a composition arrow and routed shared-capacities connector.'},
        {'id': 'regime-line', 'kind': 'native structural', 'description': 'One native structural comparison line with three circular positions and two capacity/flow legend swatches.'},
        {'id': 'formulas', 'kind': 'formula', 'description': 'Objective, feasible-set notation, capacity inequalities, hard-min composition and mathematical labels are transcribed LaTeX rendered through editppt.'},
        {'id': 'ordinary-text', 'kind': 'native text', 'description': 'All ordinary labels, titles, legend text and caption are native Liberation Sans text boxes.'},
    ],
    'background_strategy': {
        'mode': 'native-or-script',
        'source_consistency_contract': 'Preserve the 1860 by 845 white canvas, whitespace, graph positions, one shared solver span, stacked budgets and charcoal/teal palette.',
        'removed_foreground': [],
        'comparison_note': 'White background is reconstructed independently of every text, formula and diagram object; source composition preserved.'
    },
    'quality_checks': {'font_size_calibrated': True, 'visual_inventory_matched': True, 'background_strategy_checked': True, 'shape_corner_geometry_checked': True},
    'text_boxes': [], 'shapes': [], 'images': [], 'asset_provenance': [], 'formula_inventory': [],
    'scientific_context': [
        'One capacity-flow algorithm spans penalty-like and constraint-like internal regimes.',
        'The feasible set and S remain fixed while epsilon selects an internal feasible-flow optimum.',
        'Regime labels do not assert exact equivalence to external baseline algorithms.',
        'Hard-min composition combines safety capacities; discounted flow balance is not balanced OT.',
    ],
    'source_differences': [
        'Normal text uses Liberation Sans consistently; source caption serif styling is normalized to Liberation Sans.',
        'Native solid fills replace slight raster grain and shading in circles and matrix cells.',
        'Smooth span and connector turns are represented by editable native freeform contours.',
        'Formula SVGs retain their LaTeX sources and are independent movable objects, but are not Office equation objects.',
    ],
    'text_calibration': {
        'hints_backend': 'builtin-ink',
        'paddleocr_status': 'Configured service attempted during prepare; source upload timed out.',
        'note': 'Hints supplied candidate line boxes. L03 merged title, subtitle and span, while math is fragmented. Actual individual source ink bounds and Liberation Sans glyph metrics calibrate the source-faithful tiers. No heading is enlarged.',
        'font_tiers_pt': {'main-title': 27, 'subtitle': 19.5, 'endpoint-and-body': 18, 'caption': 16.5, 'small-label': 15.75},
        'paper_width_pt': 396,
    },
}


def shape(id, kind, box=None, *, fill='none', stroke='none', stroke_width=1, z=10, **extra):
    item = {'id': id, 'type': kind, 'fill': fill, 'stroke': stroke, 'stroke_width': stroke_width, 'z_index': z}
    if box is not None:
        item['box_px'] = [round(float(n), 4) for n in box]
    item.update(extra)
    manifest['shapes'].append(item)
    return item


def line(id, a, b, color, px_width, z=10):
    return shape(id, 'line', stroke=color, stroke_width=px_width * .75, z=z, points_px=[*a, *b])


def polygon(id, points, color, z=15):
    xx, yy = zip(*points)
    return shape(id, 'polygon', [min(xx), min(yy), max(xx) - min(xx), max(yy) - min(yy)], fill=color, z=z,
                 polygon_px=[[round(x, 4), round(y, 4)] for x, y in points], corner_category='straight')


def arrow(id, a, b, width, head_width=18, head_length=17, color=FLOW, z=15, start_trim=0, end_trim=0):
    dx, dy = b[0] - a[0], b[1] - a[1]
    length = math.hypot(dx, dy)
    ux, uy = dx / length, dy / length
    nx, ny = -uy, ux
    sx, sy = a[0] + ux * start_trim, a[1] + uy * start_trim
    ex, ey = b[0] - ux * end_trim, b[1] - uy * end_trim
    bx, by = ex - ux * head_length, ey - uy * head_length
    return polygon(id, [(sx + nx * width/2, sy + ny * width/2),
                        (bx + nx * width/2, by + ny * width/2),
                        (bx + nx * head_width/2, by + ny * head_width/2),
                        (ex, ey),
                        (bx - nx * head_width/2, by - ny * head_width/2),
                        (bx - nx * width/2, by - ny * width/2),
                        (sx - nx * width/2, sy - ny * width/2)], color, z)


def text(id, value, box, size, *, bold=False, color=INK, align='left', group='endpoint-and-body', hints=()):
    item = {'id': id, 'text': value, 'box_px': box, 'font': 'Liberation Sans', 'font_size': size,
            'font_size_source': 'measured', 'source_hint_ids': list(hints), 'size_group': group,
            'bold': bold, 'color': color, 'align': align, 'valign': 'middle', 'fit_text': False,
            'fit_note': 'The first deterministic preview applied excessive heuristic shrink. This source box and Liberation Sans glyph metrics are manually calibrated and checked in actual export.',
            'line_height': 1.0, 'preview_font': BOLD_FONT if bold else FONT, 'z_index': 60}
    manifest['text_boxes'].append(item)
    manifest['text_inventory'].append({'id': id, 'text': value, 'decision': 'native-text', 'size_group': group})


def ribbon(id, centerline, width, color, z=20):
    # A single editable native contour, with source-defined curved structural turns.
    normals=[]
    for i,p in enumerate(centerline):
        a=centerline[max(0,i-1)]; b=centerline[min(len(centerline)-1,i+1)]
        dx,dy=b[0]-a[0],b[1]-a[1]; d=math.hypot(dx,dy)
        normals.append((-dy/d,dx/d))
    outer=[(p[0]+n[0]*width/2,p[1]+n[1]*width/2) for p,n in zip(centerline,normals)]
    inner=[(p[0]-n[0]*width/2,p[1]-n[1]*width/2) for p,n in zip(centerline,normals)]
    polygon(id,outer+inner[::-1],color,z)


def bezier(a,b,c,d,n=16):
    return [((1-t)**3*a[0]+3*(1-t)**2*t*b[0]+3*(1-t)*t*t*c[0]+t**3*d[0],
             (1-t)**3*a[1]+3*(1-t)**2*t*b[1]+3*(1-t)*t*t*c[1]+t**3*d[1]) for t in [i/n for i in range(n+1)]]


def formula(id, latex, target, pt, color=INK):
    doc=(r'\documentclass[border=0pt]{standalone}'+'\n'+
         r'\usepackage{amsmath,amssymb,mathtools,bm,xcolor,lmodern}'+'\n'+
         rf'\DeclareMathSizes{{{pt}}}{{{pt}}}{{{pt*.7}}}{{{pt*.5}}}'+'\n'+
         r'\begin{document}'+'\n'+rf'\color[HTML]{{{color.lstrip("#")}}}\fontsize{{{pt}}}{{{pt*1.2}}}\selectfont'+
         '\n'+r'$\displaystyle '+latex+r'$'+'\n'+r'\end{document}'+'\n')
    input_path=PAGE/'assets'/f'{id}.input.tex'; input_path.write_text(doc)
    command=[str(CLI),'formula','render-latex',str(PAGE),'--tex-file',str(input_path),'--full-document',
             '--engine','/usr/bin/pdflatex','--out',f'assets/{id}.svg','--id',id,
             '--box',','.join(map(str,target)),'--fragment',str(PAGE/'assets'/f'{id}.fragment.json')]
    result=subprocess.run(command,text=True,capture_output=True)
    (PAGE/'assets'/f'{id}.render.log').write_text(result.stdout+result.stderr)
    if result.returncode:
        raise RuntimeError(f'{id}: {result.stderr[-3000:]}')
    root=ET.parse(PAGE/'assets'/f'{id}.svg').getroot()
    vw,vh=map(float,root.attrib['viewBox'].split()[2:])
    natural_w,natural_h=vw*96/72,vh*96/72
    factor=min(target[2]/natural_w,target[3]/natural_h)
    width,height=natural_w*factor,natural_h*factor
    fragment=json.loads((PAGE/'assets'/f'{id}.fragment.json').read_text())
    fragment['images'][0]['box_px']=[round(target[0]+(target[2]-width)/2,4),round(target[1]+(target[3]-height)/2,4),round(width,4),round(height,4)]
    fragment['images'][0]['z_index']=65
    fragment['formula_inventory'][0].update({'latex':latex,'requested_font_pt':pt,'effective_font_pt':round(pt*factor,4),'color':color,
                                          'font_note':'Scalable Latin Modern with explicitly declared normal/script/scriptscript math sizes; the independent SVG preserves the natural formula aspect ratio.'})
    (PAGE/'assets'/f'{id}.fragment.json').write_text(json.dumps(fragment,indent=2)+'\n')
    for key in ['images','asset_provenance','formula_inventory']:
        manifest[key].extend(fragment[key])
    print(f'{id}: {width:.1f} x {height:.1f} px, effective {pt*factor:.2f} pt',flush=True)


shape('white-canvas','rect',[0,0,1860,845],fill='#FFFFFF',z=0)

# One shared solver span, source-matched rounded shoulders and open lower side.
span=bezier((43,276),(48,259),(64,254),(86,254))+[(1773,254)]+bezier((1773,254),(1796,254),(1811,260),(1816,276))[1:]
ribbon('one-algorithm-span',span,2.8,TEAL,20)

# Stacked safety budgets are grids, not bitmap artwork.
front_colors=[['#86C1C2','#B5DCDE','#E9F4F5','#2C8D90'],
              ['#61ADAF','#AAD7D8','#E0EFF0','#B0D9DB'],
              ['#B3DADB','#E4F2F2','#54A7AA','#DFEFF0'],
              ['#AFD9DA','#52A3A6','#E3F1F2','#58A9AB']]
shared_colors=[['#92CACB','#E5F3F3','#DDEEEF','#248489'],
               ['#70B7B8','#90C9C9','#E4F2F3','#B1DADB'],
               ['#B7DCDD','#A4D3D4','#66B1B3','#DEF0F0'],
               ['#A0D1D3','#F2F9F9','#92C9CB','#A4D3D4']]

def matrix(id,x,y,colors,layer,side=100):
    cell=side/4
    shape(id+'-base','rect',[x,y,side,side],fill='#F2F8F8',z=layer)
    for r in range(4):
        for c in range(4):
            shape(f'{id}-r{r+1}c{c+1}','rect',[x+c*cell,y+r*cell,cell,cell],fill=colors[r][c],z=layer+1,corner_category='straight')
    for i in range(5):
        line(f'{id}-row-{i}',(x,y+i*cell),(x+side,y+i*cell),'#426369',.85,layer+2)
        line(f'{id}-col-{i}',(x+i*cell,y),(x+i*cell,y+side),'#426369',.85,layer+2)

for k in range(5):
    x,y=1387+8.25*k,44+9*k
    colors=front_colors if k==4 else [['#EAF5F5' if (r+c+k)%3 else '#C4E1E2' for c in range(4)] for r in range(4)]
    matrix(f'budget-matrix-{k+1}',x,y,colors,22+k*4)
matrix('shared-capacity-matrix',1653,68,shared_colors,44,99)
arrow('hard-min-composition',(1540,118.5),(1634,118.5),2.6,15,17,color=TEAL,z=45)
connector=[(1702.5,179),(1702.5,203)]+bezier((1702.5,203),(1702.5,212),(1698,215),(1688,215))[1:]+[(1520,215)]+bezier((1520,215),(1511,215),(1507.5,219),(1507.5,228))[1:]+[(1507.5,239)]
ribbon('shared-capacities-route',connector,2.7,TEAL,45)
polygon('shared-capacities-arrowhead',[(1499.5,236),(1515.5,236),(1507.5,253)],TEAL,46)

# Capacity widths are fixed edge-by-edge across all three graph regimes.
node_sets=[[(70,519),(206,435),(410,435),(551,519),(410,598),(206,598)],
           [(689,519),(825,435),(1029,435),(1170,519),(1029,598),(825,598)],
           [(1293,519),(1429,435),(1634,435),(1775,519),(1634,598),(1429,598)]]
edges=[(0,1),(0,5),(1,2),(1,5),(2,3),(2,4),(5,4),(4,3)]
capacity_widths=[22,22,25,14,25,14,25,22]
flow_widths=[[9,9,9,4.5,9,4.5,9,8],
             [7,8,5.5,4,8,4.5,5.5,6.5],
             [3,6,11.5,2.5,11,4,6.5,3]]
for g,nodes in enumerate(node_sets):
    for e,((a,b),cap,flow) in enumerate(zip(edges,capacity_widths,flow_widths[g])):
        line(f'regime-{g+1}-capacity-{e+1}',nodes[a],nodes[b],CAPACITY,cap,10)
        arrow(f'regime-{g+1}-flow-{e+1}',nodes[a],nodes[b],flow,
              head_width=18 if cap>15 else 17,head_length=18 if cap>15 else 17,
              z=15,start_trim=26,end_trim=24)
    for i,(x,y) in enumerate(nodes):
        shape(f'regime-{g+1}-node-{i+1}','ellipse',[x-22,y-22,44,44],fill=NODE,stroke='#172C37',stroke_width=1.5,z=18)

# Two keyed widths and the one-parameter comparison line.
for id,y,col in [('capacity',306.5,CAPACITY),('flow',336,FLOW)]:
    shape('legend-'+id,'roundRect',[1607,y,62,10],fill=col,z=20,source_corner_radius_px=5,corner_category='pill')
line('regime-comparison-line',(202,679),(1646,679),TEAL,2.5,20)
for i,x in enumerate([202,930,1646]):
    shape(f'regime-position-{i+1}','ellipse',[x-8.5,670.5,17,17],fill=TEAL,z=21)

# Ordinary text is native. Source font-size corrections use measured line geometry.
text('method-title','SafeTransport',[790,179,280,43],27,bold=True,color=TEAL,align='center',group='main-title',hints=['L03'])
text('method-subtitle','One capacity-flow algorithm',[753,216,354,37],19.5,color=TEAL,align='center',group='subtitle',hints=['L03'])
text('budget-heading','safety budgets',[1381,7,151,32],15.75,group='small-label',hints=['L01'])
text('shared-capacities','shared capacities',[1517,181,183,34],15.75,align='center',group='small-label')
text('capacity-legend','gray: capacity',[1684,295,164,33],15.75,group='small-label',hints=['L08'])
text('flow-legend','teal: flow',[1684,324,164,33],15.75,group='small-label',hints=['L10'])
text('flow-balance',': discounted flow balance,',[744,348,282,36],18,hints=['L11'])
text('penalty-heading','Penalty-like',[125,699,157,41],18,bold=True,align='center',hints=['L13'])
text('constraint-heading','Constraint-like',[1544,699,205,41],18,bold=True,align='center',hints=['L14'])
text('vary-epsilon-prefix','vary',[775,699,55,39],18,hints=['L12'])
text('vary-epsilon-suffix','within the same solver',[848,699,262,39],18,hints=['L12'])
text('larger-prefix','larger',[89,732,69,39],18,hints=['L18'])
text('diffuse-suffix','· diffuse flow',[179,732,150,39],18,hints=['L15'])
text('smaller-prefix','smaller',[1498,732,89,39],18,hints=['L16'])
text('concentrated-suffix','· concentrated flow',[1600,732,213,39],18,hints=['L17'])
text('bottom-caption','Shared representation across safe-RL regimes; capacities remain enforced.',[547,793,766,42],16.5,align='center',group='caption',hints=['L19'])

formula('budget-K',r'\text{\sffamily\itshape K}',[1363,10,15,24],16.5,TEAL)
formula('hard-min',r'S=\min\nolimits_k S^{(k)}',[1633,24,141,32],19.5)
formula('shared-objective',r'F^*_{\epsilon}=\arg\min_{F\in\mathcal{F}_S}\langle D,F\rangle-\epsilon H(F)',[661,281,545,68],29)
formula('feasible-set',r'\mathcal{F}_S',[703,354,40,27],20)
formula('capacity-bound',r'0\le F\le S',[1027,349,135,35],20)
formula('vary-epsilon',r'\epsilon',[828,711,13,14],18)
formula('larger-epsilon',r'\epsilon',[154,746,13,14],18)
formula('smaller-epsilon',r'\epsilon',[1580,746,13,14],18)

paper_scale=396/(REQ['slide']['width']*72)
manifest['text_calibration']['effective_font_tiers_at_396pt']= {k:round(v*paper_scale,3) for k,v in manifest['text_calibration']['font_tiers_pt'].items()}
manifest['editability']={'native_text_boxes':len(manifest['text_boxes']),'native_shapes':len(manifest['shapes']),'formula_images':len(manifest['images']),
                         'formula_sources_retained':True,'formula_internally_editable':False,'source_raster_embedded':False}
manifest['self_check']={'status':'pending-render-qa','manifest_preview_checked':False,'contact_sheet_checked':False,'actual_pptx_export_checked':False}
(PAGE/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Wrote manifest:',manifest['editability'])
