"""Semantic reconstruction of the generated revision, using SuperImg2PPT native scenes.

The generated sketches remain unchanged visual references. This separate candidate
corrects their scientific defects and applies the user's requested common hierarchy.
"""
from pathlib import Path
from contextlib import contextmanager
import argparse
import json
import math
import shutil
import logging
import re
from PIL import Image
from super_img2ppt.fonts import FontCatalog, measure, ink_bounds
from super_img2ppt.mathtext import compose_file

ROOT = Path(__file__).resolve().parent
INK = '#24343C'
TEAL = '#087F86'
GRAY = '#70828C'
PALE = '#EEF6F5'
SOFT = '#F5F7F8'
LINE = '#CADADB'
WHITE = '#FFFFFF'
FAMILY = 'Liberation Serif'
logging.getLogger('fontTools.ttLib.tables._h_e_a_d').setLevel(logging.ERROR)

def save(p, value):
    p.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

class Drawing:
    def __init__(self, number, dest):
        self.number, self.dest = number, dest
        dest.mkdir(parents=True, exist_ok=False)
        (dest/'pages/page_001').mkdir(parents=True)
        source = ROOT/'outputs/generated'/f'Figure{number}_v02.png'
        shutil.copy2(source, dest/'pages/page_001/source.png')
        self.w, self.h = Image.open(source).size
        self.scale = self.w/2000
        self.height = self.h/self.scale
        self.elements, self.groups, self.type = [], [], []
        self.cat = FontCatalog()
        self.container = None

    def add(self,e):
        e['z']=len(self.elements)
        if self.container and 'container' not in e:
            e['container']=self.container
        self.elements.append(e)
        return e['id']

    def shape(self,id,box,fill=None,stroke=None,sw=1.8,shape='round_rect',radius=8,background=False):
        e={'id':id,'kind':'shape','shape':shape,'box':[v*self.scale for v in box]}
        if fill:e['fill']=fill
        if stroke:e.update(stroke=stroke,stroke_width=sw*self.scale)
        if shape=='round_rect':e['radius']=radius*self.scale
        if background:e['role']='background'
        return self.add(e)

    def line(self,id,a,b,color=GRAY,sw=2.1,arrow=False,dash=None):
        e={'id':id,'kind':'line','points':[[v*self.scale for v in a],[v*self.scale for v in b]],'stroke':color,'stroke_width':sw*self.scale}
        if arrow:e.update(arrow=True,arrow_head={'length':12*self.scale,'width':9*self.scale})
        else:e['line_cap']='round'
        if dash:e['dash']=[v*self.scale for v in dash]
        return self.add(e)

    def join(self,a,b,why):
        e=next(x for x in self.elements if x['id']==a)
        e.setdefault('allow_overlap_with',[]).append(b)
        e['overlap_reason']=why

    def route(self,id,points,color=GRAY,sw=2.1,arrow=True):
        ids=[]
        for i,(a,b) in enumerate(zip(points,points[1:])):
            n=self.line(f'{id}_{i}',a,b,color,sw,arrow and i==len(points)-2)
            if ids:self.join(n,ids[-1],'Adjacent native segments are joined into one explicitly specified connector.')
            ids.append(n)
        if len(ids)>1:self.groups.append({'id':id,'members':ids,'description':'One editable routed connector; fixed endpoints.'})
        return ids

    def txt(self,id,text,x,y,size=37,bold=False,italic=False,color=INK,center=False):
        face=self.cat.resolve(text,FAMILY,FAMILY,bold,italic)
        s=size*self.scale
        width,asc,desc=measure(face,text,s)
        ink=ink_bounds(face,text,s)
        px=x*self.scale-(width/2 if center else 0)
        py=y*self.scale
        pad=max(0,-ink[0])+2
        e={'id':id,'kind':'text','box':[px-pad,py-asc-2,width+pad+5,max(asc+desc,s*1.18)+5],
           'padding':[2,0,0,pad],'text':text,'font_family':FAMILY,'cjk_font_family':FAMILY,
           'font_size':s,'bold':bold,'italic':italic,'color':color,'fit':'strict','wrap':False,'role':'content'}
        self.type.append({'id':id,'text':text,'font_pt_at_5_5in':size*396/2000,'role':'ordinary'})
        return self.add(e)

    def math(self,id,tokens,x,y,size=40,center=False,color=INK):
        """Explicit native parts with measured advances; tuples are (text, sub, sup)."""
        parts=[]; dx=0; special=[]; expanded=[]
        for token in tokens:
            if isinstance(token,str): token=(token,'','')
            text,sub,sup=token
            chunks=[c for c in re.split(r'([⟨⟩∥])',text) if c]
            for i,c in enumerate(chunks):expanded.append((c,sub if i==len(chunks)-1 else '',sup if i==len(chunks)-1 else ''))
        for token in expanded:
            text,sub,sup=token
            if text in ['⟨','⟩','∥']:
                special.append((text,dx))
                dx+=size*.3
                continue
            if not text.strip():
                if text:
                    face=self.cat.resolve(text,FAMILY,FAMILY,False,False)
                    dx+=measure(face,text,size*self.scale)[0]/self.scale
                continue
            italic=any(c.isalpha() for c in text) and text not in ['KL','min','max','s.t.']
            face=self.cat.resolve(text,FAMILY,FAMILY,False,italic)
            width=measure(face,text,size*self.scale)[0]/self.scale
            parts.append({'text':text,'offset':[dx*self.scale,0],'italic':italic})
            dx+=width
            scriptwidth=0
            for script,dy in [(sub,size*.24),(sup,-size*.48)]:
                if script:
                    if '_' in script:
                        head,tail=script.split('_',1)
                        face=self.cat.resolve(head,FAMILY,FAMILY,False,False)
                        headwidth=measure(face,head,size*self.scale*.66)[0]/self.scale
                        parts.append({'text':head,'offset':[dx*self.scale,dy*self.scale],'size_scale':.66,'italic':False})
                        parts.append({'text':tail,'offset':[(dx+headwidth)*self.scale,(dy+size*.18)*self.scale],'size_scale':.48,'italic':False})
                        face=self.cat.resolve(tail,FAMILY,FAMILY,False,False)
                        sw=headwidth+measure(face,tail,size*self.scale*.48)[0]/self.scale
                        scriptwidth=max(scriptwidth,sw)
                        continue
                    face=self.cat.resolve(script,FAMILY,FAMILY,False,False)
                    sw=measure(face,script,size*self.scale*.66)[0]/self.scale
                    parts.append({'text':script,'offset':[dx*self.scale,dy*self.scale],
                                  'size_scale':.66,'italic':False})
                    scriptwidth=max(scriptwidth,sw)
            dx+=scriptwidth+size*.03
        left=x-dx/2 if center else x
        origin=[left*self.scale,y*self.scale]
        spec={'id':id,'origin':origin,'font_family':FAMILY,'font_size':size*self.scale,
              'color':color,'parts':parts,'z':len(self.elements)}
        if self.container:spec['container']=self.container
        p=self.dest/f'{id}.math.json';save(p,spec)
        output=self.dest/'math'/id
        compose_file(p,output)
        elements=json.loads((output/'elements.json').read_text())
        for e in elements:
            e['role']='content'
            self.add(e)
        members=[e['id'] for e in elements]
        for i,(symbol,offset) in enumerate(special):
            px=left+offset; top=y-size*.72;bottom=y+size*.08;middle=(top+bottom)/2
            if symbol=='∥':
                for j in range(2):members.append(self.line(f'{id}_parallel_{i}_{j}',[px+size*(.08+j*.14),top],[px+size*(.08+j*.14),bottom],color,max(1.4,size*.04)))
            else:
                pts=([[px+size*.22,top],[px+size*.06,middle],[px+size*.22,bottom]] if symbol=='⟨' else [[px+size*.06,top],[px+size*.22,middle],[px+size*.06,bottom]])
                self.route(f'{id}_angle_{i}',pts,color,max(1.4,size*.04),False)
                members.append(f'{id}_angle_{i}')
        if len(members)>1:self.groups.append({'id':id,'members':members,'description':'Editable formula parts and native mathematical delimiters.'})
        self.type.append({'id':id,'font_pt_at_5_5in':size*396/2000,'role':'formula_base','text':str(tokens)})
        return dx

    @contextmanager
    def module(self,id,box=None,fill=None,stroke=None,sw=1.8):
        start=len(self.elements);gstart=len(self.groups); previous=self.container
        if box:
            self.shape(id+'_panel',box,fill,stroke,sw)
            self.container=id+'_panel'
        yield
        self.container=previous
        newgroups=self.groups[gstart:]
        children={m for g in newgroups for m in g['members']}
        members=[e['id'] for e in self.elements[start:] if e['id'] not in children]
        members += [g['id'] for g in newgroups if g['id'] not in children]
        if len(members)>1:self.groups.append({'id':id,'members':members,'description':id.replace('_',' ')})

    def graph(self,id,x,y,w,h,color=TEAL):
        # A repeated directed schematic topology; no measured flow values are implied.
        coords={1:(x,y+h*.5),2:(x+w*.26,y),3:(x+w*.72,y),4:(x+w,y+h*.5),5:(x+w*.26,y+h),6:(x+w*.72,y+h)}
        edges=[(1,2),(2,3),(3,4),(1,5),(5,6),(6,4),(2,5),(3,6)]
        r=17
        with self.module(id):
            for j,(a,b) in enumerate(edges):
                a,b=coords[a],coords[b]
                length=math.dist(a,b);vx=(b[0]-a[0])/length;vy=(b[1]-a[1])/length
                self.line(f'{id}_edge{j}',(a[0]+(r+3)*vx,a[1]+(r+3)*vy),(b[0]-(r+3)*vx,b[1]-(r+3)*vy),color if j<6 else GRAY,3.2 if j<3 else 2.3,True)
            for j,(a,b) in coords.items():self.shape(f'{id}_node{j}',[a-r,b-r,r*2,r*2],WHITE,color,2,'ellipse')

    def prices(self,id,x,y):
        with self.module(id):
            for j,text in enumerate(['1','2','…','K']):
                self.shape(id+f'_cell{j}',[x+j*80,y,80,56],WHITE,LINE,1.6,shape='rect')
                previous=self.container;self.container=id+f'_cell{j}'
                if text=='…':self.txt(id+f'_txt{j}',text,x+j*80+40,y+39,37,center=True)
                else:self.math(id+f'_txt{j}',[('λ',text,'')],x+j*80+40,y+37,39,center=True,color=TEAL)
                self.container=previous

    def rollout(self,id,x,y,w):
        with self.module(id):
            for row in range(2):
                for j in range(4):
                    cx=x+j*w/3;cy=y+row*65
                    if j<3:self.line(f'{id}_r{row}_e{j}',[cx+17,cy],[cx+w/3-17,cy],GRAY,2,True)
                    self.shape(f'{id}_r{row}_n{j}',[cx-13,cy-13,26,26],PALE,TEAL,1.8,'ellipse')

    def policy_formula(self,id,x,y,size=44):
        with self.module(id):
            self.math(id+'_numerator',[('A','r',''),' − ',('∑','k',''),' ',('λ','k',''),('A','c_k','')],x,y,size,center=True)
            self.line(id+'_bar',[x-190,y+18],[x+190,y+18],INK,1.8)
            self.math(id+'_denominator',['1 + ',('∑','k',''),' ',('λ','k','')],x,y+49,size,center=True)

    def write(self):
        scene={'version':1,'slide_width_inches':5.5,'slides':[{'id':'page_001','width':self.w,'height':self.h,
               'source':'pages/page_001/source.png','background':WHITE,'reviewed':True,
               'notes':'T-1624 semantic reconstruction; generated sketches are visual references. All visible objects native. Formulas are grouped native text/lines, not OMML. Graphs schematic.',
               'elements':self.elements,'groups':self.groups}]}
        save(self.dest/'scene.json',scene)
        save(self.dest/'appearance-plan.json',{'version':1,'regions':[
            {'id':'white_page','slide':'page_001','roi':[2,2,5,5],'kind':'solid','mode':'target','target_color':WHITE,'reason':'User requested consistent white paper background.'},
            {'id':'pale_teal_structure','slide':'page_001','roi':([430,620,6,6] if self.number==1 else [int(480*self.scale),int(28*self.scale),6,6]),'actual_roi':([int(400*self.scale),int(195*self.scale),6,6] if self.number==1 else [int(480*self.scale),int(28*self.scale),6,6]),'kind':'solid','mode':'target','target_color':PALE,'reason':'User requested one consistent, flat pale-teal structural fill. Source and actual ROIs locate their respective pale structure after intentional layout changes.'}]})
        save(self.dest/'typography.json',self.type)
        save(self.dest/'redraw-changes.json',{'source':f'Figure{self.number}_v02.png',
             'baseline':'Unmodified generated reference plus preserved 20260923 editable baseline.',
             'intentional_changes':['Uniform source-measured font family and type tiers','Flat common teal/slate palette','Reduced repeated subtitles and oversized headings','Rebuilt schematic graph and constraint motifs','Source-correct endpoint statements and independent GAE route','Paper-scale native edit groups'],
             'scientific_source':'iclr_2027_v2/sections_safeot_dual/03_exact_pricing.tex and 04_algorithm.tex',
             'fidelity':'Semantic redesign, not pixel-faithful tracing; sources retained unchanged.',
             'remaining_raster_elements':0,'formula_type':'Grouped native text parts and lines, not Office Math',
             'renderer_limits':'LibreOffice verified; PowerPoint/WPS rendering requires user application check.'})
        print(json.dumps({'scene':str(self.dest/'scene.json'),'elements':len(self.elements),'groups':len(self.groups)}))

def figure1(d):
    h=d.height
    d.txt('hero_title','SafeOT-Dual: one price rule, two views',1000,60,48,True,color=TEAL,center=True)
    d.route('unifying_bracket',[[190,108],[190,84],[1810,84],[1810,108]],GRAY,1.8,False)
    with d.module('penalty_view',[24,112,337,610],WHITE,LINE):
        d.txt('penalty_header','Penalty view',192,165,45,True,center=True)
        d.math('penalty_objective',[('max','π',''),' ',('J','r',''),'(π)'],192,222,40,center=True)
        d.math('penalty_cost',['− ',('λ','','T'),('J','c',''),'(π)'],192,270,40,center=True)
        d.line('penalty_rule',[50,294],[335,294],LINE,1.5)
        d.txt('exact_settings','Exact settings',192,342,39,True,center=True)
        d.math('zero_clip',['c = 0'],192,388,39,center=True)
        d.txt('fixed_label','Fixed β',192,454,40,True,center=True)
        d.txt('fixed_text','fixed penalty',192,500,37,center=True)
        d.math('fixed_equation',['λ = β'],192,545,42,center=True)
        d.line('left_split',[75,570],[310,570],LINE,1.3)
        d.txt('adaptive_label','Adaptive β',192,628,40,True,center=True)
        d.txt('adaptive_text','Lagrangian feedback',192,677,37,center=True)
    with d.module('shared_construction',[391,112,1218,610],PALE,TEAL,2.2):
        d.txt('joint_header','Joint',535,162,40,True,color=TEAL,center=True)
        d.txt('joint_header2','constraints',535,205,40,True,color=TEAL,center=True)
        for j,k in enumerate(['1','2','…','K']):
            y=243+j*70
            with d.module(f'budget_row_{j}',[422,y,225,57],WHITE,LINE,1.4):
                if k=='…':d.txt('budget_dots','…',535,y+38,38,center=True)
                else:d.math('budget_'+k,[('C',k,''),' ,  ',('b',k,'')],535,y+39,40,center=True)
        d.txt('hard_header','Hard support H',535,577,37,True,center=True)
        with d.module('hard_edge'):
            d.line('hard_edge_left',[466,617],[514,617],GRAY,2.2)
            d.line('hard_edge_right',[548,617],[604,617],GRAY,2.2)
            d.shape('hard_node_a',[438,605,24,24],WHITE,GRAY,1.6,'ellipse')
            d.shape('hard_node_b',[608,605,24,24],WHITE,GRAY,1.6,'ellipse')
            d.line('hard_cross_a',[518,606],[540,628],INK,3)
            d.line('hard_cross_b',[518,628],[540,606],INK,3)
            d.join('hard_cross_b','hard_cross_a','Two native strokes form the hard-support exclusion symbol.')
        d.math('hard_zero',[('F','H',''),' = 0'],535,679,40,center=True)
        d.line('central_divider1a',[677,207],[677,340],LINE,1.3)
        d.line('central_divider1b',[677,369],[677,681],LINE,1.3)
        d.txt('graph_header','One graph problem',909,175,40,True,color=TEAL,center=True)
        d.graph('shared_graph',738,264,340,178)
        d.math('graph_obj1',[('min','F',''),' − ⟨A,F⟩'],909,512,41,center=True)
        d.math('graph_obj2',['+ ε KL(F ∥ F̂)'],909,564,41,center=True)
        d.txt('balance','flow balance',909,616,37,center=True)
        d.math('soft_budget',[('⟨C','k',''),',F⟩ ≤ ',('b','k','')],909,666,39,center=True)
        d.line('central_divider2a',[1137,207],[1137,340],LINE,1.3)
        d.line('central_divider2b',[1137,369],[1137,681],LINE,1.3)
        d.txt('price_header','Shared safety price',1373,175,40,True,color=TEAL,center=True)
        d.math('solver_price',[('λ','','*')],1369,250,44,center=True,color=TEAL)
        d.line('price_into_filter',[1372,269],[1372,294],TEAL,2.2,True)
        with d.module('filter_operator',[1190,297,365,83],WHITE,LINE,1.7):
            d.txt('filter_label','Clip + filter',1372,351,39,True,center=True)
        d.line('filter_down',[1372,384],[1372,421],TEAL,2.2,True)
        d.math('unified_price',[('λ','k',''),' = ',('λ̄','k','*'),' + ',('β','k','')],1372,474,46,center=True,color=TEAL)
        d.txt('graph_price_text','graph price',1264,537,37,center=True)
        d.txt('feedback_text','feedback',1480,537,37,center=True)
        d.prices('shared_vector',1213,591)
    with d.module('constraint_view',[1639,112,337,610],WHITE,LINE):
        d.txt('constraint_header','Constraint view',1807,165,45,True,center=True)
        d.math('constraint_objective',[('max','π',''),' ',('J','r',''),'(π)'],1807,222,40,center=True)
        d.math('constraint_budget',['s.t. ',('J','c',''),'(π) ≤ B'],1807,270,40,center=True)
        d.line('constraint_rule',[1664,294],[1950,294],LINE,1.5)
        d.txt('limit_header','Graph-price limits',1807,343,38,True,center=True)
        d.txt('limit_qualifier','under assumptions',1807,388,37,center=True)
        d.math('epsilon_zero',['ε → 0'],1807,454,43,center=True)
        d.txt('lp_price','LP-derived price',1807,502,37,center=True)
        d.line('right_split',[1690,538],[1925,538],LINE,1.3)
        d.math('epsilon_infty',['ε → ∞'],1807,603,43,center=True)
        d.txt('active_price','clipped active-set',1807,650,37,center=True)
        d.txt('active_price_suffix','price',1807,690,37,center=True)
    # Draw external connectors after groups, with exact boundary ports.
    d.container='shared_construction_panel'
    d.line('joint_to_graph',[651,354],[715,354],TEAL,2.5,True)
    d.line('graph_to_price',[1102,354],[1184,354],TEAL,2.5,True)
    d.container=None
    d.route('one_price_to_update',[[1373,725],[1373,758],[1030,758],[1030,792]],TEAL,2.4)
    with d.module('common_policy',[24,795,1952,h-815],PALE,LINE):
        d.txt('common_update_label','One policy-update rule',268,854,44,True,color=TEAL,center=True)
        d.line('update_separator',[535,815],[535,h-37],LINE,1.6)
        d.math('common_advantage',[('Ã','',''),' = (',('A','r',''),' − ',('∑','k',''),' ',('λ','k',''),('A','c_k',''),') / (1 + ',('∑','k',''),' ',('λ','k',''),')'],1073,856,42,center=True)
        d.line('update_to_algorithm',[1545,846],[1600,846],TEAL,2.2,True)
        d.txt('common_optimizer','PPO / TRPO',1790,857,42,True,color=TEAL,center=True)

def figure2(d):
    h=d.height
    d.shape('graph_band',[18,18,1964,529],PALE,LINE,1.5,background=True)
    d.shape('policy_band',[18,579,1964,h-597],SOFT,LINE,1.5,background=True)
    d.txt('graph_band_title','Graph-space price construction',52,72,44,True,color=TEAL)
    d.txt('policy_band_title','Policy-space learning',52,629,44,True)
    with d.module('empirical_graph',[45,118,370,360],WHITE,LINE):
        d.txt('empirical_heading','Empirical graph',230,169,42,True,center=True)
        d.graph('rollout_graph',86,231,288,131,GRAY)
        d.math('empirical_values',['F̂, A, ',('C','k','')],230,428,41,center=True)
    with d.module('joint_solver',[467,118,1002,360],WHITE,TEAL,2):
        d.txt('joint_solver_heading','Joint budget solve',965,169,43,True,color=TEAL,center=True)
        for j,k in enumerate(['1','2','K']):
            x=503+j*147
            with d.module('solver_cost'+str(j),[x,197,130,48],PALE,LINE,1.2):
                d.math('solver_cost_math'+str(j),[('C',k,''),', ',('b',k,'')],x+65,230,35,center=True)
        d.math('rate_budget',[('b','k',''),' = ',('B','k',''),'/L'],1129,228,37,center=True)
        d.math('support_zero',[('F','H',''),' = 0'],1350,228,37,center=True)
        d.line('joint_horizontal',[493,265],[1443,265],LINE,1.5)
        d.txt('primal_label','Entropic flow problem',730,309,37,True,center=True)
        d.math('primal_objective',[('min','F',''),' − ⟨A,F⟩ + ε KL(F ∥ F̂)'],737,369,37,center=True)
        d.txt('solver_balance','flow balance',633,425,35,center=True)
        d.math('solver_constraint',[('⟨C','k',''),',F⟩ ≤ ',('b','k','')],851,425,35,center=True)
        d.line('joint_vertical_a',[992,286],[992,365],LINE,1.4)
        d.line('joint_vertical_b',[992,394],[992,451],LINE,1.4)
        d.txt('dual_label','Dual solver',1222,309,37,True,center=True)
        d.txt('u_solve','Newton in u',1218,365,37,center=True)
        d.txt('lambda_solve','Bisection in λ',1218,425,37,center=True)
        d.line('primal_to_dual',[962,379],[1021,379],TEAL,2,True)
    with d.module('clip_filter',[1525,118,430,360],WHITE,LINE):
        d.txt('clip_heading','Clip + filter',1740,169,42,True,center=True)
        d.math('clip_equation',[('λ̄','','*'),' ← (1−α)',('λ̄','','*')],1740,231,39,center=True)
        d.math('clip_equation2',['+ α clip(',('λ','','*'),',0,c)'],1740,279,39,center=True)
        # Analytical piecewise-linear clipping operator, not measured evidence.
        d.line('clip_xaxis',[1610,419],[1894,419],GRAY,1.6,True)
        d.line('clip_yaxis',[1610,419],[1610,310],GRAY,1.6,True)
        d.join('clip_yaxis','clip_xaxis','The two axes meet at the clipping schematic origin.')
        d.route('clip_function',[[1610,419],[1780,328],[1869,328]],TEAL,3,False)
        d.join('clip_function_0','clip_xaxis','The clipping curve starts at its analytic origin.')
        d.join('clip_function_0','clip_yaxis','The clipping curve starts at its analytic origin.')
        d.math('clip_cap',['c'],1579,341,35,center=True)
        d.math('clip_input',[('λ','','*')],1878,454,35,center=True)
    # Source/data and price-transfer connectors.
    d.line('graph_into_solver',[420,332],[461,332],GRAY,2.2,True)
    d.line('solver_into_filter',[1475,332],[1519,332],TEAL,2.5,True)
    d.math('lambda_star_label',[('λ','','*')],1498,307,36,center=True,color=TEAL)
    d.txt('price_boundary','Only prices enter the policy update',1000,565,37,italic=True,color=TEAL,center=True)
    with d.module('policy_rollout',[45,661,370,186],WHITE,LINE):
        d.txt('rollout_heading','Policy rollout',230,706,42,True,center=True)
        d.rollout('batch',100,750,254)
    with d.module('cost_feedback',[700,688,552,154],WHITE,LINE):
        d.txt('feedback_heading','Cost feedback',976,731,40,True,center=True)
        d.math('feedback_rule',['β ← [β + η(J̄ − B)',(']','+','')],976,793,39,center=True)
    with d.module('policy_update',[1560,661,395,204],WHITE,TEAL,1.9):
        d.txt('policy_heading','One priced update',1757,707,40,True,center=True)
        d.policy_formula('normalized_advantage',1757,750,36)
        d.txt('optimizer','PPO / TRPO',1757,848,37,True,color=TEAL,center=True)
    # GAE bypass travels underneath the feedback block and enters a separate bottom port.
    d.route('gae_bypass',[[420,807],[478,807],[478,891],[1688,891],[1688,870]],GRAY,2.1)
    d.math('gae_label',['GAE: ',('A','r',''),', ',('A','c','')],980,933,37,center=True)
    d.route('data_to_graph',[[40,713],[29,713],[29,510],[230,510],[230,483]],GRAY,2.1)
    d.txt('transition_label','transitions + costs',430,526,37)
    d.line('episode_costs',[420,766],[694,766],GRAY,2.1,True)
    d.math('episode_cost_label',['Episode J̄'],552,743,37,center=True)
    # Filtered graph price and feedback are the only two inputs to the price junction.
    d.route('graph_price_transfer',[[1740,483],[1740,600],[1410,600],[1410,740]],TEAL,2.8)
    d.math('barlambda_label',[('λ̄','','*')],1450,715,37,center=True,color=TEAL)
    d.line('beta_into_plus',[1258,776],[1364,776],GRAY,2.1,True)
    d.math('beta_label',['β'],1310,751,38,center=True)
    with d.module('price_sum'):
        d.shape('plus_circle',[1373,741,74,74],WHITE,TEAL,1.9,'ellipse')
        d.container='plus_circle'
        d.txt('plus_symbol','+',1410,792,43,center=True)
        d.container=None
    d.line('lambda_into_update',[1452,778],[1554,778],TEAL,2.5,True)
    d.math('lambda_total_label',['λ'],1500,754,38,center=True,color=TEAL)
    d.math('policy_next',[('π','t+1','')],1860,911,37,center=True)
    # Separate outer policy return; it never passes through the feedback computation.
    d.route('next_rollout',[[1931,870],[1931,h-28],[210,h-28],[210,852]],GRAY,2.1)
    d.txt('next_rollout_label','next rollout',1280,h-41,35,center=True)

def main():
    p=argparse.ArgumentParser();p.add_argument('figure',type=int,choices=[1,2]);p.add_argument('--out',required=True)
    args=p.parse_args();d=Drawing(args.figure,Path(args.out).resolve())
    (figure1 if args.figure==1 else figure2)(d)
    d.write()

if __name__=='__main__': main()
