from pathlib import Path
import sys,json,copy,math
import matplotlib as mpl
import matplotlib._mathtext as mt
from matplotlib.mathtext import MathTextParser
from matplotlib.font_manager import FontProperties
from pptx import Presentation
from pptx.util import Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_CONNECTOR
from lxml import etree
sys.path.append(str(Path(__file__).resolve().parents[2]/'image_pipeline_20260925/runtime-venv/lib/python3.12/site-packages'))
from super_img2ppt.native import equation,M
R=Path(__file__).resolve().parents[1];J=R/'conversion/f02_selected/native_r1'
mt.SHRINK_FACTOR=.82;mt.GROW_FACTOR=1/.82
mpl.rcParams.update({'mathtext.fontset':'custom','mathtext.rm':'Liberation Serif','mathtext.it':'Liberation Serif:italic','mathtext.bf':'Liberation Serif:bold','mathtext.sf':'Liberation Sans','mathtext.tt':'Liberation Mono','mathtext.fallback':'stix'})
P=MathTextParser('path')
def latex(e):
 if isinstance(e,str):
  if e=='':return '{}'
  trans={'λ':r'\lambda ','β':r'\beta ','π':r'\pi ','η':r'\eta ','ε':r'\varepsilon ','∑':r'\sum ','⟨':r'\langle ','⟩':r'\rangle ','≤':r'\leq ','≥':r'\geq ','→':r'\to ','←':r'\leftarrow ','−':'-','∥':r'\Vert '}
  if any(c.isalpha() and c.isascii() for c in e) and len(e)>1:
   # words are upright; mixed expressions remain math.
   for word in ['adaptive','fixed','finite','min','KL']:
    if word in e:e=e.replace(word,'@'+word+'@')
  s=''.join(trans.get(c,c) for c in e)
  import re
  return re.sub(r'@(\w+)@',r'\\mathrm{\1}',s)
 if isinstance(e,list):return ''.join(latex(x) for x in e)
 if 'accent'in e:return ('\\overline' if e['accent']=='bar' else '\\widetilde')+'{'+latex(e['value'])+'}'
 if 'hat'in e:return '\\hat{'+latex(e['hat'])+'}'
 if 'num'in e:return '\\dfrac{'+latex(e['num'])+'}{'+latex(e['den'])+'}'
 if 'base'in e:return '{'+latex(e['base'])+'}'+('_{'+latex(e['sub'])+'}' if 'sub'in e else '')+('^{'+latex(e['sup'])+'}' if 'sup'in e else '')
 return latex(e['text'])
N=int(sys.argv[1]);root=J/f'figure{N}';prs=Presentation(root/('build02' if N==1 else 'build03')/'editable.pptx');sl=prs.slides[0]
source_math=Presentation(root/'math01'/f'Figure{N}.pptx');srcmath={s.name:s for s in source_math.slides[0].shapes if s.name in {m['id'] for m in json.loads((root/'math.json').read_text())}}
rows=[]
for m in json.loads((root/'math.json').read_text()):
 if m['id']=='priced_label':m['size']=11.5
 if N==2 and m['id']=='lambda_out':
  m['expression']=[{'base':'λ','sub':'k'},'=',{'base':{'accent':'bar','value':'λ'},'sub':'k','sup':'*'},'+',{'base':'β','sub':'k'}];m['box']=[145,174,61,17];m['size']=10.7
 if N==2 and m['id']=='advantage':m['box']=[214,166,94,30]

 text=latex(m['expression']);v=P.parse('$'+text+'$',dpi=72,prop=FontProperties(size=m['size']))
 x,y,w,h=m['box'];x0=x+(w-float(v.width))/2;baseline=y+(h-float(v.height))/2+float(v.height-v.depth)
 group=sl.shapes.add_group_shape();group.name=m['id']+'_compat'
 for idx,(font,size,char,gx,gy) in enumerate(v.glyphs):
  import numpy as np
  from matplotlib.ft2font import LoadFlags
  from pptx.enum.shapes import MSO_SHAPE
  from pptx.oxml.xmlchemy import OxmlElement
  font.set_size(size,72);font.load_char(char,flags=LoadFlags.NO_HINTING);verts,codes=font.get_path()
  if not len(verts):continue
  # Font outlines remain native editable PowerPoint freeforms, without Unicode combining-glyph substitution.
  xx=x0+gx+verts[:,0];yy=baseline-gy-verts[:,1]
  visible=codes!=79
  xmin=float(xx[visible].min());xmax=float(xx[visible].max());ymin=float(yy[visible].min());ymax=float(yy[visible].max())
  ew=max(.02,xmax-xmin);eh=max(.02,ymax-ymin)
  sh=group.shapes.add_shape(MSO_SHAPE.RECTANGLE,Pt(xmin),Pt(ymin),Pt(ew),Pt(eh));sh.name=f'{m["id"]}_glyph_{idx}'
  sp=sh._element.spPr
  for g in list(sp):
   if g.tag.endswith('prstGeom'):sp.remove(g)
  geom=OxmlElement('a:custGeom')
  for tag in ['avLst','gdLst','ahLst','cxnLst']:geom.append(OxmlElement('a:'+tag))
  rect=OxmlElement('a:rect');rect.set('l','0');rect.set('t','0');rect.set('r','r');rect.set('b','b');geom.append(rect)
  pl=OxmlElement('a:pathLst');path=OxmlElement('a:path');path.set('w',str(round(ew*12700)));path.set('h',str(round(eh*12700)))
  i=0
  while i<len(codes):
   code=int(codes[i])
   if code==79:path.append(OxmlElement('a:close'));i+=1;continue
   tag,count={1:('moveTo',1),2:('lnTo',1),3:('quadBezTo',2),4:('cubicBezTo',3)}[code]
   node=OxmlElement('a:'+tag)
   for j in range(count):
    pt=OxmlElement('a:pt');pt.set('x',str(round((float(xx[i+j])-xmin)*12700)));pt.set('y',str(round((float(yy[i+j])-ymin)*12700)));node.append(pt)
   path.append(node);i+=count
  pl.append(path);geom.append(pl);sp.insert(1,geom);sp.append(OxmlElement('a:effectLst'));sh.fill.solid();sh.fill.fore_color.rgb=RGBColor.from_string(m['color'][1:]);sh.line.fill.background()
 for idx,(rx,ry,rw,rh) in enumerate(v.rects):
  from pptx.enum.shapes import MSO_SHAPE
  sh=group.shapes.add_shape(MSO_SHAPE.RECTANGLE,Pt(x0+rx),Pt(baseline-ry-rh),Pt(max(rw,.1)),Pt(max(rh,.12)));sh.name=m['id']+'_rule'+str(idx);sh.fill.solid();sh.fill.fore_color.rgb=RGBColor.from_string(m['color'][1:]);sh.line.fill.background();sh._element.spPr.append(OxmlElement('a:effectLst'))
 # Keep the source OMML in an AlternateContent choice. LibreOffice 7.3 uses the fully-native glyph fallback.
 MC='http://schemas.openxmlformats.org/markup-compatibility/2006';A16='http://schemas.microsoft.com/office/drawing/2014/main'
 alt=etree.Element('{'+MC+'}AlternateContent',nsmap={'mc':MC,'a16':A16});choice=etree.SubElement(alt,'{'+MC+'}Choice',Requires='a16');temp=Presentation();ts=temp.slides.add_slide(temp.slide_layouts[6]);marks=[]
 def cv(e):
  if isinstance(e,list):return [cv(x) for x in e]
  if isinstance(e,dict):
   if 'accent'in e:marks.append(e['accent']);return {'hat':cv(e['value'])}
   if 'hat'in e:marks.append('hat');return {'hat':cv(e['hat'])}
   return {k:cv(v) for k,v in e.items()}
  return e
 eq=equation(ts,[round(v*12700) for v in m['box']],cv(m['expression']),m['size'],m['color'],'Liberation Serif',m['id'])
 for node,kind in zip(eq._element.findall(f'.//{{{M}}}accPr/{{{M}}}chr'),marks):node.set(f'{{{M}}}val',{'hat':'\u0302','bar':'\u0304','tilde':'\u0303'}[kind])
 choice.append(copy.deepcopy(eq._element));fall=etree.SubElement(alt,'{'+MC+'}Fallback');el=group._element;parent=el.getparent();idx=parent.index(el);parent.remove(el);fall.append(el);parent.insert(idx,alt)
 rows.append(dict(id=m['id'],latex=text,glyph_min_pt=min(g[1] for g in v.glyphs),render_box=[x0,baseline-float(v.height-v.depth),float(v.width),float(v.height)],semantic_omml=True,compatibility_native_glyphs=True))
if N==2:
 for sh in sl.shapes:
  if sh.name=='price_to_adv':sh.left=Pt(208);sh.width=Pt(6)
props=prs.core_properties;props.author='';props.last_modified_by='';props.title=f'SafeOT Figure {N}';props.subject='';props.comments='';props.keywords=''
out=root/'compat04';out.mkdir(exist_ok=True);prs.save(out/f'Figure{N}.pptx');(out/'formula_audit.json').write_text(json.dumps(rows,indent=2));print(out)
