from pathlib import Path
import json,math,sys,shutil,hashlib,subprocess
from PIL import Image
from pptx import Presentation
from pptx.util import Pt
from lxml import etree
from super_img2ppt.native import equation, M
from super_img2ppt.render import make_renderer, rasterize_pdf
from super_img2ppt.math_layout import calibrate_equations
R=Path(__file__).resolve().parents[1]
J=R/'conversion/f02_selected'
OUT=J/'native_r1'
OUT.mkdir(exist_ok=True)
TEAL='#087F8C'; TF='#EAF6F5'; GRAY='#66747D'; GF='#F3F5F6'; INK='#24343D'; LIGHT='#A6B1B7'; ORANGE='#BA5B20'; OF='#FCF1E7'; PURPLE='#73539B'; RED='#AD3C3C'
SCALE=5

def sub(b,s):return {'base':b,'sub':s}
def sup(b,s):return {'base':b,'sup':s}
def ss(b,s,t):return {'base':b,'sub':s,'sup':t}
def hat(b):return {'hat':b}
def bar(b):return {'accent':'bar','value':b}
def tilde(b):return {'accent':'tilde','value':b}
lk=sub('λ','k'); ls=ss('λ','k','*'); lbs=ss(bar('λ'),'k','*'); beta=sub('β','k'); jk=sub(bar('J'),'k'); bk=sub('b','k'); Bk=sub('B','k'); fh=hat('F'); fs=sup('F','*'); ar=sub(hat('A'),'r'); ac=sub(hat('A'),sub('c','k')); priced=[tilde('A'),'=',{'num':[ar,'−',sub('∑','k'),lk,ac],'den':['1+',sub('∑','k'),lk]}]

def convert_acc(expr,marks):
 if isinstance(expr,list):return [convert_acc(x,marks) for x in expr]
 if isinstance(expr,dict):
  if 'accent' in expr:
   marks.append(expr['accent']);return {'hat':convert_acc(expr['value'],marks)}
  if 'hat' in expr:
   marks.append('hat');return {'hat':convert_acc(expr['hat'],marks)}
  return {k:convert_acc(v,marks) for k,v in expr.items()}
 return expr

class Fig:
 def __init__(self,n,H): self.n=n;self.H=H;self.e=[];self.math=[];self.groups=[];self.group=None;self.ids=[]
 def add(self,k,id,**kw):
  o=dict(id=id,kind=k,z=len(self.e)+1,**kw)
  if self.group and k!='line' and id!=self.group:o['container']=self.group
  self.e.append(o);return id
 def box(self,id,x,y,w,h,fill=GF,stroke=LIGHT,round=True):return self.add('shape',id,box=[v*SCALE for v in [x,y,w,h]],shape='round_rect' if round else 'rect',radius=3*SCALE,fill=fill,stroke=stroke,stroke_width=.6*SCALE)
 def text(self,id,t,x,y,w,h=10,size=7.5,bold=False,color=INK,align='left'):
  return self.add('text',id,box=[v*SCALE for v in [x,y,w,h]],text=t,font_family='Liberation Serif',font_size=size*SCALE,bold=bold,color=color,align=align,valign='middle',fit='strict',wrap=False)
 def eq(self,id,e,x,y,w,h=15,size=11,color=INK):self.math.append(dict(id=id,expression=e,box=[x,y,w,h],size=size,color=color,group=self.group))
 def line(self,id,x1,y1,x2,y2,color=GRAY,width=.8,arrow=False,dash=None):
  kw=dict(points=[[x1*SCALE,y1*SCALE],[x2*SCALE,y2*SCALE]],stroke=color,stroke_width=width*SCALE)
  if arrow:kw.update(arrow=True,arrow_head={'length':min(3.5,math.hypot(x2-x1,y2-y1)*.8)*SCALE,'width':2.8*SCALE})
  if dash:kw['dash']=[x*SCALE for x in dash]
  return self.add('line',id,**kw)
 def path(self,id,pts,color=GRAY,width=.8,arrow=False,dash=None):
  for i,(a,b) in enumerate(zip(pts,pts[1:])):
   if a==b:continue
   self.line(id+'_'+str(i),*a,*b,color,width,arrow and i==len(pts)-2,dash)
 def module(self,id,x,y,w,h,title,teal=False,size=9):
  self.group=None;self.box(id,x,y,w,h,TF if teal else GF,TEAL if teal else LIGHT);self.group=id;self.text(id+'_title',title,x+5,y+3,w-10,max(12,size*1.2),size,True,TEAL if teal else INK,'center')
 def graph(self,id,x,y,w,h,mode='observed',hard=False,overlay=False):
  nodes=[(x,y+h*.5),(x+w*.27,y),(x+w*.73,y),(x+w,y+h*.5),(x+w*.73,y+h),(x+w*.27,y+h)]
  edges=[(0,1),(1,2),(2,3),(0,5),(5,4),(4,3)]
  for j,(a,b) in enumerate(edges):
   ax,ay=nodes[a];bx,by=nodes[b];dx=bx-ax;dy=by-ay;d=math.hypot(dx,dy);ux=dx/d;uy=dy/d;nx=-uy;ny=ux
   if overlay:
    for off,col,th in [(-1.4,LIGHT,.7),(1.4,TEAL,1.8 if j>=3 else .9)]:
     self.line(f'{id}_edge_{j}_{off}',ax+ux*4+nx*off,ay+uy*4+ny*off,bx-ux*4+nx*off,by-uy*4+ny*off,col,th,True)
   else:self.line(f'{id}_edge_{j}',ax+ux*4,ay+uy*4,bx-ux*4,by-uy*4,TEAL if mode=='target' and j>=3 else GRAY,1.8 if (mode=='target' and j>=3) else .7,True)
  if hard:
   ax,ay=nodes[1];bx,by=nodes[4];self.line(id+'_hard',ax+4,ay+4,bx-4,by-4,RED,.7,False,[2,2]);cx=(ax+bx)/2;cy=(ay+by)/2
   self.line(id+'_x1',cx-3,cy-3,cx+3,cy+3,RED,1.3);self.line(id+'_x2',cx-3,cy+3,cx+3,cy-3,RED,1.3)
  for j,(a,b) in enumerate(nodes):self.add('shape',id+'_node'+str(j),box=[(a-3.5)*SCALE,(b-3.5)*SCALE,7*SCALE,7*SCALE],shape='ellipse',fill='#FFFFFF',stroke=GRAY,stroke_width=.7*SCALE)
 def trace(self,id,roi,x,y,w,h,color,src_color,exclude=None):
  # Measured source pixels, never fitted to a synthetic function. Source is schematic.
  im=Image.open(J/'pages/page_001/source.png').convert('RGB');rx,ry,rw,rh=roi
  pts=[]
  for xx in range(rw):
   ys=[]
   for yy in range(rh):
    if exclude and any(ex<=xx+rx<ex+ew and ey<=yy+ry<ey+eh for ex,ey,ew,eh in exclude):continue
    c=im.getpixel((xx+rx,yy+ry))
    if sum((a-b)**2 for a,b in zip(c,src_color))<38**2:ys.append(yy)
   if ys:pts.append((x+xx/rw*w,y+ys[len(ys)//2]/rh*h))
  # retain every 3 source pixels plus extrema; this is a traced polyline, not an experimental curve.
  pts=pts[::3]+pts[-1:]
  self.path(id,pts,color,.8)
  return pts
 def save(self):
  self.group=None
  # Named intentional layer intersections. Each module is a pale background; graph junctions and plot guides are intentional.
  # Avoid hiding text collisions. Only non-text geometry with actual intersecting bounds is eligible.
  def bounds(e):
   if 'box'in e:return list(e['box'])
   p=e['points'];return [min(q[0] for q in p),min(q[1] for q in p),abs(p[1][0]-p[0][0]),abs(p[1][1]-p[0][1])]
  for e in self.e:
   if e['kind']=='line':continue
   x,y,w,h=e['box'];candidates=[]
   for sh in self.e:
    if sh['kind']!='shape' or sh['z']>=e['z'] or sh['shape']=='ellipse':continue
    a,b,c,d=sh['box']
    if a<=x and b<=y and x+w<=a+c and y+h<=b+d:candidates.append((c*d,sh['id']))
   if candidates:e['container']=min(candidates)[1]
  for e in self.e:
   if e['id']=='sum_sign':e['container']='sum'
  for i,a in enumerate(self.e):
   for b in self.e[:i]:
    if a['kind']=='text' or b['kind']=='text':continue
    if a.get('container')==b['id'] or b.get('container')==a['id']:continue
    ba=bounds(a);bb=bounds(b)
    for e0,bb0 in [(a,ba),(b,bb)]:
     margin=e0.get('stroke_width',0)/2+ (3*SCALE if e0.get('arrow') else 0)
     bb0[:]=[bb0[0]-margin,bb0[1]-margin,bb0[2]+2*margin,bb0[3]+2*margin]
    if ba[0]<=bb[0]+bb[2] and bb[0]<=ba[0]+ba[2] and ba[1]<=bb[1]+bb[3] and bb[1]<=ba[1]+ba[3]:
     a.setdefault('allow_overlap_with',[]).append(b['id']);a['overlap_reason']='Source-verified graph junction, schematic curve/guide crossing, or module background layer; text is never exempted.'
  scene={'version':1,'title':f'SafeOT Figure {self.n}','slide_width_inches':5.5,'slides':[{'id':f'figure{self.n}','width':1980,'height':int(self.H*SCALE),'background':'#FFFFFF','reviewed':True,'notes':'Semantic redraw of selected F02. Original raster preserved separately. Module layout retained; mentor 14:25Z corrections applied. No experiment data.','elements':self.e}]}
  p=OUT/f'figure{self.n}';p.mkdir(exist_ok=True);(p/'scene.json').write_text(json.dumps(scene,indent=2));(p/'math.json').write_text(json.dumps(self.math,indent=2));return p

f=Fig(1,216)
f.module('penalty',3,3,83,144,'Fixed penalty')
f.text('leak','Budget leakage',9,22,70,12,8,True,RED,'center')
f.line('p_x',14,124,78,124,GRAY,.7,True);f.line('p_y',14,124,14,39,GRAY,.7,True)
f.line('p_B',15,85,77,85,GRAY,.7,False,[2,2]);f.text('p_budget','B',6,80,7,11,8,False)
f.trace('cost_penalty',(64,177,373,157),16,46,60,39,GRAY,(93,105,115));f.text('p_cost','cost',30,54,25,10,7.5)
f.line('p_price',16,111,76,111,PURPLE,.9,False,[3,2]);f.text('p_price_label','price',33,99,30,10,7.5,color=PURPLE)
f.text('p_training','training',25,130,50,10,7.5,align='center')
f.module('safeot',91,3,214,144,'SafeOT',True,12)
f.text('one_flow','One flow, all budgets',95,19,206,11,8.5,True,TEAL,'center')
f.graph('unified_graph',111,44,167,33,overlay=True,hard=True)
f.line('leg_observed',99,35,109,35,LIGHT,.7,True);f.eq('Fhat_legend',fh,112,30,12,12,10)
f.line('leg_target',134,35,144,35,TEAL,1.6,True);f.eq('Fstar_legend',fs,147,30,13,12,10)
f.eq('budget', ['⟨',sub('C','k'),',F⟩≤',bk],204,29,94,17,11)
f.text('graph_legend','nodes: clustered states · edges: transition flow',97,79,202,10,7.2,align='center')
f.box('projection',144,92,104,15,TEAL,TEAL);f.text('projection_text','Entropic projection',147,94,98,10,8.5,True,'#FFFFFF','center')
f.line('duals_down',194,108,194,121,TEAL,.8,True)
f.eq('raw_dual',ls,172,109,18,13,11,TEAL)
f.text('pre_violation','Can price before violation',202,109,98,12,8,True,TEAL)
f.text('filter','clip + EMA',174,124,44,10,7.2,align='center')
f.group=None
# Actor path on a separate strip in the center; the observed-cost branch has a small accent only.
f.box('price_rule',91,151,214,25,TF,TEAL)
f.text('feedback_label','feedback',95,155,31,9,7.2,color=ORANGE)
f.eq('feedback_cost',[jk,'−',Bk],94,163,38,12,10.7,ORANGE)
f.line('feedback_to_price',133,165,140,165,ORANGE,.8,True)
f.eq('price_sum',[lk,'=',lbs,'+',beta],143,154,74,20,11.5)
f.line('price_to_actor',220,165,246,165,GRAY,.8,True)
f.eq('priced_label',tilde('A'),225,151,16,13,10.7)
f.box('actor',249,155,41,16,GF,LIGHT);f.text('actor_text','PPO/TRPO',250,157,39,12,7.5,align='center')
f.line('actor_out',291,165,301,165,GRAY,.8,True)
f.line('filter_to_price',195,138,195,151,TEAL,.8,True)
f.module('lagrangian',310,3,83,144,'Lagrangian')
f.text('late','Late feedback',315,22,73,12,8,True,GRAY,'center')
f.line('l_x',321,124,386,124,GRAY,.7,True);f.line('l_y',321,124,321,39,GRAY,.7,True)
f.line('l_B',322,77,385,77,GRAY,.7,False,[2,2]);f.text('l_budget','B',313,72,7,11,8)
f.trace('lag_cost',(1390,256,385,136),323,58,62,32,GRAY,(91,102,114),[(1390,331,385,8)])
f.trace('lag_price',(1390,369,385,136),323,82,62,29,PURPLE,(107,62,163),[(1440,449,102,28),(1610,442,180,38)])
f.text('l_cost','cost',357,45,26,10,7.5);f.text('l_price','price',349,111,30,10,7.5,color=PURPLE)
f.text('l_training','training',329,130,52,10,7.5,align='center')
f.group=None
# Prominent categorical summary, not a numerical axis.
f.box('unification',3,182,390,32,'#F6FAFA',LIGHT)
f.text('rule_title','One price rule',7,154,77,13,9,True,TEAL,'center')
f.text('exact_title','Exact settings',7,170,78,10,7.5,True,GRAY,'center')
f.text('limits_title','Conditional limits',313,166,77,12,7.5,True,GRAY,'center')
f.line('exact_bracket',14,182,143,182,GRAY,.6);f.line('limit_bracket',248,182,386,182,GRAY,.6)
for id,title,x in [('fixed','Fixed penalty',9),('lag','Lagrangian',85),('ours','SafeOT',163),('lp','LP',239),('active','Active-set',314)]:
 f.text('u_'+id,title,x,185,73,11,8,True,TEAL if id=='ours' else INK,'center')
f.eq('u_fixed_eq',['c=0,',beta,' fixed'],8,198,77,13,10)
f.eq('u_lag_eq',['c=0,',beta,' adaptive'],83,198,84,13,10)
f.eq('u_safe_eq',['finite ε'],164,198,72,13,10)
f.eq('u_lp_eq',['ε→0'],240,198,72,13,10)
f.text('u_active_eq','saturated clip',315,199,74,11,7.4,align='center')
f.save()

f=Fig(2,215)
f.module('rollout',3,3,77,123,'1. Rollout')
f.eq('pi_t',sub('π','t'),28,22,23,16,11)
f.graph('rollout_graph',16,49,49,28)
f.text('rollout_label','Sample transitions',8,85,67,12,7.5,align='center')
f.text('GAE_label','Rollout + GAE',8,100,67,11,8,True,align='center')
f.eq('gae',[ar,', ',ac],11,111,61,13,11)
f.module('inputs',85,3,77,123,'2. Flow inputs')
f.graph('inputs_graph',97,45,53,29)
f.text('input_nodes','Clustered states',89,80,69,11,7.5,align='center')
f.text('input_edges','Transition flow',89,91,69,11,7.5,align='center')
f.eq('edge_inputs',[fh,', A, ',sub('C','k')],97,108,51,17,11)
f.module('budgets',167,3,83,123,'3. Constraints',size=8.7)
f.text('soft_title','Soft budgets',173,24,71,11,8,True,align='center')
f.eq('soft_eq',['⟨',sub('C','k'),',F⟩≤',bk],172,36,72,19,11)
f.graph('excluded_graph',181,64,54,29,hard=True)
f.eq('hard_eq',[sub('F','H'),'=0'],181,101,50,15,11)
f.text('hard_label','Hard exclusions',173,114,71,10,7.5,align='center')
f.module('projection',255,3,138,123,'4. SafeOT projection',True,9)
f.eq('objective',[sub('min','F≥0'),' −⟨A,F⟩+ε KL(F∥',fh,')'],260,24,128,22,10.7)
f.graph('before',268,58,44,24)
f.graph('after',336,58,44,24,mode='target',hard=True)
f.eq('before_F',fh,274,86,23,13,11);f.eq('after_F',fs,345,86,23,13,11)
f.line('reroute',314,70,330,70,TEAL,.9,True)
f.text('flow_balance','s.t. flow balance + constraints',261,43,126,10,7.2,align='center')
f.text('target_only','Target flow is not executed',260,104,128,11,7.5,True,TEAL,'center')
f.group=None
for id,x in [('a',80),('b',162),('c',250)]:f.line('top_'+id,x+.5,64,x+4.5,64,GRAY,.8,True)
# Full-width update band: feedback → sum → price → advantage → standard actor.
f.module('update',3,140,390,59,'5. Priced update',False,9)
# left-align title so top band carries graph price transfer.
f.e[-1]['box']=[8*SCALE,144*SCALE,89*SCALE,11*SCALE];f.e[-1]['align']='left'
f.text('observed','Observed episode costs',8,158,100,10,7.3,color=ORANGE)
f.eq('beta_update',[beta,'←[',beta,'+η(',jk,'−',Bk,')]',sub('','+')],8,173,101,19,10.7,ORANGE)
# replace empty base with full bracketed scripted expression
f.math[-1]['expression']=[beta,'←',sub(['[',beta,'+η(',jk,'−',Bk,')]'],'+')]
f.line('beta_to_sum',110,182,124,182,ORANGE,.8,True)
f.add('shape','sum',box=[126*SCALE,176*SCALE,12*SCALE,12*SCALE],shape='ellipse',fill='#FFFFFF',stroke=GRAY,stroke_width=.8*SCALE)
f.text('sum_sign','+',127,177,10,10,8,align='center')
f.line('sum_to_price',140,182,146,182,GRAY,.8,True)
f.eq('lambda_out',lk,149,174,19,17,11)
f.line('price_to_adv',169,182,180,182,GRAY,.8,True)
f.eq('advantage',priced,181,166,126,30,11.5)
f.line('adv_to_actor',309,182,321,182,GRAY,.8,True)
f.box('actor_step',323,171,42,23,GF,LIGHT);f.text('actor_step_text','PPO/TRPO',324,177,40,11,7.5,align='center')
f.line('actor_to_policy',366,182,373,182,GRAY,.8,True)
f.eq('pi_next',sub('π','t+1'),375,174,18,16,11)
f.group=None
# Precise data routing: GAE to priced advantage; realized costs only to feedback.
f.path('gae_route',[(42,127),(42,136),(122,136),(122,163),(304,163),(304,166)],GRAY,.7,True)
f.text('gae_arrow_label','advantages',66,127,53,9,7.2,align='center')
f.path('dual_in',[(326,127),(326,134),(288,134)],TEAL,.9,True)
f.box('filter_box',151,127,136,13,TF,TEAL)
f.eq('filter_raw',ls,263,127,19,14,11,TEAL)
f.line('raw_to_clip',260,134,245,134,TEAL,.8,True)
f.text('filter_text','clip + EMA',195,129,48,10,7.5,align='center')
f.line('clip_to_processed',192,134,179,134,TEAL,.8,True)
f.eq('filter_processed',lbs,154,127,23,14,11,TEAL)
f.path('processed_to_sum',[(150,134),(132,134),(132,174)],TEAL,.8,True)
f.text('dual_label','budget duals',333,128,58,10,7.2,color=TEAL)
f.path('cost_route',[(15,127),(15,133),(7,133),(7,175)],ORANGE,.7,True)
f.path('next_rollout',[(384,201),(384,209),(1,209),(1,64),(3,64)],GRAY,.7,True)
f.text('next_label','next rollout',172,200,54,9,7.2,align='center')
f.save()
print(OUT)
