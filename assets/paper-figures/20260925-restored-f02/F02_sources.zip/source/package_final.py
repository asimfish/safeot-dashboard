from pathlib import Path
import json,shutil,hashlib,zipfile
import fitz
from lxml import etree
R=Path(__file__).resolve().parents[1];F=R.parent/'final/history_unified_20260925';F.mkdir(parents=True,exist_ok=True)
reports=[]
for n in [1,2]:
 root=R/f'conversion/f02_selected/native_r1/figure{n}';src=root/'delivery';stem=f'Figure{n}_F02_editable'
 shutil.copy2(src/f'Figure{n}.pptx',F/(stem+'.pptx'))
 doc=fitz.open(src/f'render/Figure{n}.pdf');doc.set_metadata({});doc.del_xml_metadata();doc.save(F/(stem+'.pdf'),garbage=4,deflate=True)
 page=doc[0];page.get_pixmap(dpi=300).save(F/(stem+'_300dpi.png'));(F/(stem+'.svg')).write_text(page.get_svg_image(text_as_path=False))
 textspans=[s for b in page.get_text('dict')['blocks'] if 'lines'in b for l in b['lines'] for s in l['spans'] if s['text'].strip()]
 formula=json.loads((root/'compat04/formula_audit.json').read_text());minmath=min(x['glyph_min_pt'] for x in formula)
 with zipfile.ZipFile(F/(stem+'.pptx')) as z:
  xml=etree.fromstring(z.read('ppt/slides/slide1.xml'));ns={'p':'http://schemas.openxmlformats.org/presentationml/2006/main','m':'http://schemas.openxmlformats.org/officeDocument/2006/math','mc':'http://schemas.openxmlformats.org/markup-compatibility/2006'}
  raster=len(xml.findall('.//p:pic',ns));omml=len(xml.findall('.//m:oMath',ns));fallback=len(xml.findall('.//mc:Fallback/p:grpSp',ns))
 report={'figure':n,'width_in':page.rect.width/72,'height_in':page.rect.height/72,'minimum_pdf_text_pt':min(s['size'] for s in textspans),'minimum_math_source_glyph_pt':minmath,'math_size_measurement':'Font outline source size at 72dpi, scale 1; accents included. PDF math paths do not expose font size.','pptx_raster_objects':raster,'pdf_raster_objects':len(page.get_images()),'office_math_objects':omml,'native_formula_fallback_groups':fallback,'rendered_with':'LibreOffice 7.3.7.2, native-vector compatibility branch','powerpoint_render_verified':False,'svg_editability':'Text labels remain text; geometry and formula outlines are vector paths. Native Office Math is retained in the PPTX alternate branch.','status':'Candidate for visual review; no claim of cold-reader acceptance'}
 assert raster==0 and len(page.get_images())==0
 assert report['minimum_pdf_text_pt']>=7 and minmath>=7
 (F/f'Figure{n}_font_editability_report.json').write_text(json.dumps(report,indent=2));reports.append(report)
 shutil.copy2(root/'scene.json',F/f'Figure{n}_scene.json');shutil.copy2(root/'math.json',F/f'Figure{n}_math_source.json');shutil.copy2(root/'compat04/formula_audit.json',F/f'Figure{n}_formula_audit.json')
 doc.close()
(F/'DELIVERY.md').write_text('''# Selected F02 editable candidates

Both figures follow the selected S5 F02 modular compositions, with separate observed/target flow arrows, corrected raw/processed price routing, observed-cost feedback, and independent GAE-to-advantage routing. Figure 1 contains schematic curves only; no experiment data.

PPTX geometry, connectors and text are native editable objects, with zero raster objects. Formulas preserve Office Math in a compatibility branch and native vector glyph groups in the LibreOffice branch. The actual PNG/PDF previews were exported by LibreOffice. Microsoft PowerPoint rendering of the Office Math branch is not verified. SVG labels are text; formula glyphs are editable vector outlines, not SVG equation objects. External arrows do not reroute automatically.

Fonts: Liberation Serif for ordinary text; native math outlines preserve the measured symbol geometry. Reports distinguish actual PDF text measurements from the source sizes of outlined math. PDF/SVG export metadata is anonymous. These are review candidates, not a claim of cold-reader acceptance or manuscript integration.
''')
print(json.dumps(reports,indent=2))
