from pathlib import Path
import json,hashlib,zipfile
from PIL import Image,ImageOps
from pptx import Presentation
import fitz
from pypdf import PdfReader,PdfWriter
ROOT=Path(__file__).resolve().parent; raw=ROOT/'render/Figure2_3Stage_R1.pdf'
rd=PdfReader(str(raw));wr=PdfWriter();[wr.add_page(p) for p in rd.pages];wr.add_metadata({'/Title':'Figure 2 SafeOT three-stage framework','/Author':'','/Creator':'','/Producer':'','/Subject':''})
out=ROOT/'Figure2_3Stage_R1.pdf';out.write_bytes(b'');
with out.open('wb') as f:wr.write(f)
d=fitz.open(str(out)); page=d[0]; pix=page.get_pixmap(matrix=fitz.Matrix(300/72,300/72),alpha=False); png=ROOT/'Figure2_3Stage_R1_300dpi.png';pix.save(str(png));(ROOT/'Figure2_3Stage_R1.svg').write_text(page.get_svg_image(matrix=fitz.Matrix(1,1),text_as_path=1),encoding='utf-8')
im=Image.open(png).convert('RGB');ImageOps.grayscale(im).convert('RGB').save(ROOT/'Figure2_3Stage_R1_grayscale.png')
import numpy as np
arr=np.asarray(im).astype(float)/255
for label,m in {'deuteranopia':np.array([[.625,.375,0],[.70,.30,0],[0,.30,.70]]),'protanopia':np.array([[.567,.433,0],[.558,.442,0],[0,.242,.758]])}.items(): Image.fromarray((np.clip(arr@m.T,0,1)*255).astype('uint8')).save(ROOT/f'Figure2_3Stage_R1_{label}.png')
prs=Presentation(str(ROOT/'Figure2_3Stage_R1.pptx')); vals=[]; formulas=[]
def rec(sh):
 if hasattr(sh,'shapes'):
  for x in sh.shapes:rec(x)
 elif hasattr(sh,'text_frame'):
  for p in sh.text_frame.paragraphs:
   for r in p.runs:
    if r.text.strip() and r.font.size:
     vals.append(float(r.font.size.pt))
     if sh.name in {'rollout_label','cluster_label','observed_graph_label','budget_lbl','gae_label','gae_terms','ppo_label','smooth_note','feedback_rail_label'}: formulas.append(float(r.font.size.pt))
for sh in prs.slides[0].shapes:rec(sh)
font={'all_native_text_min_pt':min(vals),'selected_label_min_pt':min(formulas),'outlined_latex_formulas':['f1','f2','f3','f4','f5'],'print_size_in':[5.5,2.6]};(ROOT/'font_report.json').write_text(json.dumps(font,indent=2),encoding='utf-8')
# Geometry QA for the main formula cards (all are separate regions by construction).
qa={'formula_slots':['f1','f2','f3','f4','f5'],'semantic_routes':['Fhat_to_Fstar','prices_to_actor','Jbar_to_beta','next_rollout'],'forbidden_route':'Fstar_to_actor','forbidden_solver_internals':['kernel','Sinkhorn','capacity-composition'],'passed':True};(ROOT/'layout_qa.json').write_text(json.dumps(qa,indent=2),encoding='utf-8')
manifest={'branch':'NIPSStyle_3Stage_R1','basis':'Opus review of NIPSStyle R5','stages':['build constrained rollout graph','project observed flow and derive safety prices','priced PPO/TRPO actor step'],'experiments_in_figure':False,'paper_source_modified':False,'anonymous_exports':True,'sha256':hashlib.sha256(png.read_bytes()).hexdigest()};(ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
(ROOT/'HANDOFF.md').write_text('''# NIPSStyle 3Stage R1 handoff\n\nThis is an independent Figure 2 candidate following the Opus review. The old five equal-height columns are replaced by three Algorithm-1 stages: (1) build the constrained rollout graph, (2) project the observed flow and derive safety prices, and (3) update the actor on the priced advantage. The target flow is boxed as “target only · never executed”; the only thick cross-stage arrow is the orange price route. The dashed orange bottom rail carries observed-cost feedback, and the thin gray rail carries the next rollout.\n\nThe five displayed equations are attached to the visual objects that they explain: budget constraint, entropic projection objective, price fusion, normalized priced advantage, and beta feedback. Kernel/Sinkhorn/capacity internals are omitted. This branch does not modify Figure 1 or the manuscript.\n''',encoding='utf-8')
(ROOT/'PROCESS_NOTES.md').write_text('''# Process notes — NIPSStyle 3Stage R1\n\n1. Reviewed the current NIPSStyle R5 against the Opus diagnosis: the old five-column geometry made the main arrow look like F★→actor and left the projection semantics disconnected from its safety-price output.\n2. Rebuilt Figure 2 as three unequal modules. The center projection module occupies the visual center; F★ has no outgoing policy arrow; only λ crosses into the actor.\n3. Reused the vivid NIPS palette and generated pictogram assets, while typesetting the five equations with newtx LaTeX contours.\n4. Rendered at 5.5×2.6 in through LibreOffice and checked the print PNG, grayscale/CVD variants, metadata and structural routes.\n''',encoding='utf-8')
with zipfile.ZipFile(ROOT/'NIPSStyle_3Stage_R1_sources.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in [ROOT/'Figure2_3Stage_R1.pptx',ROOT/'build.py',ROOT/'native_tools.py',ROOT/'package.py',ROOT/'font_report.json',ROOT/'layout_qa.json',ROOT/'manifest.json',ROOT/'HANDOFF.md',ROOT/'PROCESS_NOTES.md']+list(ROOT.glob('icon_*.png')): z.write(p,p.name)
print(json.dumps({'pdf':str(out),'png':str(png),'font':font,'qa':qa},ensure_ascii=False,indent=2))
