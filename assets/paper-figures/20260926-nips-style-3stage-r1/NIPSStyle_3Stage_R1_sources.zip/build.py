from pathlib import Path
import json, shutil, fitz, hashlib, zipfile
from pptx import Presentation
from pptx.util import Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import PP_ALIGN
from pptx.enum.dml import MSO_LINE_DASH_STYLE

ROOT=Path(__file__).resolve().parent
import sys
sys.path.insert(0,str(ROOT))
from native_tools import typeset, import_formula, text, line, clean

W,H=396,187.2 # 5.5 x 2.6 inch in points
INK='24343D'; BLUE='1828E6'; BLUE_L='AFC4F5'; TEAL='087F8C'; GREEN='126B35'; GREEN_L='EAF5EC'; ORANGE='E8790A'; ORANGE_L='FFF1E2'; PURPLE='56318A'; RED='C8212A'; GRAY='66747D'; LIGHT='F7F9FB'

def rgb(hexv): return RGBColor.from_string(hexv)
def box(sl,name,x,y,w,h,fill='FFFFFF',linec=GRAY,width=.7,round=True):
    sh=sl.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if round else MSO_SHAPE.RECTANGLE,Pt(x),Pt(y),Pt(w),Pt(h)); sh.name=name
    sh.fill.solid(); sh.fill.fore_color.rgb=rgb(fill); sh.line.color.rgb=rgb(linec); sh.line.width=Pt(width); return sh

def circle(sl,name,x,y,d,fill,linec=None):
    sh=sl.shapes.add_shape(MSO_SHAPE.OVAL,Pt(x),Pt(y),Pt(d),Pt(d)); sh.name=name; sh.fill.solid(); sh.fill.fore_color.rgb=rgb(fill); sh.line.color.rgb=rgb(linec or fill); sh.line.width=Pt(.5); return sh

def add_pic(sl,name,path,x,y,w,h):
    sh=sl.shapes.add_picture(str(path),Pt(x),Pt(y),Pt(w),Pt(h)); sh.name=name; return sh

def graph(sl,prefix,x,y,w,h,edge_color=BLUE,node_fill='FFFFFF',hard=True,target=False):
    # six-node two-route motif; same topology is reused for observed and target flow.
    pts=[(x+8,y+5),(x+w*.5,y+5),(x+w-8,y+5),(x+8,y+h-5),(x+w*.5,y+h-5),(x+w-8,y+h-5)]
    edges=[(0,1),(1,2),(3,4),(4,5),(0,3),(1,4),(2,5),(1,3)]
    for i,(a,b) in enumerate(edges):
        col=RED if hard and i==1 else edge_color
        dash=hard and i==1
        line(sl,f'{prefix}_e{i}',[pts[a],pts[b]],color=col,width=1.4 if target and i in (2,3,7) else .75,arrow=True,dash=dash)
        if hard and i==1:
            mx=(pts[a][0]+pts[b][0])/2; my=(pts[a][1]+pts[b][1])/2
            line(sl,f'{prefix}_x{i}',[(mx-3,my-3),(mx+3,my+3)],color=RED,width=1.1)
            line(sl,f'{prefix}_x{i}b',[(mx-3,my+3),(mx+3,my-3)],color=RED,width=1.1)
    for i,(px,py) in enumerate(pts): circle(sl,f'{prefix}_n{i}',px-3,py-3,6,node_fill,edge_color)
    # orange tick identifies the costly upper route; this is a cue, not an extra formula.
    if target:
        line(sl,f'{prefix}_cost',[ (x+14,y+5),(x+w*.45,y+5) ],color=ORANGE,width=2.3)

def arrow(sl,name,p1,p2,color=BLUE,width=1.3,dash=False):
    line(sl,name,[p1,p2],color=color,width=width,arrow=True,dash=dash)

def formula(svgdir, page_index, name, tex, size, color, sl, x,y,w,h):
    svg=svgdir/f'eq-{page_index}.svg'; page=fitz.open(str(svgdir/'equations.pdf'))[page_index-1]
    return import_formula(sl,svg,name,(x,y,w,h),color,page.rect)

# Formula pages. Keep the math sparse and attach each equation to a visual module.
rows=[
 ('f1',r'\langle C_k,F\rangle\le b_k=B_k/L',7.6, GREEN),
 ('f2',r'\max_F\;\langle A,F\rangle-\varepsilon\,\mathrm{KL}(F\Vert\widehat F)',7.4, GREEN),
 ('f3',r'\lambda_k=\bar\lambda_k^\star+\beta_k',7.6, ORANGE),
 ('f4',r'\widetilde A=\frac{A_r-\sum_k\lambda_k A_{c_k}}{1+\sum_k\lambda_k}',7.2, ORANGE),
 ('f5',r'\beta_k\leftarrow[\beta_k+\alpha(\bar J_k-B_k)]_+',7.2, ORANGE),
]
svgdir=typeset([(n,t,(40,40),s,c) for n,t,s,c in rows],1)

prs=Presentation(); prs.slide_width=Pt(W); prs.slide_height=Pt(H); sl=prs.slides.add_slide(prs.slide_layouts[6])
# white background
bg=sl.background.fill; bg.solid(); bg.fore_color.rgb=rgb('FFFFFF')
# three algorithm stages; projection is the dominant center module.
box(sl,'stage1',4,5,105,148,'F9FBFF',BLUE,1.0)
box(sl,'stage2',116,5,174,148,'F7FCF8',GREEN,1.5)
box(sl,'stage3',297,5,95,148,'FFF9F2',ORANGE,1.0)
# numbered headers
for name,n,x,c,title in [('s1num','1',11,BLUE,'Build the graph'),('s2num','2',123,GREEN,'Project + price'),('s3num','3',304,ORANGE,'Priced actor')]:
 circle(sl,name,x,11,20,c,c); text(sl,name+'_txt',n,x,13,20,15,12,'FFFFFF',True)
 text(sl,name+'_title',title,x+25,12,70,16,9.0,c,True,align=PP_ALIGN.LEFT)
# Stage 1: rollout -> graph, with compact input chips
add_pic(sl,'stage1_graph_icon',ROOT/'icon_graph_r4.png',12,35,24,24)
text(sl,'rollout_label','rollout π_t',40,37,56,10,7.2,BLUE,True,align=PP_ALIGN.LEFT)
text(sl,'cluster_label','k-means · N nodes',14,60,86,10,7.0,INK,False)
graph(sl,'observed',17,73,78,36,BLUE_L,'FFFFFF',hard=True,target=False)
text(sl,'observed_graph_label','observed graph  F̂',17,111,78,10,7.0,BLUE,True)
# input chips
for i,(x,c,t) in enumerate([(12,BLUE,'F̂'),(39,PURPLE,'A'),(66,GREEN,'C_k')]):
 box(sl,f'chip{i}',x,122,24,12,'FFFFFF',c,.6); text(sl,f'chip{i}txt',t,x,124,24,8,7.0,c,True)
formula(svgdir,1,'formula_f1',r'\langle C_k,F\rangle\le b_k=B_k/L',7.6,GREEN,sl,10,136,92,11)
text(sl,'cost_out','J̄_k',75,142,24,9,7.4,ORANGE,True)
# Stage 2: two copies of same graph motif, target is dashed and has no actor-facing edge.
text(sl,'stage2_subtitle','same transition graph, constrained once',130,36,145,10,7.0,GREEN,False)
text(sl,'obs_lbl','observed  F̂',128,49,58,10,7.3,BLUE,True)
text(sl,'tar_lbl','target  F★',218,49,58,10,7.3,TEAL,True)
graph(sl,'stage2_obs',128,62,64,28,BLUE_L,'FFFFFF',hard=True,target=False)
box(sl,'target_frame',210,58,72,43,'FFFFFF',TEAL,1.0,round=False)
graph(sl,'stage2_tar',214,62,64,28,TEAL,'FFFFFF',hard=True,target=True)
arrow(sl,'reroute_arrow',(195,80),(208,80),TEAL,1.8)
text(sl,'target_note','target only · never executed',211,91,70,8,7.0,GRAY,False)
# budget occupancy cue, active versus slack
text(sl,'budget_lbl','budget occupancy',129,120,70,9,7.0,GREEN,True,align=PP_ALIGN.LEFT)
# bars
text(sl,'b1','k=1',128,131,18,8,7.0,GRAY,False,align=PP_ALIGN.LEFT); box(sl,'bar1',147,131,42,6,'FFFFFF',GRAY,.4,False); box(sl,'bar1fill',147,131,40,6,GREEN,GREEN,.2,False); text(sl,'price1','λ̄★₁ > 0',192,129,42,9,7.0,ORANGE,True,align=PP_ALIGN.LEFT)
text(sl,'b2','k=2',128,143,18,8,7.0,GRAY,False,align=PP_ALIGN.LEFT); box(sl,'bar2',147,143,42,6,'FFFFFF',GRAY,.4,False); box(sl,'bar2fill',147,143,23,6,'B9C1C6','B9C1C6',.2,False); text(sl,'price2','λ̄★₂ = 0',192,141,42,9,7.0,GRAY,False,align=PP_ALIGN.LEFT)
# Projection objective and price merge near right edge.
box(sl,'objective_card',120,104,112,15,'FFFFFF',GREEN,.5,round=True); formula(svgdir,2,'formula_f2',r'\max_F\;\langle A,F\rangle-\varepsilon\,\mathrm{KL}(F\Vert\widehat F)',7.4,GREEN,sl,125,106,102,12)
circle(sl,'plus_node',258,119,16,ORANGE,ORANGE); text(sl,'plus_txt','+',258,120,16,13,10,'FFFFFF',True)
arrow(sl,'price_to_plus',(242,119),(258,127),TEAL,1.2)
formula(svgdir,3,'formula_f3',r'\lambda_k=\bar\lambda_k^\star+\beta_k',7.6,ORANGE,sl,236,102,51,15)
text(sl,'smooth_note','clip + smooth',236,146,50,8,7.0,GRAY,False)
# thick orange semantic output only
arrow(sl,'lambda_out',(274,127),(298,127),ORANGE,2.6)
# Stage 3: advantages -> built-up fraction -> PPO/TRPO.
text(sl,'gae_label','GAE from rollout',307,36,76,9,7.0,GRAY,True)
text(sl,'gae_terms','reward Aᵣ · cost A_c',307,46,76,9,7.2,PURPLE,True)
box(sl,'adv_card',303,57,83,42,'FFFFFF',ORANGE,.8)
formula(svgdir,4,'formula_f4',r'\widetilde A=\frac{A_r-\sum_k\lambda_k A_{c_k}}{1+\sum_k\lambda_k}',7.2,ORANGE,sl,306,61,77,34)
box(sl,'ppo_card',307,105,75,20,'FFF1E2',ORANGE,.8)
text(sl,'ppo_label','PPO / TRPO → πₜ₊₁',307,110,75,10,7.3,ORANGE,True)
add_pic(sl,'actor_icon',ROOT/'icon_actor_r4.png',307,129,18,20)
line(sl,'actor_traj',[(330,142),(342,137),(353,143),(365,133),(378,137)],color=ORANGE,width=1.2,arrow=True)
for i,(x,y) in enumerate([(330,142),(342,137),(353,143),(365,133),(378,137)]): circle(sl,f'actor_node{i}',x-2,y-2,4,ORANGE,ORANGE)
# Bottom data rails: feedback is dashed orange; iteration is thin gray.
line(sl,'feedback_rail',[(27,164),(27,159),(190,159),(190,122),(258,122)],color=ORANGE,width=1.0,arrow=True,dash=True)
text(sl,'feedback_rail_label','J̄_k − B_k  →  β_k',45,160,83,9,7.0,ORANGE,True)
line(sl,'next_iteration',[(373,174),(373,181),(14,181),(14,174)],color=GRAY,width=.8,arrow=True)
text(sl,'next_iteration_label','next rollout',173,168,52,9,7.0,GRAY,False)
# metadata
prs.core_properties.author=''; prs.core_properties.last_modified_by=''; prs.core_properties.title='SafeOT Figure 2 · three-stage framework'; prs.core_properties.subject='Method framework'; prs.core_properties.comments=''
out=ROOT/'Figure2_3Stage_R1.pptx'; prs.save(str(out)); print(out)
