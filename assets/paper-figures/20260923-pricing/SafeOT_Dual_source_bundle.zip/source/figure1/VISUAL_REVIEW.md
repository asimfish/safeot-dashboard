# Figure 1 review

Selected candidate: `paper_v03/build_01/editable.pptx` and its sibling SVG, PDF, resolved scene, and actual-render previews. The comparison source is `Figure1_unified_price_v02.png` (1837 × 856). The scientifically incorrect v01 graph support is retained only as source/preparation evidence in `baseline_v01`; it is not the final figure.

## What was inspected

- Viewed both raster sources before authoring. Manually checked every label, graph direction, formula component, and the two zero-clip branches because no OCR engine is installed.
- Viewed the actual LibreOffice-rendered PPTX at full-page size, at exact source width, and in isolated formula crops. The selected figure has no clipped visible text, unintended collision, missing symbol, or reversed arrow. All three graphs use the same six nodes and eight directed edges: 1→2, 2→3, 3→4, 1→5, 5→6, 6→4, 2→5, and 3→6. Line widths are conceptual; these are partial schematic transitions, not complete balanced-flow solutions or measured results.
- Compared the source-faithful v02 baseline (`faithful_v02_r04`) with the original source and retained the difference image and fixed-region diagnostics. The baseline is an editable approximation, not pixel-identical tracing. Liberation Serif is an installed font approximation; the source font cannot be uniquely identified from its pixels.
- Viewed the duplicate-PPTX editing test after moving the entropic station 40 source pixels right and changing its native title to “Entropic graph edit.” All 30 intended leaves moved, the other 192 leaves stayed fixed, and only that label changed. The duplicate is test evidence, not the deliverable figure.

## Intentional paper-candidate changes

The parent-approved revision uses charcoal `#25323A` for text and structure, teal `#16868B` for graph flow and the interface heading, feedback gray `#6B7882`, pale teal `#EDF5F4`, and white. The band heading becomes “SafeOT-Dual: one price rule.” Ordinary labels are at least 33 source pixels; the actual PPTX minimum is **7.11 pt** at 5.5 inches. Headers are 34 px bold. The band has modestly greater horizontal padding and is 8 px taller; the advantage formula and zero-clip branch move down by 5 and 7 px. Node labels are enlarged with their circles. The scientific text and formulas are otherwise preserved.

Mathematical scripts are smaller by design: the smallest nested script is 3.49 pt, while the main price formula is 9.48 pt. These are grouped, editable native text parts with explicit script baselines, **not OMML / Office Math objects**. Ordinary prose stays in full-label text boxes or rich-text runs. There are 222 native leaf objects, 57 nested semantic groups, eight top-level selectable groups, and **zero visible raster images**. Braces are grouped native line segments.

## Validation and measured limits

The selected build passes preflight, native-object verification, actual-render text/font checks for all 69 text boxes, and its six-region appearance plan. The actual PDF uses Liberation Serif regular, italic, and bold without renderer substitution. Fonts are not embedded. The four-region `actual_target_ink_audit.json` separately confirms the approved literal target colors for title/body text, the teal heading, and the feedback marker.

Two source text regions have no stable opaque color core: `station_title_ink` and `graph_price_ink`. Their initial failing appearance results and crops remain in `paper_v02/build_01/appearance/` and `faithful_v02_r03/build_01/appearance/`. A bounded foreground-threshold diagnostic at 16, 64, and 128 still failed source core consistency. These regions remain **unverified for source-color fidelity** in `unresolved_source_appearance.json`; the final measurable-region build does not convert these failures into source-fidelity passes. Direct target-RGB verification is a separate check with a different claim.

Fixed same-coordinate masks retain source versus actual edge differences. For the source-faithful baseline, the title bounds differ by [-4, 0, +1, 0] px, the shared-price formula by [0, -3, -3, +3] px, and the advantage formula by [-2, +6, +2, +2] px (left, top, right, bottom). Glyph-mask IoU is 0.164, 0.255, and 0.179 respectively; these are diagnostics, not an aggregate accuracy score. The paper candidate intentionally changes type weight/color and lower-formula placement, so its differences are also retained without a fidelity claim. No registration or preview resizing was used to hide displacement.

The actual application check is **LibreOffice/PDFium on Linux**. PowerPoint and WPS click behavior and rendering were not checked. Moving a native module or formula works, but external arrows and the epsilon rail do not reroute automatically. Much longer edited labels may require resizing.

## Retained attempts

`faithful_v02` / `paper_v01` retain the first scene-role schema failure and subsequent graph/brace-join preflight findings. Specific source-supported endpoint and cusp joins were then declared; no text collision was blanket-exempted. `faithful_v02_r03` / `paper_v02` retain the first actual-render appearance failures. `group_edit_test/attempt01_failure.json` records a missing preview-directory error after the edited PPTX and PDF were already produced; recovery verified those files and generated only the missing preview/report.

Authoring: `author_figure1.py`. Verification: `verify_figure1.py`. Final artifact map: `delivery.json`. The parent task owns paper placement, caption integration, and publishing.
