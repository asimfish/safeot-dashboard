from pathlib import Path
from copy import deepcopy
import json
import subprocess
import zipfile
import fitz
from pptx import Presentation

ROOT = Path(__file__).resolve().parent
D = ROOT / 'delivery'
if not D.is_dir():
    # In the portable ZIP this script lives in source/ beside root deliverables.
    D = ROOT.parent
OUT = ROOT / 'outputs/combined/native-final'


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    decks = [Presentation(D / f'Figure{i}_SafeOT_Dual.pptx') for i in (1, 2)]
    result = Presentation()
    result.slide_width = decks[0].slide_width
    assert all(p.slide_width == result.slide_width for p in decks)
    result.slide_height = max(p.slide_height for p in decks)
    for source in decks:
        slide = result.slides.add_slide(result.slide_layouts[6])
        for shape in source.slides[0].shapes:
            # All artwork is native. No images, links or external relationships
            # need remapping; copied shape XML retains sizes and nested groups.
            slide.shapes._spTree.insert_element_before(deepcopy(shape._element), 'p:extLst')
    output = D / 'SafeOT_Dual_Figures_editable.pptx'
    result.save(output)
    with zipfile.ZipFile(output) as z:
        assert not any(n.startswith('ppt/media/') for n in z.namelist())
        assert z.testzip() is None
    cmd = ['soffice', '-env:UserInstallation=file:///tmp/safeot-dual-final-composition',
           '--headless', '--convert-to', 'pdf', '--outdir', str(OUT), str(output)]
    run = subprocess.run(cmd, capture_output=True, text=True)
    (OUT / 'render.log').write_text(run.stdout + run.stderr)
    assert run.returncode == 0
    pdf_path = OUT / 'SafeOT_Dual_Figures_editable.pdf'
    combined = fitz.open(pdf_path)
    assert len(combined) == 2
    checks = []
    for i, page in enumerate(combined, 1):
        separate = fitz.open(D / f'Figure{i}_SafeOT_Dual.pdf')
        # Same native sizes, exact text and vector content, no raster substitution.
        norm = lambda x: ''.join(x.split())
        assert norm(page.get_text()) == norm(separate[0].get_text())
        assert len(page.get_images()) == 0
        fonts = lambda pg: sorted((span['text'], round(span['size'], 3), span['font'])
            for block in pg.get_text('dict')['blocks'] if 'lines' in block
            for line in block['lines'] for span in line['spans'])
        assert fonts(page) == fonts(separate[0])
        page.get_pixmap(matrix=fitz.Matrix(3, 3)).save(OUT / f'page_{i:03}.png')
        checks.append({'figure': i, 'text_identical': True, 'font_sizes_identical': True,
                       'raster_images': 0, 'native_shapes': len(result.slides[i-1].shapes)})
        separate.close()
    combined.close()
    (D / 'SafeOT_Dual_Figures_vector.pdf').write_bytes(pdf_path.read_bytes())
    report = {'status': 'PASS', 'method': 'Copy native grouped shape XML from verified individual decks; retain physical sizes; add bottom whitespace to shorter slide',
              'width_inches': result.slide_width/914400, 'height_inches': result.slide_height/914400,
              'figures': checks, 'renderer': 'LibreOffice',
              'preliminary_build': 'build_01 retained; final download uses native-final composition'}
    (ROOT / 'outputs/combined/native-composition.json').write_text(json.dumps(report, indent=2))
    print(json.dumps(report))


if __name__ == '__main__':
    main()
