"""Scientific print previews; Machado 2009 severity-100 linear-RGB matrices.
No image synthesis, resampling, data manipulation or global dependencies.
"""
from pathlib import Path
import json
import numpy as np
from PIL import Image
P=Path(__file__).resolve().parent/'outputs'
MATS={'deuteranopia':np.array([[.367322,.860646,-.227968],[.280085,.672501,.047413],[-.011820,.042940,.968881]]),'protanopia':np.array([[.152286,1.052583,-.204868],[.114503,.786281,.099216],[-.003882,-.048116,1.051998]])}
results=[]
for path in sorted(P.glob('*_300dpi.png')):
 a=np.array(Image.open(path).convert('RGB'),dtype=np.float64)/255
 linear=np.where(a<=.04045,a/12.92,((a+.055)/1.055)**2.4)
 for name,m in MATS.items():
  c=np.clip(linear @ m.T,0,1)
  encoded=np.where(c<=.0031308,12.92*c,1.055*np.maximum(c,0)**(1/2.4)-.055)
  target=path.with_name(path.name.replace('_300dpi','_'+name))
  Image.fromarray(np.round(np.clip(encoded,0,1)*255).astype('uint8')).save(target,dpi=(300,300))
  results.append({'source':path.name,'preview':target.name,'severity':100,'matrix':m.tolist()})
(P/'accessibility_report.json').write_text(json.dumps({'method':'Machado, Oliveira and Fernandes 2009; severity 100; sRGB decoding then matrix then sRGB encoding; out-of-gamut values clipped','note':'Simulations are diagnostic previews, not a claim of universal accessibility. Identity is additionally encoded by line pattern, marker and labels.','figures':results},indent=2))
print('CVD previews:',len(results))
