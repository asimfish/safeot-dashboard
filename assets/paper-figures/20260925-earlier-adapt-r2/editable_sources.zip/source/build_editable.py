"""Native editable PowerPoint from the shared vector scene, without raster images."""
from pathlib import Path
import json
from matplotlib.colors import to_hex
from pptx import Presentation
from pptx.util import Pt,Emu
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE,MSO_CONNECTOR
from pptx.enum.text import PP_ALIGN,MSO_ANCHOR
from pptx.oxml.xmlchemy import OxmlElement
from pptx.oxml.ns import qn
from matplotlib.textpath import TextToPath
from matplotlib.font_manager import FontProperties
from datetime import datetime
R=Path(__file__).resolve().parent;O=R/'outputs'
C=lambda s:RGBColor.from_string(to_hex(s).lstrip('#'))
P=lambda x:Emu(round(x*12700))
def no_theme(sh):
 for el in list(sh._element):
  if el.tag==qn('p:style'):sh._element.remove(el)
 sp=sh._element.spPr
 for el in list(sp):
  if el.tag in [qn('a:effectLst'),qn('a:effectDag')]:sp.remove(el)
 sp.append(OxmlElement('a:effectLst'))
def style(sh,item):
 no_theme(sh)
 sh.line.color.rgb=C(item['color']);sh.line.width=Pt(item.get('lw',.7))
 if item.get('lw',.7)==0:sh.line.fill.background()
 if item.get('dash'):
  dash=OxmlElement('a:prstDash');dash.set('val','dash');sh.line._get_or_add_ln().append(dash)
 if 'fill' in item:
  sh.fill.solid();sh.fill.fore_color.rgb=C(item['fill'])
  if item.get('alpha',1)!=1:
   alpha=OxmlElement('a:alpha');alpha.set('val',str(round(item['alpha']*100000)));sh.fill._xPr.solidFill.srgbClr.append(alpha)
 elif hasattr(sh,'fill'):sh.fill.background()
def add_arrow_end(sh,tag):
 e=OxmlElement('a:'+tag);e.set('type','triangle');e.set('w','sm');e.set('len','sm');sh.line._get_or_add_ln().append(e)
def build(name):
 scene=json.loads((O/(name+'.scene.json')).read_text());prs=Presentation();prs.slide_width=P(scene['width']);prs.slide_height=P(scene['height']);sl=prs.slides.add_slide(prs.slide_layouts[6]);tp=TextToPath()
 for item in scene['items']:
  k=item['kind']
  if k=='text':
   text=item['text'];size=item['size'];fam='STIXGeneral' if any(a in text for a in '⟨⟩') else 'Liberation Serif';fp=FontProperties(family=fam,size=size,weight='bold' if item['bold'] else 'normal')
   w=tp.get_text_width_height_descent(text,fp,False)[0]+1.5;x=item['x'];x-=w/2 if item['ha']=='center' else w if item['ha']=='right' else 0
   sh=sl.shapes.add_textbox(P(x),P(item['y']-size*.65),P(w),P(size*1.3));no_theme(sh);tf=sh.text_frame;tf.clear();tf.margin_left=tf.margin_right=tf.margin_top=tf.margin_bottom=0;tf.word_wrap=False;tf.vertical_anchor=MSO_ANCHOR.MIDDLE
   para=tf.paragraphs[0];para.alignment=PP_ALIGN.LEFT;para.space_before=para.space_after=Pt(0);para.line_spacing=1
   run=para.add_run();run.text=text;run.font.name=fam;run.font.size=Pt(size);run.font.bold=item['bold'];run.font.color.rgb=C(item['color']);continue
  if k=='box':
   sh=sl.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE,P(item['x']),P(item['y']),P(item['w']),P(item['h']));sh.adjustments[0]=min(.4,item['r']/min(item['w'],item['h']));style(sh,item)
  elif k=='circle':
   sh=sl.shapes.add_shape(MSO_SHAPE.OVAL,P(item['x']-item['r']),P(item['y']-item['r']),P(item['r']*2),P(item['r']*2));style(sh,item)
  elif k in ['line','polygon']:
   pts=item['pts'];ff=sl.shapes.build_freeform(P(pts[0][0]),P(pts[0][1]),scale=1.0);ff.add_line_segments([(P(x),P(y)) for x,y in pts[1:]],close=k=='polygon');sh=ff.convert_to_shape();style(sh,item)
  elif k=='arrow':
   assert item['rad']==0
   a,b=item['a'],item['b'];sh=sl.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,P(a[0]),P(a[1]),P(b[0]),P(b[1]));style(sh,item);add_arrow_end(sh,'tailEnd')
   if item['style']=='<->':add_arrow_end(sh,'headEnd')
 for n in ['author','last_modified_by','title','subject','keywords','comments','category','identifier','content_status']:setattr(prs.core_properties,n,'')
 prs.core_properties.created=datetime(2000,1,1);prs.core_properties.modified=datetime(2000,1,1)
 prs.save(O/(name+'.pptx'));print(name,'native shapes',len(sl.shapes),'text shapes',sum(x.has_text_frame for x in sl.shapes))
for n in ['Figure1','Figure2']:build(n)
