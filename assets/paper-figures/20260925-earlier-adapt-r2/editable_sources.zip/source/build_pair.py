"""Earlier-design adaptation: all vector primitives, no inherited scientific claims.
Physical coordinates are printer points. Mini-curves are illustrative schematics.
"""
from pathlib import Path
import json,hashlib,math,xml.etree.ElementTree as ET
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,Rectangle,Circle,Polygon,FancyArrowPatch
from matplotlib.lines import Line2D
from matplotlib.textpath import TextToPath
from matplotlib.font_manager import FontProperties
import numpy as np
import fitz
from anonymize import clean_pdf,clean_svg
R=Path(__file__).resolve().parent;O=R/'outputs';O.mkdir(exist_ok=True)
plt.style.use(R/'safeot.mplstyle')
BLUE='#0072B2';GREEN='#167C80';TEAL='#167C80';RED='#C43C39';PURPLE='#A0467E';ORANGE='#D55E00';GRAY='#59636A';LIGHT='#D8DEE2';INK='#23343B'
SCENES={}
class Canvas:
 def __init__(self,name,h):
  self.name=name;self.w=396;self.h=h;self.fig=plt.figure(figsize=(self.w/72,h/72));self.ax=self.fig.add_axes([0,0,1,1]);self.ax.set_xlim(0,self.w);self.ax.set_ylim(h,0);self.ax.axis('off');self.items=[]
 def text(self,x,y,text,size=7.5,color=INK,bold=False,ha='left',math=False):
  self.ax.text(x,y,text,fontfamily=('STIXGeneral' if any(a in text for a in '⟨⟩') else 'Liberation Serif'),fontsize=size,color=color,fontweight='bold' if bold else 'normal',ha=ha,va='center',linespacing=1.17)
  self.items.append(dict(kind='text',x=x,y=y,text=text,size=size,color=color,bold=bold,ha=ha,math=math))
 def rich(self,x,y,runs,color=INK,ha='center'):
  # Explicit7pt scripts avoid unreadable nested automatic math scripts.
  tp=TextToPath();widths=[tp.get_text_width_height_descent(t,FontProperties(family=('STIXGeneral' if any(a in t for a in '⟨⟩') else 'Liberation Serif'),size=z),False)[0] for t,z,dy,*cc in runs]
  xx=x-(sum(widths)/2 if ha=='center' else sum(widths) if ha=='right' else 0)
  for run,w in zip(runs,widths):
   t,z,dy,*cc=run;self.text(xx,y+dy,t,z,cc[0] if cc else color);xx+=w
 def box(self,x,y,w,h,color=GRAY,fill='white',r=3,lw=.65,dash=False):
  self.ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle=f'round,pad=0,rounding_size={r}',facecolor=fill,edgecolor=color,linewidth=lw,linestyle='--' if dash else '-'));self.items.append(dict(kind='box',x=x,y=y,w=w,h=h,color=color,fill=fill,r=r,lw=lw,dash=dash))
 def line(self,pts,color=GRAY,lw=.7,dash=False):
  self.ax.plot([p[0] for p in pts],[p[1] for p in pts],color=color,lw=lw,ls='--' if dash else '-',solid_capstyle='round');self.items.append(dict(kind='line',pts=pts,color=color,lw=lw,dash=dash))
 def arrow(self,a,b,color=GRAY,lw=.8,style='-|>',rad=0):
  self.ax.add_patch(FancyArrowPatch(a,b,arrowstyle=style,mutation_scale=6.5,lw=lw,color=color,connectionstyle=f'arc3,rad={rad}',shrinkA=0,shrinkB=0));self.items.append(dict(kind='arrow',a=a,b=b,color=color,lw=lw,style=style,rad=rad))
 def circle(self,x,y,r=2.2,fill='white',color=GRAY,lw=.6):
  self.ax.add_patch(Circle((x,y),r,facecolor=fill,edgecolor=color,lw=lw));self.items.append(dict(kind='circle',x=x,y=y,r=r,fill=fill,color=color,lw=lw))
 def polygon(self,pts,color=GRAY,fill='white',lw=.6,alpha=1):
  self.ax.add_patch(Polygon(pts,closed=True,facecolor=fill,edgecolor=color,lw=lw,alpha=alpha));self.items.append(dict(kind='polygon',pts=pts,color=color,fill=fill,lw=lw,alpha=alpha))
 def export(self):
  raw=O/(self.name+'.raw.pdf');self.fig.savefig(raw,metadata={'Creator':None,'Producer':None,'CreationDate':None});clean_pdf(raw,O/(self.name+'.pdf'));raw.unlink()
  raw=O/(self.name+'.raw.svg');self.fig.savefig(raw,metadata={'Creator':None,'Date':None});clean_svg(raw,O/(self.name+'_editable.svg'));raw.unlink()
  with plt.rc_context({'svg.fonttype':'path'}):
   self.fig.savefig(raw,metadata={'Creator':None,'Date':None});clean_svg(raw,O/(self.name+'.svg'));raw.unlink()
  with fitz.open(O/(self.name+'.pdf')) as d:
   p=d[0];ss=[s for b in p.get_text('dict')['blocks'] if 'lines' in b for l in b['lines'] for s in l['spans'] if s['text'].strip()];minimum=min(s['size'] for s in ss)
   report={'size_in':[p.rect.width/72,p.rect.height/72],'minimum_font_pt':minimum,'native_vector':not p.get_images(),'embedded_fonts':all(d.extract_font(f[0])[3] for f in p.get_fonts()),'outside':[s['text'] for s in ss if not p.rect.contains(fitz.Rect(s['bbox']))],'text':p.get_text(),'mini_plots':'Top failure sketches are schematic; lower Figure1 strip uses frozen producer data' if self.name=='Figure1' else 'Flow graphs are schematic'}
   (O/(self.name+'.report.json')).write_text(json.dumps(report,indent=2)+'\n')
   for suffix,cs in [('300dpi',fitz.csRGB),('grayscale',fitz.csGRAY)]:
    pm=p.get_pixmap(matrix=fitz.Matrix(300/72,300/72),colorspace=cs,alpha=False);pm.set_dpi(300,300);pm.save(O/(self.name+'_'+suffix+'.png'))
   assert minimum>=7,(self.name,minimum);assert not report['outside'],report['outside']
  SCENES[self.name]={'width':self.w,'height':self.h,'items':self.items};plt.close(self.fig);print(self.name,minimum)

def drop(c,x,y,color):
 c.polygon([(x,y-6),(x-3,y),(x-3,y+3),(x,y+5),(x+3,y+3),(x+3,y)],color=color,fill=color,lw=.5)
def force(c,x,y,color):
 c.line([(x-5,y+5),(x+5,y+5)],color,1);c.line([(x-3,y+4),(x-1,y-1),(x+4,y-4)],color,1.1);c.circle(x-1,y-1,1.2,fill='white',color=color);c.arrow((x+3,y-4),(x+3,y+1),color,lw=.7)
def impact(c,x,y,color):
 c.line([(x-5,y+4),(x-5,y-3),(x+5,y-3),(x+5,y+4)],color,.9);c.arrow((x,y-6),(x,y+2),color);c.line([(x-2,y+4),(x,y+2),(x+2,y+4)],color,.8)
def graph(c,x,y,w,h,color=TEAL,observed=False,hard=True):
 points=[(x,y+h*.5),(x+w*.3,y),(x+w*.67,y),(x+w,y+h*.5),(x+w*.67,y+h),(x+w*.3,y+h)]
 edges=[(0,1),(1,2),(2,3),(0,5),(5,4),(4,3),(1,4)]
 for j,(a,b) in enumerate(edges):
  if hard and j==6:continue
  col=LIGHT if observed else color;lw=(1.8 if j<3 else .6) if observed else (.7 if j<3 else 1.65)
  c.line([points[a],points[b]],col,lw)
 if hard:
  a,b=points[1],points[4];c.line([a,b],RED,.7,True);cx=(a[0]+b[0])/2;cy=(a[1]+b[1])/2;c.line([(cx-2,cy-2),(cx+2,cy+2)],RED,.9);c.line([(cx-2,cy+2),(cx+2,cy-2)],RED,.9)
 for j,(xx,yy) in enumerate(points):c.circle(xx,yy,2.0,fill=color if j==3 else 'white',color=color)


def reroute(c,x,y,w,h,target=True,overlay=False,hard=True):
 pts=[(x,y+h/2),(x+w*.30,y),(x+w*.68,y),(x+w,y+h/2),(x+w*.68,y+h),(x+w*.30,y+h)]
 edges=[(0,1),(1,2),(2,3),(0,5),(5,4),(4,3)]
 # Orange halo identifies the costly shortcut, independently of flow color.
 c.line([pts[1],pts[2]],'#F3D4B3',3.6)
 for j,(a,b) in enumerate(edges):
  if overlay:c.line([pts[a],pts[b]],LIGHT,2.8 if j<3 else .8)
  c.line([pts[a],pts[b]],TEAL if target else '#ABB5BC',(.65 if j<3 else 2) if target else (2.0 if j<3 else .65))
 if hard:
  a,b=pts[1],pts[4];c.line([a,b],RED,.65,True);cx=(a[0]+b[0])/2;cy=(a[1]+b[1])/2;c.line([(cx-2,cy-2),(cx+2,cy+2)],RED,.8);c.line([(cx-2,cy+2),(cx+2,cy-2)],RED,.8)
 for j,(xx,yy) in enumerate(pts):c.circle(xx,yy,1.7,fill=(TEAL if target else GRAY) if j==3 else 'white',color=TEAL if target else GRAY)

def total_price(c,x,y,size=10):
 c.rich(x,y,[('λ',size,0,BLUE),('k',7,3,BLUE),(' = ',size,0,GRAY),('λ̄',size,0,TEAL),('*',7,-4,TEAL),('k',7,3,TEAL),(' + ',size,0,GRAY),('β',size,0,ORANGE),('k',7,3,ORANGE)])

def curves(c):
 import csv
 rows=list(csv.DictReader((R/'figure3c_alltask_aggregate.csv').open()));stats=json.loads((R/'primary_V_summaries.json').read_text())
 c.box(3,138,390,88,LIGHT,'#FCFDFE',r=3,lw=.6)
 c.text(9,147,'Training cost / B (task median)',7.5,INK,True)
 c.line([(205,147),(216,147)],BLUE,1.25);c.text(219,147,'SafeOT-Dual',7.1,BLUE)
 c.line([(273,147),(284,147)],PURPLE,1.0,True);c.text(287,147,'TRPO-Lag (c = 0)',7.1,PURPLE)
 receipt=[]
 for suite,x,statx in [('SafePO',24,166),('Bullet',221,362)]:
  y=173;w=107;h=34;log=suite=='Bullet';lo,hi=(.5,24) if log else (0,2.6)
  trans=lambda v:np.log(v) if log else v
  yy=lambda v:y+h-(trans(v)-trans(lo))/(trans(hi)-trans(lo))*h
  xx=lambda v:x+v*w/100
  c.text(x,160,suite+' · '+('10' if suite=='SafePO' else '6')+' tasks',7.5,INK,True)
  if log:c.text(x+w,160,'log y',7,GRAY,ha='right')
  ticks=[1,5,20] if log else [0,1,2]
  c.line([(x,y),(x,y+h),(x+w,y+h)],GRAY,.5)
  for t in ticks:
   c.line([(x-2,yy(t)),(x,yy(t))],GRAY,.5);c.text(x-4,yy(t),str(t),7,GRAY,ha='right')
  for progress in [0,100]:c.text(xx(progress),y+h+9,str(progress)+'%',7,GRAY,ha='center')
  c.text(x+w/2,y+h+9,'progress',7,GRAY,ha='center')
  for method,col,dash in [('TRPO-Lag',PURPLE,True),('SafeOT-Dual',BLUE,False)]:
   vals=sorted([(float(r['progress_pct']),float(r['cost_over_budget_median'])) for r in rows if r['suite']==suite and r['method']==method]);assert all(lo<=v<=hi for _,v in vals)
   # Add exact linear intersections only to the shaded-area boundary, not the data trace.
   expanded=[]
   for i,(a,b) in enumerate(vals):
    if i:
     a0,b0=vals[i-1]
     if (b0-1)*(b-1)<0:expanded.append((a0+(a-a0)*(1-b0)/(b-b0),1.0))
    expanded.append((a,b))
   poly=[(xx(a),yy(max(1,b))) for a,b in expanded]+[(xx(vals[-1][0]),yy(1)),(xx(vals[0][0]),yy(1))]
   c.polygon(poly,color=col,fill=col,lw=0,alpha=.17)
   c.line([(xx(a),yy(b)) for a,b in vals],col,1.05 if dash else 1.3,dash)
   receipt.append({'suite':suite,'method':method,'points':vals,'log_axis':log,'y_limits':[lo,hi]})
  c.line([(x,yy(1)),(x+w,yy(1))],GRAY,.55,True)
  c.text(statx,170,'V ratio',7,GRAY,ha='center');c.text(statx,183,f"{stats[suite]['point']:.2f}×",10,BLUE,True,'center')
  c.text(statx,201,f"{stats[suite]['lower_V']}/{stats[suite]['n_tasks']} lower V",7.3,INK,True,'center')
 (O/'curve_render_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')

def figure1():
 c=Canvas('Figure1',258)
 # Three large modules, with the proposed method visually dominant.
 c.box(3,3,94,126,GRAY,'#FAFAFC',r=3,lw=.65)
 c.box(104,3,184,126,TEAL,'#F4F9F8',r=3,lw=.9)
 c.box(295,3,98,126,TEAL,'#F9FBFC',r=3,lw=.65)
 c.text(50,13,'Feedback only',8.5,GRAY,True,'center')
 c.text(50,28,'Penalty leaks',7.5,PURPLE,True,'center')
 # Observed cost grows across the budget under a fixed price.
 x,y,w,h=20,38,63,25;c.line([(x,y),(x,y+h),(x+w,y+h)],GRAY,.5)
 c.line([(x,y+13),(x+w,y+13)],GRAY,.6,True);c.text(x-3,y+13,'B',7,GRAY,ha='right')
 ts=np.linspace(0,1,40);c.line([(x+t*w,y+23-21*(1-np.exp(-3*t))) for t in ts],PURPLE,1.1)
 c.text(50,77,'Lagrangian lags',7.5,PURPLE,True,'center')
 # Cost violates first, then a delayed feedback price increases.
 x,y,w,h=20,88,63,24;c.line([(x,y),(x,y+h),(x+w,y+h)],GRAY,.5);c.line([(x,y+13),(x+w,y+13)],GRAY,.6,True)
 ts=np.linspace(0,1,60);cost=[(x+t*w,y+13-10*np.sin(2.8*np.pi*t)) for t in ts]
 vals=[0.]
 for i in range(1,len(ts)):vals.append(max(0,vals[-1]+.12*(y+13-cost[i-1][1])))
 beta=[(x+t*w,y+22-18*b/max(vals)) for t,b in zip(ts,vals)]
 c.line(cost,PURPLE,1.0);c.line(beta,ORANGE,1.0,True);c.text(x+w+2,y+5,'β',7,ORANGE)
 c.text(50,121,'violate → react (schematic)',7,GRAY,ha='center')
 # Central algorithm: all budgets go through ONE joint solve.
 c.text(196,14,'SafeOT-Dual',10,BLUE,True,'center');c.text(196,29,'One joint flow solve',8.3,TEAL,True,'center')
 for j in range(3):
  c.box(113+j*2.5,43-j*2.5,25,17,GRAY,'white',r=1.5,lw=.5)
 c.rich(130,49,[('b',9,0),('1:K',7,3)],GRAY);c.arrow((143,51),(154,51),TEAL)
 reroute(c,160,42,111,24,target=True,overlay=True)
 c.text(160,38,'start',7,GRAY,ha='center');c.text(270,38,'goal',7,GRAY,ha='center')
 c.line([(116,71),(125,71)],LIGHT,2.1);c.text(128,71,'F̂',8,GRAY);c.line([(155,71),(164,71)],TEAL,1.6);c.text(167,71,'F*',8,TEAL)
 c.line([(201,71),(210,71)],'#E4A967',2.4);c.text(213,71,'costly',7,GRAY);c.text(250,71,'× hard',7,RED)
 c.text(196,80,'width = visits',7,GRAY,ha='center');total_price(c,196,94,10)
 c.text(151,108,'clipped + filtered',7,TEAL,ha='center');c.rich(245,105,[('J̄',8,0),('k',7,2),(' − B',8,0),('k',7,2)],ORANGE)
 c.text(247,119,'feedback',7,ORANGE,ha='center');c.arrow((196,110),(196,115),BLUE)
 c.rich(196,121,[('Ã',9,0,BLUE),(' → ',9,0,BLUE),('actor',8,0,GRAY)])
 # The budget view explains why one coupled solve produces distinct prices.
 c.text(344,14,'Joint budgets',8.5,TEAL,True,'center')
 x,y=307,94;c.polygon([(x,y),(x+40,y),(x+40,y-42),(x,y-42)],TEAL,'#E9F3F2',.6)
 c.arrow((x,y),(388,y),GRAY,.5);c.arrow((x,y),(x,33),GRAY,.5)
 c.rich(311,34,[('⟨C',8,0),('2',7,2),(', F⟩',8,0)],GRAY,ha='left')
 c.rich(388,103,[('⟨C',8,0),('1',7,2),(', F⟩',8,0)],GRAY,ha='right')
 c.circle(377,69,2,fill='white',color=GRAY);c.text(377,55,'reward',7,GRAY,ha='center');c.arrow((373,69),(350,69),GRAY,.6)
 c.circle(347,69,2,fill=TEAL,color=TEAL);c.text(343,69,'F*',8,TEAL,ha='right');c.arrow((347,81),(361,81),TEAL,.8)
 c.rich(343,42,[('λ',8,0),('*',7,-3),('2',7,2),(' = 0',8,0)],GRAY)
 c.rich(352,116,[('λ',8,0),('*',7,-3),('1',7,2),(' > 0',8,0)],TEAL)
 curves(c)
 # Compact exact-settings/limits band, retained as a single readable footer.
 for a,b,col in [(16,100,GRAY),(100,196,PURPLE),(196,292,BLUE),(292,380,TEAL)]:c.line([(a,243),(b,243)],col,1.5)
 for x,label,col in [(48,'Fixed penalty',GRAY),(142,'Lagrangian',PURPLE),(239,'SafeOT-Dual',BLUE),(345,'LP / active-set',TEAL)]:
  c.text(x,235,label,7.4,col,True,'center');c.circle(x,243,1.8,fill=col,color=col,lw=.5)
 c.text(48,252,'c = 0, fixed β',7,GRAY,ha='center');c.text(142,252,'c = 0, adaptive β',7,GRAY,ha='center');c.text(239,252,'finite ε',7,GRAY,ha='center');c.text(345,252,'ε → 0 / saturated clip',7,GRAY,ha='center')
 c.export()

def matrix_icon(c,x,y,col=TEAL):
 for i in range(3):
  for j in range(3):c.box(x+i*3.5,y+j*3.5,3,3,col,'#C5DFDF' if (i+j)%3==0 else '#EDF5F5',r=.2,lw=.5)

def figure2():
 c=Canvas('Figure2',217)
 specs=[(3,50,GRAY,'1  Rollout'),(59,61,TEAL,'2  Inputs'),(126,65,TEAL,'3  Budgets'),(197,113,TEAL,'4  Joint projection'),(316,77,BLUE,'5  Policy update')]
 for x,w,col,title in specs:
  c.box(x,3,w,160,col,'white',r=3,lw=.7);c.box(x+1,4,w-2,21,col,'#F5F6F7' if col==GRAY else '#F2F8F8' if col==TEAL else '#F2F7FA',r=2,lw=0);c.text(x+w/2,14,title,8.4,col,True,'center')
 for a,b in [(53,59),(120,126),(191,197)]:c.arrow((a,89),(b,89),GRAY,.8)
 c.rich(28,37,[('π',10,0),('t',7,3)],GRAY)
 for j,x in enumerate([13,28,43]):
  c.circle(x,54,2.5,fill='white',color=GRAY)
  if j<2:c.arrow((x+3,54),(x+12,54),GRAY,.65)
 c.box(8,80,40,33,GRAY,'#FAFAFA',r=2,lw=.6);c.text(28,89,'GAE',8,GRAY,True,'center');c.rich(28,103,[('Â',8,0),('r',7,3),(', Â',8,0),('c',7,3),('k',7,5)],GRAY)
 c.text(28,130,'Episode costs',7.2,GRAY,ha='center');c.rich(28,147,[('J̄',10,0),('k',7,3)],ORANGE)
 c.text(89.5,35,'Rollout graph',7.5,TEAL,ha='center');graph(c,70,47,40,22,TEAL,observed=True,hard=False)
 for yy,label in [(84,'F̂'),(108,'A'),(132,'C')]:
  matrix_icon(c,72,yy);c.text(98,yy+5,label,9,TEAL,ha='center')
 c.text(105,140,'k',7,TEAL);c.text(89.5,151,'state clusters',7,GRAY,ha='center')
 c.text(158.5,36,'Soft budgets',8,TEAL,True,'center');c.rich(158.5,51,[('b',9,0),('k',7,2),(' = B',9,0),('k',7,2),('/L',9,0)],TEAL)
 c.rich(158.5,67,[('⟨C',8.5,0),('k',7,2),(', F⟩ ≤ b',8.5,0),('k',7,2)],TEAL)
 c.line([(134,81),(183,81)],LIGHT,.5);c.text(158.5,94,'Hard edges',8,RED,True,'center')
 c.line([(138,111),(179,111)],RED,.7,True);c.line([(155,107),(161,115)],RED,.9);c.line([(155,115),(161,107)],RED,.9)
 c.rich(158.5,129,[('F',9,0),('H',7,2),(' = 0',9,0)],RED);c.text(158.5,147,'excluded; no price',7,GRAY,ha='center')
 # Full objective and all constraint classes; explicit before/after rerouting.
 c.rich(253.5,35,[('max',8,0),('F',7,3),(' ⟨A,F⟩ − ε KL(F∥F̂)',8,0)],TEAL)
 c.text(253.5,49,'F ≥ 0 · flow balance',7.3,TEAL,ha='center')
 c.rich(253.5,63,[('⟨C',8,0),('k',7,2),(',F⟩≤b',8,0),('k',7,2),(' · F',8,0),('H',7,2),('=0',8,0)],TEAL)
 c.text(223,82,'F̂',9,GRAY,ha='center');c.text(253,82,'costly',7,ORANGE,ha='center');c.text(284,82,'F*',9,TEAL,ha='center')
 reroute(c,204,94,38,24,target=False,hard=True);c.arrow((246,106),(262,106),TEAL,.8);reroute(c,266,94,38,24,target=True,hard=True)
 c.line([(272,122),(272,130),(303,130)],GRAY,.6,True);c.text(285,138,'target only',7,GRAY,ha='center');c.text(229,138,'width = visits',7,GRAY,ha='center')
 c.text(240,152,'Budget prices λ*',7.8,TEAL,True,'center');c.line([(304,152),(313,152),(313,35)],TEAL,.8);c.arrow((313,35),(321,35),TEAL,.8)
 c.text(354.5,35,'clip c + EMA',8,TEAL,ha='center');c.arrow((354.5,42),(354.5,50),TEAL)
 total_price(c,354.5,62,8.5);c.arrow((354.5,70),(354.5,78),BLUE)
 c.box(323,81,63,25,BLUE,'#F4F8FC',r=2,lw=.6);c.text(354.5,89,'Priced advantage',7.3,BLUE,True,'center');c.text(354.5,100,'Ã',10,BLUE,ha='center')
 c.arrow((354.5,107),(354.5,115),BLUE);c.box(323,118,63,20,GRAY,'#FAFAFA',r=2,lw=.6);c.text(354.5,128,'PPO / TRPO',8,GRAY,True,'center');c.rich(354.5,152,[('π',10,0),('t+1',7,3)],GRAY)
 c.line([(28,153),(28,178),(160,178)],ORANGE,.8);c.box(160,170,126,16,ORANGE,'#FFF8F2',r=2,lw=.6);c.rich(223,178,[('β',8,0),('k',7,2),(' ← [β',8,0),('k',7,2),(' + η(J̄',8,0),('k',7,2),(' − B',8,0),('k',7,2),(')]',8,0),('+',7,2)],ORANGE)
 c.line([(286,178),(389,178),(389,62)],ORANGE,.8);c.arrow((389,62),(383,62),ORANGE,.8)
 c.line([(354.5,157),(354.5,200),(.8,200),(.8,39)],GRAY,.6);c.arrow((.8,39),(9,39),GRAY,.6);c.text(77,194,'next rollout',7,GRAY,ha='center');c.text(223,193,'observed-cost feedback',7.2,ORANGE,ha='center')
 c.text(199,211,'F* is a target, not executed; feedback corrects the realization gap',7.5,GRAY,ha='center')
 c.export()

if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--figure',choices=['1','2','all'],default='all');a=p.parse_args()
 if a.figure in ['1','all']:figure1()
 if a.figure in ['2','all']:figure2()
 for n,scene in SCENES.items():(O/(n+'.scene.json')).write_text(json.dumps(scene,ensure_ascii=False,indent=2)+'\n')
