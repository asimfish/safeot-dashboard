"""Clear PDF/SVG metadata without altering drawing content.

Use on copies. Identity-sensitive content/URLs require a separate content audit;
this module does not redact text or silently remove scholarly references.
"""
from pathlib import Path
import argparse
import xml.etree.ElementTree as ET
import fitz

PDF_METADATA = {key: None for key in (
    'Title', 'Author', 'Subject', 'Keywords', 'Creator', 'Producer',
    'CreationDate', 'ModDate', 'Trapped')}
SVG_METADATA = {'Date': None, 'Creator': None}

def clean_pdf(source, destination):
    source, destination = Path(source), Path(destination)
    if source.resolve() == destination.resolve():
        raise ValueError('Write an anonymous copy to a distinct path.')
    destination.parent.mkdir(parents=True, exist_ok=True)
    with fitz.open(source) as doc:
        doc.set_metadata({key: '' for key in ('title', 'author', 'subject', 'keywords', 'creator', 'producer', 'creationDate', 'modDate', 'trapped')})
        doc.xref_set_key(-1, 'Info', 'null')
        doc.del_xml_metadata()
        doc.save(destination, garbage=4, deflate=True)
    with fitz.open(destination) as doc:
        assert not doc.get_xml_metadata()
        assert not any(v for k, v in doc.metadata.items() if k not in ('format', 'encryption'))
    return destination

def clean_svg(source, destination):
    source, destination = Path(source), Path(destination)
    root = ET.fromstring(source.read_bytes())
    for parent in root.iter():
        for child in list(parent):
            if child.tag.split('}')[-1] == 'metadata':
                parent.remove(child)
    ET.register_namespace('', 'http://www.w3.org/2000/svg')
    ET.register_namespace('xlink', 'http://www.w3.org/1999/xlink')
    destination.parent.mkdir(parents=True, exist_ok=True)
    ET.ElementTree(root).write(destination, encoding='utf-8', xml_declaration=True)
    return destination

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('destination', type=Path)
    args = parser.parse_args()
    if args.source.suffix.lower() == '.pdf': clean_pdf(args.source, args.destination)
    elif args.source.suffix.lower() == '.svg': clean_svg(args.source, args.destination)
    else: parser.error('Only PDF and SVG are supported.')
