"""Two-stage reconstruction of the exact author-supplied paper figures.

Historical geometry/content is frozen first. The current-content deck is derived
from its native PPTX, retaining source modules and pictograms where appropriate.
"""
from pathlib import Path
import sys,json,math,copy,shutil,subprocess,os,zipfile,hashlib
import fitz,numpy as np
from PIL import Image,ImageFont
from pptx import Presentation
from pptx.util import Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE,MSO_CONNECTOR
from pptx.enum.text import PP_ALIGN,MSO_ANCHOR
from pptx.oxml.xmlchemy import OxmlElement
from lxml import etree
import math_tools

HERE=Path(__file__).resolve().parent;R=HERE.parent
sys.path.append(str(R.parent/'image_pipeline_20260925/runtime-venv/lib/python3.12/site-packages'))
from super_img2ppt.render import LibreOfficeRenderer
ANS=math_tools.ANS
BLUE='0900FA';GREEN='00621C';RED='FF0709';TEAL='0085A0';PURPLE='50227B';ORANGE='F45C1A';BLACK='101010';GRAY='69727B'

class Deck:
 def __init__(self,n,kind,width,height,from_ppt=None):
  self.n=n;self.kind=kind;self.W=width;self.H=height;self.s=396/width
  self.dir=HERE/kind/f'figure{n}';self.dir.mkdir(parents=True,exist_ok=True)
  self.prs=Presentation(from_ppt) if from_ppt else Presentation()
  if from_ppt:
   self.sl=self.prs.slides[0]
   self.source_objects={}
   def collect(shapes):
    for sh in shapes:
     self.source_objects[sh.name]=copy.deepcopy(sh._element)
     if sh.shape_type==6:collect(sh.shapes)
   collect(self.sl.shapes)
   for sh in list(self.sl.shapes):self.sl.shapes._spTree.remove(sh._element)
   self.prs.slide_width=Pt(396);self.prs.slide_height=Pt(height*self.s)
  else:
   self.prs.slide_width=Pt(396);self.prs.slide_height=Pt(height*self.s);self.sl=self.prs.slides.add_slide(self.prs.slide_layouts[6])
  self.rows=[];self.elements=[];self.groups={};self.module=None;self.fonts=[];self.rasters=[]
 def reuse(self,id,x,y,w,h,newid=None):
  el=copy.deepcopy(self.source_objects[id]);self.sl.shapes._spTree.insert_element_before(el,'p:extLst');sh=self.sl.shapes[-1]
  sh.name=newid or id;sh.left=Pt(x*self.s);sh.top=Pt(y*self.s);sh.width=Pt(w*self.s);sh.height=Pt(h*self.s)
  self.record(sh.name,'reused_native',[x,y,w,h],from_object=id)
  if sh.shape_type==13:self.rasters.append(dict(id=sh.name,source='faithful baseline pictogram',contains_text=False))
  return sh
 def record(self,id,kind,box=None,**kw):
  self.elements.append(dict(id=id,kind=kind,box=box,module=self.module,**kw))
  if self.module:self.groups.setdefault(self.module,[]).append(id)
 def shape(self,id,x,y,w,h,fill=None,line=BLACK,lw=1.5,round=False,ellipse=False):
  sh=self.sl.shapes.add_shape(MSO_SHAPE.OVAL if ellipse else MSO_SHAPE.ROUNDED_RECTANGLE if round else MSO_SHAPE.RECTANGLE,*[Pt(v*self.s) for v in (x,y,w,h)]);sh.name=id
  if round:sh.adjustments[0]=.025
  if fill:sh.fill.solid();sh.fill.fore_color.rgb=RGBColor.from_string(fill)
  else:sh.fill.background()
  if line:sh.line.color.rgb=RGBColor.from_string(line);sh.line.width=Pt(lw*self.s)
  else:sh.line.fill.background()
  math_tools.clean(sh);self.record(id,'shape',[x,y,w,h],fill=fill,stroke=line,stroke_width=lw);return sh
 def text(self,id,t,x,y,w,h,size=28,bold=False,color=BLACK,align='center',italic=False):
  if self.kind=='faithful':
   font=ImageFont.truetype('/usr/share/fonts/truetype/liberation2/LiberationSerif-'+('Bold' if bold else 'Regular')+'.ttf',round(size*10))
   extent=max(font.getlength(line)/10 for line in t.split('\n'))
   size*=min(1,(w-2)/max(extent,1))
  sh=self.sl.shapes.add_textbox(*[Pt(v*self.s) for v in (x,y,w,h)]);sh.name=id;tf=sh.text_frame
  tf.margin_left=tf.margin_right=tf.margin_top=tf.margin_bottom=0;tf.word_wrap=False;tf.vertical_anchor=MSO_ANCHOR.MIDDLE
  for i,line in enumerate(t.split('\n')):
   p=tf.paragraphs[0] if i==0 else tf.add_paragraph();p.alignment={'left':PP_ALIGN.LEFT,'right':PP_ALIGN.RIGHT,'center':PP_ALIGN.CENTER}[align];p.space_after=Pt(0);p.space_before=Pt(0)
   p.line_spacing=1.0;r=p.add_run();r.text=line;r.font.name='Liberation Serif';r.font.size=Pt(size*self.s);r.font.bold=bold;r.font.italic=italic;r.font.color.rgb=RGBColor.from_string(color)
  self.record(id,'text',[x,y,w,h],text=t,font_size=size,font_family='Liberation Serif',bold=bold,color=color);self.fonts.append(size*self.s);return sh
 def line(self,id,points,color=BLACK,width=1.5,arrow=False,dash=False):
  x=min(p[0] for p in points);y=min(p[1] for p in points);w=max(p[0] for p in points)-x;h=max(p[1] for p in points)-y
  # One editable custom path, including continuous exterior feedback loops.
  sh=self.shape(id,x,y,max(w,.01),max(h,.01),None,color,width)
  sp=sh._element.spPr
  for e in list(sp):
   if e.tag.endswith('prstGeom'):sp.remove(e)
  geom=OxmlElement('a:custGeom')
  for tag in ['avLst','gdLst','ahLst','cxnLst']:geom.append(OxmlElement('a:'+tag))
  rect=OxmlElement('a:rect')
  for k,v in dict(l='0',t='0',r='r',b='b').items():rect.set(k,v)
  geom.append(rect);pl=OxmlElement('a:pathLst');p=OxmlElement('a:path');p.set('w',str(max(1,Pt(w*self.s))));p.set('h',str(max(1,Pt(h*self.s))));p.set('fill','none')
  for j,(a,b) in enumerate(points):
   q=OxmlElement('a:moveTo' if j==0 else 'a:lnTo');pt=OxmlElement('a:pt');pt.set('x',str(Pt((a-x)*self.s)));pt.set('y',str(Pt((b-y)*self.s)));q.append(pt);p.append(q)
  pl.append(p);geom.append(pl);sp.insert(1,geom)
  ln=sp.find('{'+ANS+'}ln')
  if dash:
   q=OxmlElement('a:prstDash');q.set('val','dash');ln.append(q)
  if arrow:
   q=OxmlElement('a:tailEnd');q.set('type','triangle');q.set('w','sm');q.set('len','sm');ln.append(q)
  self.elements[-1].update(kind='line',points=points,arrow=arrow,dash=dash);return sh
 def eq(self,id,t,x,y,w,h,size=30,color=BLACK):
  self.rows.append((id,t,[v*self.s for v in (x,y,w,h)],size*self.s,color));self.record(id,'formula',[x,y,w,h],latex=t,font_size=size,color=color)
 def icon(self,id,source,roi,x,y,w,h):
  p=self.dir/(id+'.png');Image.open(HERE/'source'/f'Figure{source}_original.png').crop(roi).save(p)
  sh=self.sl.shapes.add_picture(str(p),*[Pt(v*self.s) for v in (x,y,w,h)]);sh.name=id
  self.rasters.append(dict(id=id,source=f'Figure{source}_original.png',crop=roi,contains_text=False));self.record(id,'image',[x,y,w,h],path=p.name);return sh
 def panel(self,id,x,y,w,h,color):
  self.module=id;self.shape(id+'_border',x,y,w,h,'FFFFFF',color,1.8 if self.kind=='faithful' else .55,True)
 def matrix(self,id,x,y,w,h,color=GREEN,n=4,values=None,slant=0,ncols=None):
  start=len(self.elements);pale='F1F7F1' if color==GREEN else 'EEF1FA' if color==BLUE else 'F3EDF8'
  nc=ncols or n
  for a in range(n):
   for b in range(nc):
    xx=x+b*w/nc+(n-a-1)*slant;yy=y+a*h/n
    fill=pale if values else color if a==b or (a+b)%5==1 else pale
    if self.kind=='faithful' and not slant and not values:
     source=Image.open(HERE/'source'/f'Figure{self.n}_original.png').convert('RGB')
     rgb=source.getpixel((int(xx+w/nc*.5),int(yy+h/n*.5)));fill=''.join(f'{v:02X}' for v in rgb)
    self.shape(f'{id}_{a}_{b}',xx,yy,w/nc,h/n,fill,color,.9)
    if values:self.text(f'{id}_v{a}_{b}',str(values[a][b]),xx,yy,w/nc,h/n,20,True,color)
  return [e['id'] for e in self.elements[start:]]
 def graph(self,id,x,y,w,h,color=BLUE,hard=False,target=False):
  ps=[(0,0),(.34,0),(.68,0),(0,.5),(.34,.5),(.68,.5),(1,.5),(0,1),(.34,1),(.68,1)]
  es=[(0,1),(1,2),(0,3),(1,4),(2,5),(3,4),(4,5),(5,6),(3,7),(4,8),(5,9),(8,5)]
  pts=[(x+a*w,y+b*h) for a,b in ps]
  r=w*.045
  for i,(a,b) in enumerate(es):
   p,q=pts[a],pts[b];dx=q[0]-p[0];dy=q[1]-p[1];L=math.hypot(dx,dy);p=(p[0]+dx/L*r,p[1]+dy/L*r);q=(q[0]-dx/L*r,q[1]-dy/L*r)
   bad=hard and i==1;self.line(f'{id}_e{i}',[p,q],RED if bad else color,(2.8 if target and i in (2,5,6,7) else 1.3)*(1 if self.kind=='faithful' else .4),not bad,bad)
   if bad:
    mx=(p[0]+q[0])/2;my=(p[1]+q[1])/2
    for j,sgn in enumerate((-1,1)):self.line(f'{id}_x{j}',[(mx-r*.6,my-sgn*r*.6),(mx+r*.6,my+sgn*r*.6)],RED,2 if self.kind=='faithful' else .7)
  for i,(a,b) in enumerate(pts):self.shape(f'{id}_n{i}',a-r,b-r,2*r,2*r,'F2F7FC',color,1.5 if self.kind=='faithful' else .55,ellipse=True)
 def trace(self,id,folder,box=None):
  data=json.loads((HERE/folder/'elements.json').read_text());data=data if isinstance(data,list) else data['elements']
  pts=[data[0]['points'][0]]+[e['points'][1] for e in data]
  if box:
   src=(80,280,389,211) if 'left' in folder else (1460,335,358,141);x,y,w,h=box;pts=[(x+(a-src[0])*w/src[2],y+(b-src[1])*h/src[3]) for a,b in pts]
  self.line(id,pts,BLUE if 'left' in folder else RED,2.0 if self.kind=='faithful' else .65)
 def formulas(self):
  math_tools.OUT=self.dir/'math';math_tools.OUT.mkdir(exist_ok=True)
  md=math_tools.typeset(self.rows,self.n,self.kind=='faithful');doc=fitz.open(md/'equations.pdf');audit=[]
  svgs=sorted(md.glob('eq-*.svg'),key=lambda p:int(p.stem.split('-')[-1]))
  for row,page,svg in zip(self.rows,doc,svgs):
   id,tex,box,size,col=row
   if self.kind=='faithful':
    # Match the source's condensed math without shifting surrounding modules.
    bw,bh=page.rect.width,page.rect.height
    a=math_tools.import_formula(self.sl,svg,id,[box[0],box[1],max(bw,box[2]),max(bh,box[3])],col,page.rect)
    sh=self.sl.shapes[-1];sx=min(1,box[2]/bw);sy=min(1,box[3]/bh)
    sh.width=int(sh.width*sx);sh.height=int(sh.height*sy);sh.left=Pt(box[0]+(box[2]-bw*sx)/2);sh.top=Pt(box[1]+(box[3]-bh*sy)/2)
    a.update(source_horizontal_scale=sx,source_vertical_scale=sy,allocated_box=box,fits=True)
   else:a=math_tools.import_formula(self.sl,svg,id,box,col,page.rect)
   a.update(latex=tex,minimum_math_pt=min(s['size'] for b in page.get_text('dict')['blocks'] for l in b.get('lines',[]) for s in l['spans'] if s['text'].strip()))
   audit.append(a)
  (self.dir/'formula_audit.json').write_text(json.dumps(audit,indent=2));return audit
 def save(self):
  audit=self.formulas()
  for module,names in self.groups.items():
   members=[s for s in self.sl.shapes if s.name in names]
   if len(members)<2:continue
   idx=list(self.sl.shapes._spTree).index(members[0]._element);g=self.sl.shapes.add_group_shape();g.name='module_'+module
   for s in members:g._element.append(s._element)
   g._element.recalculate_extents();self.sl.shapes._spTree.remove(g._element);self.sl.shapes._spTree.insert(idx,g._element)
  for key in ['author','last_modified_by','comments','subject','keywords']:setattr(self.prs.core_properties,key,'')
  for idx,el in enumerate(self.sl._element.findall('.//{http://schemas.openxmlformats.org/presentationml/2006/main}cNvPr'),1):el.set('id',str(idx))
  self.prs.core_properties.title=f'Figure {self.n} '+('historical reconstruction' if self.kind=='faithful' else 'SafeOT')
  if self.sl.has_notes_slide:self.sl.notes_slide.notes_text_frame.text=''
  stem=f'Figure{self.n}_'+('OriginalEditable' if self.kind=='faithful' else 'SafeOT_Adapted')
  ppt=self.dir/(stem+'.pptx');self.prs.save(ppt)
  render=self.dir/'render';j=1
  while render.exists():j+=1;render=self.dir/f'render_{j:02d}'
  pdf=LibreOfficeRenderer('/usr/bin/soffice',timeout=60).render(ppt,render)
  d=fitz.open(pdf);d.set_metadata({});d.del_xml_metadata();d.save(self.dir/(stem+'.pdf'),garbage=4,deflate=True)
  p=d[0];p.get_pixmap(dpi=300).save(self.dir/(stem+'_300dpi.png'));(self.dir/(stem+'.svg')).write_text(p.get_svg_image(text_as_path=False))
  p.get_pixmap(matrix=fitz.Matrix(self.W/p.rect.width,self.W/p.rect.width)).save(self.dir/'source_size_render.png')
  Image.open(self.dir/(stem+'_300dpi.png')).convert('L').save(self.dir/(stem+'_grayscale.png'))
  text=[s for b in p.get_text('dict')['blocks'] for l in b.get('lines',[]) for s in l['spans'] if s['text'].strip()]
  report=dict(status='review',visual_review='required',figure=self.n,branch=self.kind,width_in=p.rect.width/72,height_in=p.rect.height/72,minimum_text_pt=min(s['size'] for s in text),minimum_math_pt=min(a['minimum_math_pt'] for a in audit),formula_overflow=[a['id'] for a in audit if not a['fits']],font='Liberation Serif; newtx math',remaining_rasters=self.rasters,formulas='Editable vector contours with LaTeX source; not semantic OfficeMath',renderer='LibreOffice actual PPTX via super_img2ppt',PowerPoint_verified=False)
  (self.dir/'validation.json').write_text(json.dumps(report,indent=2));(self.dir/'scene.resolved.json').write_text(json.dumps(dict(source_units='pixels',width=self.W,height=self.H,scale_to_pt=self.s,elements=self.elements,groups=self.groups),indent=2))
  (self.dir/'equations.json').write_text(json.dumps(self.rows,indent=2));print(stem,json.dumps(report));return ppt

def faithful1():
 d=Deck(1,'faithful',1880,837)
 d.panel('penalty',10,8,507,614,BLUE);d.text('left_title','Soft penalty objective',30,15,470,53,38,True,BLUE)
 d.eq('left_obj',r'\max\quad J_\tau-\lambda^\top J_c',94,72,326,47,32)
 d.text('left_st','s.t.',162,112,70,35,30);d.eq('left_tau',r'\tau\to\infty',202,140,165,42,32)
 d.eq('left_vector',r'J_\tau=[J_{c1},\ldots,J_{cN}]^\top,\quad\lambda=[\lambda_1,\ldots,\lambda_N]^\top',30,196,465,52,28)
 d.line('left_x',[(66,518),(500,518)],BLACK,1.7,True);d.line('left_y',[(66,519),(66,271)],BLACK,1.7,True)
 d.line('left_bound',[(67,367),(498,367)],RED,1.4,dash=True);d.eq('left_J',r'J_\tau',20,264,38,36,28);d.eq('left_b',r'b_k',19,341,41,41,30,RED)
 d.trace('left_curve','trace_left');d.line('leakage_arrow',[(390,361),(390,301)],RED,1.5,True);d.line('leakage_down',[(390,305),(390,361)],RED,1.5,True)
 d.text('leakage','leakage',406,319,90,33,28,color=RED);d.text('left_episodes','episodes',404,475,96,33,26)
 d.eq('left_annotation',r'\text{fixed-}\lambda\ \text{penalty: some safety tasks reward }b_k',42,545,440,32,25,BLUE)
 d.text('left_weakness','weakness: constant leakage',60,582,420,32,25,color=RED)
 d.panel('bridge',530,8,836,614,GREEN);d.text('middle_title','SafeTransport',728,7,445,52,45,True,GREEN);d.eq('middle_sub',r'\text{safe }\gamma\text{-flow bridge}',778,58,353,44,31)
 d.text('constraints_title','1. Constraints',563,97,250,43,33,True,GREEN);d.text('compress_title','2. Compress',873,105,222,44,33,True,GREEN);d.text('solve_title','3. Solve',1153,99,195,39,33,True,GREEN);d.text('sinkhorn_label','(OFT-Sinkhorn)',1152,136,195,30,24,True,GREEN)
 for x in (829,1112):d.line(f'separator{x}',[(x,111),(x,595)],GREEN,1.4,dash=True)
 colors=[BLUE,TEAL,BLACK,RED];labels=['Bridge','Liquid','Excavator','Fire'];ys=[173,267,360,454]
 rois=[(545,182,594,250),(545,279,594,335),(545,369,594,433),(545,463,595,537)]
 vals=[['0.35  1.60  0.21','0.65  1.60  0.55','0.15  1.60  0.35'],['0.30  1.60  0.15','0.30  1.60  0.35','0.20  1.60  0.55'],['0.20  1.60  0.12','0.25  1.60  0.25','0.20  1.60  0.35'],['0.15  1.60  0.13','0.20  1.60  0.15','0.20  1.60  0.15']]
 for i,(y,c,l,roi) in enumerate(zip(ys,colors,labels,rois)):
  d.shape(f'costcard{i}',539,y,264,86,'FFFFFF',c,1.2,True);d.line(f'costdivide{i}',[(675,y),(675,y+86)],c,1)
  d.icon(f'costicon{i}',1,roi,545,y+9,49,roi[3]-roi[1]);d.text(f'costname{i}',l,598,y+9,73,30,25 if i!=2 else 18,color=c)
  d.eq(f'S{i}',rf'S_{{{i+1}}}',606,y+46,50,30,27,c)
  d.text(f'costvalues{i}','\n'.join(vals[i]),682,y+7,116,68,18,color=c)
 d.shape('compression',861,169,218,85,'FFFFFF',GREEN,1.5,True);d.text('compression_name','uniform compression',870,176,202,27,24,color=GREEN);d.eq('compression_eq',r'S=\min_i S_i',883,211,180,35,30)
 for i,c in enumerate(colors):
  y=279+i*48
  for r in range(2):
   for k in range(4):
    pts=[(908+k*34-r*9,y+r*20),(942+k*34-r*9,y+r*20),(933+k*34-r*9,y+(r+1)*20),(899+k*34-r*9,y+(r+1)*20),(908+k*34-r*9,y+r*20)]
    d.line(f'stack{i}_{r}_{k}',pts,c,1.4)
  d.eq(f'stacklabel{i}',rf'S_{{{i+1}}}',1047,y+6,49,33,28,c)
 d.line('into_stack',[(836,362),(868,362)],GREEN,12,True);d.eq('stack_S',r'S=',834,389,58,40,31);d.text('uniform_min','uniform minimum',853,517,229,39,30,True,GREEN)
 d.shape('solvebox',1143,187,190,91,'FFFFFF',GREEN,1.5,True);d.text('solvetext','▸ OFT-Sinkhorn\n+ PPO',1147,196,182,70,28,True,GREEN)
 d.eq('P',r'P=',1124,368,60,51,32);d.matrix('Pgrid',1186,314,161,158,GREEN,3,[['0.45','0.45','0.21'],['0.65','0.55','0.02'],['0.12','0.34','0.34']]);d.text('transport','transport matrix',1151,502,206,42,28,True,GREEN);d.eq('certificate',r'P^\top\le S',1180,560,145,48,36)
 d.panel('hard',1378,8,491,614,RED);d.text('hard_title','Hard CMDP budget',1400,17,448,51,38,True,RED);d.eq('hard_obj',r'\max\quad J_\tau\quad\mathrm{s.t.}\quad J_c\le b',1430,77,401,47,33);d.eq('hard_tau',r'\tau\to0',1520,132,139,42,32)
 d.eq('hard_vector',r'J_\tau=[J_{c1},\ldots,J_{cN}]^\top,\quad b=[b_1,\ldots,b_N]^\top',1396,194,460,52,28)
 d.line('hard_x',[(1443,517),(1856,517)],BLACK,1.7,True);d.line('hard_y',[(1443,518),(1443,271)],BLACK,1.7,True);d.eq('hard_J',r'J_\tau',1395,264,42,40,28)
 for i,y in enumerate([349,390]):d.line('hardbound'+str(i),[(1443,y),(1848,y)],RED,1.3,dash=True)
 d.eq('hard_b1',r'b_1',1390,321,40,41,30,RED);d.eq('hard_bK',r'b_K',1390,432,44,44,30,RED);d.text('dots','⋮',1402,377,23,43,32)
 d.trace('oscillation','trace_right_02');d.text('hard_episodes','episodes',1750,476,98,32,26)
 d.eq('hard_annotation',r'\text{dual updates: safety costs oscillate around }b_k',1396,540,462,38,25,RED);d.text('hard_weak','weakness: oscillation / brittleness',1420,579,425,33,25,color=RED)
 d.module='spectrum';d.eq('tauinf',r'\tau=\infty',12,654,128,45,38,BLUE);d.eq('tauzero',r'\tau=0',1740,654,115,46,38,RED);d.text('soft_end','soft penalty',14,738,147,42,31,color=BLUE);d.text('hard_end','hard budget',1730,738,143,42,31,color=RED)
 # LibreOffice 7.3 truncates an Office multi-stop gradient to its first two stops.
 # A grouped sampled vector strip preserves the original colors in actual export.
 stops=[(0,BLUE),(.32,TEAL),(.49,'008000'),(.70,'FF9800'),(1,RED)]
 for j in range(160):
  t=(j+.5)/160
  for (a,c),(b,e) in zip(stops,stops[1:]):
   if a<=t<=b:
    v=(t-a)/(b-a);rgb=[round(int(c[k:k+2],16)*(1-v)+int(e[k:k+2],16)*v) for k in (0,2,4)];break
  d.shape('spectrum_strip'+str(j),162+j*1550/160,711,1550/160+.1,12,''.join(f'{q:02X}' for q in rgb),None,0)
 for i,(x,t,c) in enumerate([(331,'PPO / SAC',BLUE),(652,'FOCOPS',TEAL),(1258,'CPO','FF8A00'),(1543,'hard-constraint / CUP',RED)]):
  d.text('marktext'+str(i),t,x-150,655,300,42,31);d.shape('mark'+str(i),x-11,702,22,29,c,'FFFFFF',3,ellipse=True)
 d.shape('spectrum_safe',798,675,285,80,'005B16',None,0,True);d.text('spectrum_name','SafeTransport',820,680,245,65,41,True,'FFFFFF');return d.save()

def faithful2():
 d=Deck(2,'faithful',1672,941)
 boxes=[(11,64,260,801),(300,64,323,801),(649,64,265,801),(940,64,389,801),(1352,64,304,801)]
 titles=['Rollout','Build flow inputs','Compose\ncapacities','Safe flow projection','Weighted PPO update'];cols=['002EAA','002EAA','006B24','006B24','FF5800']
 for i,((x,y,w,h),title,c) in enumerate(zip(boxes,titles,cols),1):
  d.panel(f'stage{i}',x,y,w,h,c);d.shape(f'badge{i}',x+36,94,52,56,c,None,0,ellipse=True);d.text(f'number{i}',str(i),x+36,95,52,52,43,False,'FFFFFF');d.text(f'title{i}',title,x+100,100,w-111,76 if i==3 else 49,31 if i!=5 else 29,True)
 d.module='stage1';d.eq('samples',r's_t\quad a_t\quad r_t\quad c_{s,t}',51,296,190,45,30);d.icon('world',2,(15,351,66,411),18,352,49,57);d.icon('robot',2,(228,341,268,420),229,342,37,76)
 for i in range(3):d.shape(f'trajnode{i}',77+i*44,370,15,17,'002EAA',None,0,ellipse=True)
 d.line('trajectory',[(84,379),(223,379)],'002EAA',2,True);d.text('trajectory_dots','···',187,358,33,36,32,color='002EAA');d.eq('nextstate',r's_{t+1}',102,424,65,39,31)
 d.text('collect','Collect transitions',41,622,204,43,29);d.eq('tuple',r'(s_t,a_t,r_t,\{c_{k,t}\},s_{t+1})',19,678,244,50,28)
 d.module='stage2';d.text('graph_title','Discrete state graph',329,180,269,44,30);d.graph('graph',365,253,197,119,'002EAA');d.line('input_rule',[(316,434),(604,434)],BLUE,2)
 for id,y,c,tex in [('emp',465,'002EAA',r'\text{empirical flow }\hat F'),('score',588,PURPLE,r'\text{score matrix }D'),('cap',715,GREEN,r'\text{capacities }S^{(k)}')]:
  d.matrix(id,330,y,72,96,c);d.eq(id+'_label',tex,410,y+19,201,56,27,'002EAA' if id!='cap' else GREEN)
 d.module='stage3'
 for j,x in enumerate([662,743,847]):
  d.eq(f'cap_label{j}',[r'S^{(1)}',r'S^{(2)}',r'S^{(K)}'][j],x+2,217,57,43,31);d.matrix(f'capmini{j}',x,266,59,78,GREEN)
 d.text('capellipsis','···',810,273,32,48,32);d.line('compose_brace',[(662,365),(666,380),(775,380),(780,390),(785,380),(901,380),(901,365)],GREEN,2);d.line('brace_arrow',[(780,383),(780,424)],GREEN,3,True)
 d.eq('composed_S',r'S',756,438,52,43,35);d.matrix('composed',730,493,99,128,GREEN)
 d.shape('composebox',659,681,245,153,'FFFFFF',GREEN,1.6,True);d.eq('composeeq',r'S=\mathrm{Compose}_\varepsilon(\{S^{(k)}\})',666,700,232,52,29);d.text('one_matrix','one matrix, not K duals',672,774,221,39,26)
 d.module='stage4';d.shape('projection_formula_box',950,194,369,85,'FFFFFF',GREEN,1.5,True);d.eq('projection_eq',r'F^*=\gamma\text{-Flow-Sinkhorn}(D,\hat F,S,\varepsilon)',964,212,341,51,29)
 d.text('iterations','Sinkhorn iterations',1002,319,270,46,31);d.eq('kernel',r'K_{ij}=e^{-D_{ij}/\varepsilon}',941,413,120,52,25)
 for id,t,x,w in [('row','row\nscaling',1080,61),('col','col\nscaling',1160,64),('projected','projected\nflow F*',1239,79)]:d.text('iter_'+id,t,x,382,w,67,25)
 d.matrix('kernelgrid',964,473,72,94,PURPLE);d.matrix('rowgrid',1085,465,43,101,PURPLE,4,ncols=2);d.matrix('colgrid',1173,465,35,101,PURPLE,4,ncols=1);d.matrix('projectedgrid',1249,469,66,98,PURPLE)
 for j,x in enumerate([1048,1135,1216]):d.line('iterarrow'+str(j),[(x,514),(x+26,514)],GREEN,6,True)
 d.line('repeat',[(998,614),(998,662),(1005,667),(1272,667),(1276,660),(1276,615)],GREEN,2.2,True);d.text('repeat_label','repeat to convergence',1021,622,233,35,24)
 d.shape('certbox',994,750,270,80,'EFF7EC',GREEN,1.4,True);d.eq('cert',r'\text{certificate: }F^*\le S',1010,769,240,46,29,GREEN)
 d.module='stage5';d.text('weights','weights',1418,183,159,43,29);d.shape('weight_box',1367,238,279,117,'FFF6ED','FF5800',1.3,True);d.eq('weight_eq',r'w_t=\mathrm{clip}\left(\frac{F^*}{\max(\hat F,\delta)}\right)',1381,250,246,93,31)
 d.text('ppo_label','PPO objective (clipped)',1374,395,265,43,29);d.shape('ppo_box',1359,452,289,161,'FFF6ED','FF5800',1.3,True)
 d.eq('ppo_eq1',r'\mathcal L(\theta)=\mathbb E_t\left[w_t\min\left(r_t\hat A_t,\right.\right.',1366,473,279,51,30);d.eq('ppo_eq2',r'\left.\left.\mathrm{clip}(r_t,1-\delta_{\rm clip},1+\delta_{\rm clip})\hat A_t\right)\right]',1367,535,278,53,25)
 d.line('actor_down',[(1502,630),(1502,679)],'FF5800',3,True);d.eq('updated_policy',r'\text{updated policy }\pi_\theta',1396,698,229,49,29)
 d.icon('robot_next',2,(1367,737,1414,821),1368,738,46,82);pts=[(1440,819),(1477,809),(1508,784),(1542,807),(1576,803),(1605,769),(1630,737)]
 d.line('nexttraj',pts,'FF5800',2.3,True)
 for i,(x,y) in enumerate(pts[:-1]):d.shape('nextnode'+str(i),x-6,y-6,12,12,'FF5800',None,0,ellipse=True)
 d.module=None
 for i,x in enumerate([267,620,911,1326]):d.line('main_arrow'+str(i),[(x,493),(x+34,493)],'003CA6',8,True)
 return d.save()

def adapted1():
 d=Deck(1,'adapted',396,237.6,HERE/'faithful/figure1/Figure1_OriginalEditable.pptx')
 # Keep the exact three-column grammar, the two source curves and four cost pictograms.
 d.panel('penalty',2,3,98,172,BLUE)
 d.text('left_title','Penalty view',6,8,90,14,11,True,BLUE)
 d.text('left_sub','Costs enter the objective',6,25,90,12,8.2)
 d.eq('objective',r'A_r-\sum_k\lambda_k A_{c_k}',5,41,92,24,10)
 d.line('left_x',[(15,124),(95,124)],BLACK,.65,True);d.line('left_y',[(15,125),(15,76)],BLACK,.65,True)
 d.line('left_budget',[(15,104),(94,104)],RED,.6,dash=True);d.eq('left_B',r'B_k',2,92,15,15,10,RED)
 d.reuse('left_curve',18,79,70,43)
 d.text('leakage_label','budget leakage',25,69,67,10,8.2,color=RED)
 d.line('leakage_leader',[(71,80),(75,91)],RED,.6)
 d.text('left_x_label','training',60,126,34,11,8.2)
 d.text('left_note','Fixed price can leave\na budget violated.',8,142,88,22,8.2)
 d.text('left_schematic','(schematic)',9,163,86,10,8.2,color=GRAY)
 d.panel('safeot',105,3,186,172,GREEN);d.text('safeot_title','SafeOT',135,7,127,18,14,True,GREEN)
 d.text('subtitle','One flow prices all budgets',112,28,172,12,9,True,GREEN)
 d.text('costs_title','1. Costs',112,45,43,12,9,True,GREEN);d.text('solve_title','2. Flow solve',171,45,110,12,9,True,GREEN)
 for i,y in enumerate([61,80,99,118]):
  d.shape('costcard'+str(i),112,y,45,17,'FFFFFF',[BLUE,TEAL,BLACK,RED][i],.4,True)
  d.reuse('costicon'+str(i),114,y+1,10,15)
  d.eq('cost'+str(i),[r'C_1',r'C_2',r'C_3',r'C_K'][i],128,y-1,25,18,10,[BLUE,TEAL,BLACK,RED][i])
 d.line('to_solve',[(157,90),(167,90)],GREEN,1.8,True)
 d.graph('flow',174,64,97,34,GRAY,hard=True,target=False)
 # Native overlaid target path in the existing graph; two line weights plus color.
 for i,pts in enumerate([[(174,81),(207,81)],[(207,81),(240,81)],[(240,81),(270,81)]]):d.line('target'+str(i),[(x,y+2.2) for x,y in pts],GREEN,1.6,True)
 d.eq('budgets',r'\langle C_k,F\rangle\le b_k',168,104,115,20,10)
 d.text('entropy','flow balance · entropy',164,122,122,11,8.2,color=GREEN)
 d.text('flow_key','gray: observed · green: target',162,137,124,11,8.2,color=GRAY)
 d.text('hard_key','× hard event: excluded edge',161,151,125,11,8.2,color=RED)
 d.panel('budget',296,3,98,172,RED);d.text('right_title','Budget view',300,8,90,14,11,True,RED)
 d.text('right_sub','Budgets constrain costs',300,25,90,12,8.2);d.eq('budget_objective',r'J_{c_k}(\pi)\le B_k',300,43,89,21,10)
 d.line('right_x',[(309,124),(389,124)],BLACK,.65,True);d.line('right_y',[(309,125),(309,76)],BLACK,.65,True);d.line('right_budget',[(309,95),(389,95)],RED,.6,dash=True)
 d.reuse('oscillation',311,83,74,36);d.eq('right_B',r'B_k',296,90,15,17,10,RED);d.text('right_x_label','training',354,126,34,11,8.2)
 d.text('right_note','Feedback-only prices\ncan react late and oscillate.',299,141,92,22,8.2);d.text('right_schematic','(schematic)',300,164,90,10,8.2,color=GRAY)
 # Price bridge is the readable center-to-actor outlet, replacing the obsolete matrix certificate.
 d.module='price_bridge';d.shape('price_band',4,178,388,25,'F2F7F1',GREEN,.5,True)
 d.eq('raw_duals',r'\lambda_k^*',6,182,22,17,10,GREEN);d.line('raw_to_filter',[(27,191),(35,191)],GREEN,.6,True)
 d.text('filter','clip + EMA',36,182,46,17,8.2,color=GREEN);d.line('filter_to_price',[(83,191),(91,191)],GREEN,.6,True)
 d.eq('combined',r'\lambda_k=\bar\lambda_k^*+\beta_k',93,182,105,17,10,GREEN)
 d.text('feedback_note','observed-cost\nfeedback',200,179,52,23,8.2,color=ORANGE)
 d.line('price_to_actor',[(254,191),(265,191)],GREEN,.7,True);d.text('actor','priced actor',265,182,48,17,8.2,True);d.text('algorithm','PPO/TRPO',316,182,46,17,8.2)
 d.line('actor_next',[(363,191),(369,191)],GRAY,.6,True);d.eq('pi_next',r'\pi_{t+1}',369,182,23,17,10)
 d.module='spectrum';d.text('one_rule','One price rule',3,203,65,11,9,True,GREEN)
 d.text('exact','exact settings',70,203,106,11,8.2,color=GRAY);d.text('limits','conditional limits',255,203,135,11,8.2,color=GRAY)
 xs=[3,83,172,229,279];ws=[76,85,52,45,111];names=['Fixed penalty','Lagrangian','SafeOT','LP','Active-set']
 for i,(a,b,c) in enumerate([(18,128,BLUE),(128,203,GREEN),(203,252,GREEN),(252,380,RED)]):d.line('spectrum_axis'+str(i),[(a,225),(b,225)],c,.75)
 d.shape('ours_marker',172,214,52,10.5,GREEN,None,0,True)
 for i,(x,w,t) in enumerate(zip(xs,ws,names)):
  d.text('setting'+str(i),t,x,214,w,10,8.5,True,'FFFFFF' if i==2 else BLACK)
 for id,t,x,w in [('fixed',r'c=0,\ \beta\ \text{fixed}',3,80),('lag',r'c=0,\ \beta\ \text{adaptive}',84,86),('finite',r'\text{finite }\varepsilon',172,55),('lp',r'\varepsilon\to0',227,45),('active_setting',r'\varepsilon\to\infty,\ \text{saturated clip}',277,115)]:d.eq(id,t,x,227,w,10.5,8.3)
 # Pre-violation advantage is a central callout rather than a quantitative result.
 d.text('advance_price','can price before violation',138,162,143,11,8.2,True,GREEN)
 return d.save()

def adapted2():
 d=Deck(2,'adapted',396,237.6,HERE/'faithful/figure2/Figure2_OriginalEditable.pptx')
 # Five side-by-side steps are retained; only their widths change to fit current equations.
 boxes=[(3,6,43,201),(51,6,58,201),(114,6,64,201),(183,6,96,201),(284,6,109,201)]
 titles=['Rollout','Flow\ninputs','Budgets &\nhard edges','Entropic\nprojection','Priced\npolicy update'];cols=[GRAY,'003EA8',GREEN,GREEN,GRAY]
 for i,((x,y,w,h),t,c) in enumerate(zip(boxes,titles,cols),1):
  d.panel(f'stage{i}',x,y,w,h,c);d.shape(f'badge{i}',x+4,12,13,13,c,None,0,ellipse=True);d.text(f'number{i}',str(i),x+4,12,13,13,10,True,'FFFFFF')
  d.text(f'title{i}',t,x+2 if i==1 else x+19,27 if i==1 else 9,w-4 if i==1 else w-21,12 if i==1 else 24,8.8,True,c,align='center' if i==1 else 'left')
 d.module='stage1';d.text('policy_label','policy',7,44,35,11,8.2);d.eq('pi_t',r'\pi_t',10,58,29,17,10)
 d.reuse('world',7,82,13,15);d.reuse('robot',27,80,12,23);d.line('rollout_arrow',[(20,91),(28,91)],'003EA8',.8,True)
 for j,y in enumerate([117,137,157]):d.text('rollout_text'+str(j),['samples','GAE','episode cost'][j],5,y,39,12,8.2)
 d.eq('advantages',r'A_r,\ A_{c_k}',3,169,46,17,9.5);d.eq('observed_cost',r'\bar J_k',12,187,25,18,10,ORANGE)
 d.module='stage2';d.text('clustered','state clusters',54,41,52,13,8.2,color='003EA8');d.graph('rollout_graph',57,64,44,31,'003EA8');d.text('transitions','transition edges',54,101,52,14,8.2,color='003EA8')
 for i,(y,c,tex,label) in enumerate([(126,'003EA8',r'\hat F','flow'),(152,PURPLE,r'A','advantage'),(178,GREEN,r'C_k','costs')]):
  d.reuse(['emp','score','cap'][i]+'_0_0',57,y,5,5,'sampled_cell'+str(i))
  d.matrix('inputmatrix'+str(i),56,y,14,14,c,3);d.eq('input_symbol'+str(i),tex,73,y-2,29,18,10,c);d.text('input_name'+str(i),label,54,y+15,52,11,8.2,color=c)
 d.module='stage3';d.text('soft_label','Soft budgets',117,41,58,12,8.5,True,GREEN);d.eq('budget_conversion',r'b_k=B_k/L',116,59,61,20,10)
 d.eq('soft_constraints',r'\langle C_k,F\rangle\le b_k',114,83,65,22,8.5)
 for j in range(3):
  d.shape('budgetcard'+str(j),121+j*17,113,15,12,'F1F7F1',GREEN,.4,True);d.text('budgetidx'+str(j),str(j+1) if j<2 else 'K',121+j*17,113,15,12,8.2,color=GREEN)
 d.text('hard_label','Hard exclusions',117,140,58,12,8.5,True,RED);d.graph('hard_graph',123,164,44,21,GRAY,hard=True);d.eq('hard_support',r'F_H=0',121,188,52,16,10,RED)
 d.module='stage4';d.text('one_projection','One flow solve',187,40,88,13,9,True,GREEN)
 d.eq('observed_F',r'\hat F',184,64,22,16,10,GRAY);d.graph('observed_graph',211,62,55,25,GRAY,hard=True)
 d.line('reroute_arrow',[(235,91),(235,103)],GREEN,1.2,True)
 d.eq('target_F',r'F^*',184,114,23,18,10,GREEN);d.graph('target_graph',211,110,55,25,GREEN,hard=True,target=True)
 d.text('target_only','target only; not executed',185,137,92,11,8.2,color=GREEN)
 d.text('projection_caption','balance · budgets · KL',185,150,92,12,8.2,color=GREEN)
 d.eq('objective_line1',r'\min_{F\ge0}-\langle A,F\rangle',185,164,92,19,10,GREEN);d.eq('objective_line2',r'+\varepsilon\,\mathrm{KL}(F\Vert\hat F)',184,183,93,19,10,GREEN)
 d.module='stage5';d.text('dual_label','budget duals',289,41,100,11,8.5,True,GREEN);d.eq('dual_filter',r'\lambda_k^*\ \to\ \bar\lambda_k^*',290,55,97,22,10,GREEN);d.text('filter_label','clip at c + EMA',290,77,98,11,8.2,color=GREEN)
 d.text('feedback_label','observed-cost feedback',290,94,98,11,8.2,color=ORANGE)
 d.eq('feedback',r'\beta_k\leftarrow[\beta_k+\alpha(\bar J_k-B_k)]_+',286,109,106,23,8.5,ORANGE)
 d.eq('price_rule',r'\lambda_k=\bar\lambda_k^*+\beta_k',289,135,100,19,10,GREEN)
 d.eq('priced_advantage',r'\widetilde A=\frac{A_r-\sum_k\lambda_k A_{c_k}}{1+\sum_k\lambda_k}',286,157,105,29,10)
 d.text('update_label','PPO/TRPO',290,191,56,11,8.5,True);d.line('update_pi',[(347,197),(356,197)],GRAY,.7,True);d.eq('next_policy',r'\pi_{t+1}',359,189,28,17,10)
 d.module=None
 for i,(x,y) in enumerate([(46,106),(109,106),(178,106)]):d.line('main_arrow'+str(i),[(x,y),(x+5,y)],'003EA8',1.4,True)
 d.line('dual_to_update',[(274,67),(284,67)],GREEN,1.3,True)
 # Observed costs feed beta; advantages bypass graph prices and feed the actor.
 d.line('observed_feedback',[(25,204),(25,214),(282,214),(282,118),(286,118)],ORANGE,.65,True)
 d.shape('observed_label_bg',57,209,106,10,'FFFFFF',None,0);d.text('observed_route','observed episode costs',57,209,105,10,8.2,color=ORANGE)
 d.line('gae_route',[(43,180),(48,180),(48,224),(281,224),(281,174),(286,174)],GRAY,.6,True)
 d.shape('gae_label_bg',69,219,83,11,'FFFFFF',None,0);d.text('gae_route_label','GAE advantages',69,219,83,11,8.2,color=GRAY)
 d.line('next_rollout',[(389,198),(395,198),(395,235),(1,235),(1,62),(9,62)],GRAY,.6,True)
 d.text('loop_label','next rollout',163,225,68,10,8.2,color=GRAY)
 return d.save()

if __name__=='__main__':
 if sys.argv[1]=='faithful':faithful1();faithful2()
 elif sys.argv[1]=='adapted':adapted1();adapted2()
