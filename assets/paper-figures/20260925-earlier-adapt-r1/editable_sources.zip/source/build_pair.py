"""Earlier-design adaptation: all vector primitives, no inherited scientific claims.
Physical coordinates are printer points. Mini-curves are illustrative schematics.
"""
from pathlib import Path
import json,hashlib,math,xml.etree.ElementTree as ET
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,Rectangle,Circle,Polygon,FancyArrowPatch
from matplotlib.lines import Line2D
from matplotlib.textpath import TextToPath
from matplotlib.font_manager import FontProperties
import numpy as np
import fitz
from anonymize import clean_pdf,clean_svg
R=Path(__file__).resolve().parent;O=R/'outputs';O.mkdir(exist_ok=True)
plt.style.use(R/'safeot.mplstyle')
BLUE='#244EA4';GREEN='#247345';TEAL='#087F87';RED='#BD3D3D';PURPLE='#40347C';ORANGE='#CE751D';GRAY='#617078';LIGHT='#D8DEE2';INK='#223139'
SCENES={}
class Canvas:
 def __init__(self,name,h):
  self.name=name;self.w=396;self.h=h;self.fig=plt.figure(figsize=(self.w/72,h/72));self.ax=self.fig.add_axes([0,0,1,1]);self.ax.set_xlim(0,self.w);self.ax.set_ylim(h,0);self.ax.axis('off');self.items=[]
 def text(self,x,y,text,size=7.5,color=INK,bold=False,ha='left',math=False):
  self.ax.text(x,y,text,fontfamily=('STIXGeneral' if any(a in text for a in '⟨⟩') else 'Liberation Serif'),fontsize=size,color=color,fontweight='bold' if bold else 'normal',ha=ha,va='center',linespacing=1.17)
  self.items.append(dict(kind='text',x=x,y=y,text=text,size=size,color=color,bold=bold,ha=ha,math=math))
 def rich(self,x,y,runs,color=INK,ha='center'):
  # Explicit7pt scripts avoid unreadable nested automatic math scripts.
  tp=TextToPath();widths=[tp.get_text_width_height_descent(t,FontProperties(family=('STIXGeneral' if any(a in t for a in '⟨⟩') else 'Liberation Serif'),size=z),False)[0] for t,z,dy in runs]
  xx=x-(sum(widths)/2 if ha=='center' else sum(widths) if ha=='right' else 0)
  for (t,z,dy),w in zip(runs,widths):self.text(xx,y+dy,t,z,color);xx+=w
 def box(self,x,y,w,h,color=GRAY,fill='white',r=3,lw=.65,dash=False):
  self.ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle=f'round,pad=0,rounding_size={r}',facecolor=fill,edgecolor=color,linewidth=lw,linestyle='--' if dash else '-'));self.items.append(dict(kind='box',x=x,y=y,w=w,h=h,color=color,fill=fill,r=r,lw=lw,dash=dash))
 def line(self,pts,color=GRAY,lw=.7,dash=False):
  self.ax.plot([p[0] for p in pts],[p[1] for p in pts],color=color,lw=lw,ls='--' if dash else '-',solid_capstyle='round');self.items.append(dict(kind='line',pts=pts,color=color,lw=lw,dash=dash))
 def arrow(self,a,b,color=GRAY,lw=.8,style='-|>',rad=0):
  self.ax.add_patch(FancyArrowPatch(a,b,arrowstyle=style,mutation_scale=6.5,lw=lw,color=color,connectionstyle=f'arc3,rad={rad}',shrinkA=0,shrinkB=0));self.items.append(dict(kind='arrow',a=a,b=b,color=color,lw=lw,style=style,rad=rad))
 def circle(self,x,y,r=2.2,fill='white',color=GRAY,lw=.6):
  self.ax.add_patch(Circle((x,y),r,facecolor=fill,edgecolor=color,lw=lw));self.items.append(dict(kind='circle',x=x,y=y,r=r,fill=fill,color=color,lw=lw))
 def polygon(self,pts,color=GRAY,fill='white',lw=.6):
  self.ax.add_patch(Polygon(pts,closed=True,facecolor=fill,edgecolor=color,lw=lw));self.items.append(dict(kind='polygon',pts=pts,color=color,fill=fill,lw=lw))
 def export(self):
  raw=O/(self.name+'.raw.pdf');self.fig.savefig(raw,metadata={'Creator':None,'Producer':None,'CreationDate':None});clean_pdf(raw,O/(self.name+'.pdf'));raw.unlink()
  raw=O/(self.name+'.raw.svg');self.fig.savefig(raw,metadata={'Creator':None,'Date':None});clean_svg(raw,O/(self.name+'_editable.svg'));raw.unlink()
  with plt.rc_context({'svg.fonttype':'path'}):
   self.fig.savefig(raw,metadata={'Creator':None,'Date':None});clean_svg(raw,O/(self.name+'.svg'));raw.unlink()
  with fitz.open(O/(self.name+'.pdf')) as d:
   p=d[0];ss=[s for b in p.get_text('dict')['blocks'] if 'lines' in b for l in b['lines'] for s in l['spans'] if s['text'].strip()];minimum=min(s['size'] for s in ss)
   report={'size_in':[p.rect.width/72,p.rect.height/72],'minimum_font_pt':minimum,'native_vector':not p.get_images(),'embedded_fonts':all(d.extract_font(f[0])[3] for f in p.get_fonts()),'outside':[s['text'] for s in ss if not p.rect.contains(fitz.Rect(s['bbox']))],'text':p.get_text(),'mini_plots':'illustrative only; no experimental data'}
   (O/(self.name+'.report.json')).write_text(json.dumps(report,indent=2)+'\n')
   for suffix,cs in [('300dpi',fitz.csRGB),('grayscale',fitz.csGRAY)]:
    pm=p.get_pixmap(matrix=fitz.Matrix(300/72,300/72),colorspace=cs,alpha=False);pm.set_dpi(300,300);pm.save(O/(self.name+'_'+suffix+'.png'))
   assert minimum>=7,(self.name,minimum);assert not report['outside'],report['outside']
  SCENES[self.name]={'width':self.w,'height':self.h,'items':self.items};plt.close(self.fig);print(self.name,minimum)

def drop(c,x,y,color):
 c.polygon([(x,y-6),(x-3,y),(x-3,y+3),(x,y+5),(x+3,y+3),(x+3,y)],color=color,fill=color,lw=.5)
def force(c,x,y,color):
 c.line([(x-5,y+5),(x+5,y+5)],color,1);c.line([(x-3,y+4),(x-1,y-1),(x+4,y-4)],color,1.1);c.circle(x-1,y-1,1.2,fill='white',color=color);c.arrow((x+3,y-4),(x+3,y+1),color,lw=.7)
def impact(c,x,y,color):
 c.line([(x-5,y+4),(x-5,y-3),(x+5,y-3),(x+5,y+4)],color,.9);c.arrow((x,y-6),(x,y+2),color);c.line([(x-2,y+4),(x,y+2),(x+2,y+4)],color,.8)
def graph(c,x,y,w,h,color=TEAL,observed=False,hard=True):
 points=[(x,y+h*.5),(x+w*.3,y),(x+w*.67,y),(x+w,y+h*.5),(x+w*.67,y+h),(x+w*.3,y+h)]
 edges=[(0,1),(1,2),(2,3),(0,5),(5,4),(4,3),(1,4)]
 for j,(a,b) in enumerate(edges):
  if hard and j==6:continue
  col=LIGHT if observed else color;lw=(1.8 if j<3 else .6) if observed else (.7 if j<3 else 1.65)
  c.line([points[a],points[b]],col,lw)
 if hard:
  a,b=points[1],points[4];c.line([a,b],RED,.7,True);cx=(a[0]+b[0])/2;cy=(a[1]+b[1])/2;c.line([(cx-2,cy-2),(cx+2,cy+2)],RED,.9);c.line([(cx-2,cy+2),(cx+2,cy-2)],RED,.9)
 for j,(xx,yy) in enumerate(points):c.circle(xx,yy,2.0,fill=color if j==3 else 'white',color=color)

def figure1():
 c=Canvas('Figure1',226)
 # Original three-panel hierarchy; center is the sole proposed method.
 for x,w,col,fill in [(3,96,BLUE,'#F9FAFE'),(104,188,GREEN,'#F8FBF8'),(297,96,RED,'#FFF9F8')]:c.box(x,3,w,164,col,fill,lw=.85,r=4)
 c.text(51,14,'Soft penalty',9,BLUE,True,'center');c.text(51,28,'costs in the objective',7.2,GRAY,ha='center')
 c.rich(51,44,[('J',11,0),('r',7,3),(' − Σ',11,0),('k',7,3),(' λ',11,0),('k',7,3),(' J',11,0),('c',7,3),('k',7,5)],BLUE)
 # Leakage schematic.
 x,y,w,h=20,64,66,63;c.arrow((x,y+h),(x,y),INK,lw=.6);c.arrow((x,y+h),(x+w,y+h),INK,lw=.6)
 c.text(x-7,y-5,'Cost',7.2,ha='left');c.text(x+w,y+h+10,'Training',7.2,ha='right')
 by=y+32;c.line([(x,by),(x+w,by)],RED,.65,True);c.text(x-3,by-6,'B',7.2,RED,ha='right')
 xs=np.linspace(0,1,55);ys=57-50*(1-np.exp(-3*xs));c.line([(x+3+t*(w-8),y+v) for t,v in zip(xs,ys)],BLUE,1.3)
 c.arrow((x+48,by),(x+48,y+13),RED,.7,style='<->');c.text(51,147,'Budget leakage',7.5,BLUE,True,'center');c.text(51,158,'schematic',7.2,GRAY,ha='center')
 c.text(345,14,'Explicit budgets',9,RED,True,'center');c.text(345,28,'coupled constraints',7.2,GRAY,ha='center')
 c.rich(345,44,[('J',11,0),('c',7,3),('k',7,5),(' ≤ B',11,0),('k',7,3)],RED)
 x,y,w,h=315,64,66,63;c.arrow((x,y+h),(x,y),INK,lw=.6);c.arrow((x,y+h),(x+w,y+h),INK,lw=.6)
 c.text(x-7,y-5,'Cost',7.2);c.text(x+w,y+h+10,'Training',7.2,ha='right')
 for off,label in [(16,'B₁'),(31,'B₂'),(46,'Bₖ')]:c.line([(x,y+off),(x+w,y+off)],RED,.65,True);c.rich(x-3,y+off,[('B',8,0),(label[-1] if label[-1]!='ₖ' else 'k',7,2)],RED,ha='right')
 ts=np.linspace(0,1,120);c.line([(x+3+t*(w-6),y+31-20*np.sin(6*np.pi*t)) for t in ts],RED,1.15)
 c.text(345,147,'Budget oscillation',7.5,RED,True,'center');c.text(345,158,'schematic',7.2,GRAY,ha='center')
 # Middle retains input pictograms -> one solve -> policy structure.
 c.text(198,14,'SafeOT-Dual',10,GREEN,True,'center')
 c.text(198,28,'K constraints · one joint solve',8,GREEN,True,'center')
 for x,icon,label in [(125,drop,'Spill'),(165,force,'Force'),(207,impact,'Impact')]:
  icon(c,x,43,GRAY);c.text(x,57,label,7.2,GRAY,ha='center')
 c.text(249,44,'···',11,GRAY,ha='center');c.text(254,57,'K channels',7.2,GRAY,ha='center')
 c.arrow((198,64),(198,72),GREEN)
 c.box(117,74,162,39,GREEN,'white',r=3,lw=.7);c.text(126,84,'ONE joint',8.1,GREEN,True);c.text(126,96,'flow solve',8.1,GREEN,True)
 graph(c,204,83,63,21,GREEN,hard=True)
 c.arrow((198,114),(198,120),GREEN)
 c.rich(198,129,[('λ',11,0),('k',7,3),(' = λ̄',11,0),('*',7,-4),('k',7,3),(' + β',11,0),('k',7,3)],TEAL)
 c.text(153,142,'joint prices',7.2,TEAL,ha='center');c.text(240,142,'cost feedback',7.2,ORANGE,ha='center')
 c.arrow((198,145),(198,150),GREEN)
 c.box(145,152,106,12,PURPLE,'#F4F2FA',r=2,lw=.6);c.text(198,158,'Actor update',8,PURPLE,True,'center')
 # Exact settings and conditional limits; no external algorithm recovery marks.
 c.text(198,178,'One price rule: exact settings and conditional limits',7.5,INK,True,'center')
 for a,b,col in [(24,111,BLUE),(111,207,TEAL),(207,288,GREEN),(288,374,RED)]:c.line([(a,193),(b,193)],col,2)
 for x,col in [(39,BLUE),(130,TEAL),(222,GREEN),(340,RED)]:c.circle(x,193,2.3,fill=col,color='white',lw=.6)
 c.text(39,186,'Fixed penalty',7.5,BLUE,True,'center');c.text(39,204,'c = 0; fixed β',7.2,GRAY,ha='center')
 c.text(130,186,'Lagrangian',7.5,TEAL,True,'center');c.text(130,204,'c = 0; adaptive β',7.2,GRAY,ha='center')
 c.text(222,186,'SafeOT-Dual',7.5,GREEN,True,'center');c.text(222,204,'finite ε',7.2,GRAY,ha='center')
 c.text(340,186,'LP / active-set',7.5,RED,True,'center');c.text(340,204,'ε → 0 / saturated clip',7.2,GRAY,ha='center')
 c.text(340,217,'under assumptions',7.2,GRAY,ha='center')
 c.export()

def figure2():
 c=Canvas('Figure2',217)
 specs=[(3,64,BLUE,'1  Rollout'),(73,73,BLUE,'2  Flow inputs'),(152,72,GREEN,'3  Constraints'),(230,78,TEAL,'4  Joint solve'),(314,79,PURPLE,'5  Actor update')]
 for x,w,col,title in specs:
  c.box(x,3,w,160,col,'white',r=3,lw=.8);c.box(x+1,4,w-2,21,col,{'1  Rollout':'#F2F5FC','2  Flow inputs':'#F2F5FC','3  Constraints':'#F4F9F2','4  Joint solve':'#F0F9F9','5  Actor update':'#F5F3FA'}[title],r=2,lw=0)
  c.text(x+w/2,14,title,8.5,col,True,'center')
 for x1,x2 in [(67,73),(146,152),(224,230)]:c.arrow((x1,89),(x2,89),INK,lw=.8)
 # (1) Rollout chain, reward/cost advantages and actual costs.
 c.text(35,34,'Current policy',7.5,BLUE,ha='center');c.rich(35,43,[('π',9,0),('t',7,3)],BLUE)
 for j,xx in enumerate([15,35,55]):
  c.circle(xx,53,3,fill='#E4ECFA',color=BLUE);c.rich(xx,67,[('s',8,0),(['0','1','t'][j],7,2)])
  if j<2:c.arrow((xx+3,53),(xx+17,53),BLUE)
 c.box(10,80,50,33,BLUE,'#F8FAFE',r=2);c.text(35,89,'GAE',8,BLUE,True,'center');c.rich(35,102,[('Â',9,0),('r',7,3),(', Â',9,0),('c',7,3),('k',7,5)],BLUE)
 c.text(35,128,'Episode costs',7.5,ha='center');c.rich(35,145,[('J̄',10,0),('k',7,3)],ORANGE)
 # (2) Empirical graph and explicit inputs.
 c.text(109.5,35,'k-means cells',7.5,BLUE,ha='center');graph(c,86,49,47,23,BLUE,observed=True,hard=False)
 c.text(109.5,85,'Empirical flow F̂',7.5,BLUE,ha='center')
 c.box(80,99,59,51,BLUE,'#F8FAFE',r=2)
 c.text(109.5,110,'Advantage A',7.5,ha='center');c.rich(109.5,124,[('Edge costs C',7.5,0),('k',7,2)]);c.text(109.5,138,'Initial mass μ₀',7.5,ha='center')
 # (3) Soft channels share one solve; hard events excluded without a price.
 c.text(188,35,'Soft budgets',8,GREEN,True,'center');c.rich(188,50,[('b',9,0),('k',7,2),(' = B',9,0),('k',7,2),(' / L',9,0)],GREEN);c.rich(188,66,[('⟨C',9,0),('k',7,2),(', F⟩ ≤ b',9,0),('k',7,2)],GREEN)
 c.line([(159,80),(217,80)],LIGHT,.6)
 c.text(188,92,'Hard edges',8,RED,True,'center');c.line([(165,110),(211,110)],RED,.8,True);c.circle(165,110,2,fill='white',color=RED);c.circle(211,110,2,fill='white',color=RED);c.line([(185,106),(191,114)],RED,1);c.line([(185,114),(191,106)],RED,1)
 c.rich(188,127,[('F',9,0),('H',7,2),(' = 0',9,0)],RED);c.text(188,144,'Excluded; no price',7.2,GRAY,ha='center')
 # (4) One constrained entropic projection and its duals.
 c.text(269,36,'Entropic projection',7.5,TEAL,True,'center')
 c.text(269,51,'Reward − ε KL',8,TEAL,ha='center');c.text(269,66,'flow balance',7.5,TEAL,ha='center');graph(c,241,82,55,27,TEAL,hard=True)
 c.text(269,123,'Target F*',9,TEAL,ha='center');c.text(269,145,'Budget prices λ*',8,TEAL,ha='center');c.line([(305,145),(310,145),(310,35)],TEAL,.8);c.arrow((310,35),(319,35),TEAL,.8)
 # (5) Clipped/filtered dual prices plus realized-cost feedback.
 c.text(353.5,35,'clip c + EMA',8,TEAL,ha='center');c.arrow((353.5,42),(353.5,49),TEAL)
 c.rich(353.5,60,[('λ',9,0),('k',7,2),(' = λ̄',9,0),('*',7,-3),('k',7,2),(' + β',9,0),('k',7,2)],PURPLE)
 c.arrow((353.5,69),(353.5,77),PURPLE);c.box(323,80,61,25,PURPLE,'#F7F5FB',r=2);c.text(353.5,88,'Priced advantage',7.3,PURPLE,True,'center');c.text(353.5,98,'Ã',10,PURPLE,ha='center')
 c.arrow((353.5,106),(353.5,114),PURPLE);c.box(323,117,61,21,PURPLE,'#F7F5FB',r=2);c.text(353.5,127,'PPO / TRPO',8,PURPLE,True,'center');c.rich(353.5,151,[('π',10,0),('t+1',7,3)],PURPLE)
 # Shared paths in separate routing lanes.
 c.line([(35,151),(35,176),(162,176)],ORANGE,.8);c.box(162,169,126,15,ORANGE,'#FFF8EE',r=2,lw=.65);c.rich(225,176,[('β',8,0),('k',7,2),(' ← [β',8,0),('k',7,2),(' + η(J̄',8,0),('k',7,2),(' − B',8,0),('k',7,2),(')]',8,0),('+',7,2)],ORANGE);c.line([(288,176),(388,176),(388,60)],ORANGE,.8);c.arrow((388,60),(381,60),ORANGE,.8)
 c.line([(353.5,157),(353.5,199),(.9,199),(.9,39)],GRAY,.65);c.arrow((.9,39),(9,39),GRAY,.65);c.text(80,194,'next rollout',7.2,GRAY,ha='center');c.text(225,190,'observed-cost feedback',7.2,ORANGE,ha='center')
 c.text(200,211,'F* is a target, not executed; gap corrected by feedback',7.5,GRAY,ha='center')
 c.export()

if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--figure',choices=['1','2','all'],default='all');a=p.parse_args()
 if a.figure in ['1','all']:figure1()
 if a.figure in ['2','all']:figure2()
 for n,scene in SCENES.items():(O/(n+'.scene.json')).write_text(json.dumps(scene,ensure_ascii=False,indent=2)+'\n')
