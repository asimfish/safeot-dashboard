from pathlib import Path
import importlib.util,sys,json,shutil,hashlib,re,zipfile
import fitz
from PIL import Image,ImageChops
R=Path(__file__).resolve().parent;O=R/'outputs';O.mkdir(exist_ok=True);F=R/'delivery';F.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('anon',R/'method/source/anonymize.py');anon=importlib.util.module_from_spec(spec);spec.loader.exec_module(anon)
files={'Figure1':R/'method/outputs/Figure1.pdf','Figure2':R/'method/outputs/Figure2.pdf','Figure3':R/'data3/outputs/Figure3.pdf','Figure4':R/'data4/figure/Figure4a_stacked_direction.pdf','Figure5':R/'data5/outputs/Figure5_local.pdf'}
reports=[]
for name,source in files.items():
 anon.clean_pdf(source,O/(name+'.pdf'))
 with fitz.open(O/(name+'.pdf')) as d:
  p=d[0];spans=[s for b in p.get_text('dict')['blocks'] if 'lines' in b for l in b['lines'] for s in l['spans'] if s['text'].strip()]
  report={'figure':name,'size_in':[p.rect.width/72,p.rect.height/72],'minimum_font_pt':min(s['size'] for s in spans),'raster_images':len(p.get_images()),'outside':[s['text'] for s in spans if not p.rect.contains(fitz.Rect(s['bbox']))],'old_name_hits':re.findall(r'SafeOT[-‐‑– ]*Dual',p.get_text(),re.I),'embedded_fonts':all(d.extract_font(x[0])[3] for x in p.get_fonts()),'metadata':d.metadata,'text':p.get_text(),'sha256':hashlib.sha256((O/(name+'.pdf')).read_bytes()).hexdigest()}
  report['pass']=report['minimum_font_pt']>=7 and not report['raster_images'] and not report['outside'] and not report['old_name_hits'] and report['embedded_fonts']
  assert report['pass'],report
  assert not any(v for k,v in d.metadata.items() if k not in ['format','encryption'])
  (O/(name+'.svg')).write_text(p.get_svg_image(text_as_path=True))
  for suffix,cs in [('300dpi',fitz.csRGB),('grayscale',fitz.csGRAY)]:
   pm=p.get_pixmap(matrix=fitz.Matrix(300/72,300/72),colorspace=cs,alpha=False);pm.set_dpi(300,300);pm.save(O/(name+'_'+suffix+'.png'))
  reports.append(report)
for name in ['Figure1','Figure2']:shutil.copy2(R/'method/outputs'/(name+'.tex'),O/(name+'.tex'))
captions=json.loads((R/'method/outputs/captions.json').read_text())
captions['Figure3']=r'Training excess and final return. Circles: SafePO; diamonds: Bullet. Right favors SafeOT: (a) reversed-log task-median excess ratio; (b) normalized return difference. Bars: 95\% task/seed bootstrap intervals. SafePO switch/TRPO-PID use five matched seeds/task. Forests differ from the 534-run SafePO trace snapshot and headline population; Bullet uses 270 runs. $\dagger$: baseline mean cost exceeds budget on 4/6 TRPO-Lag or 5/6 PPO-Lag tasks. Dashes: not run. (c) All-task median traces and interquartile bands; budget equals one. Appendices specify remaining counts and estimators.'
captions['Figure4']=r'Sampled flow realization for SafeOT. Left: means of four signed components divided by $b_t$; diamonds give their sum. Right: median alignment/projection. Parentheses show run counts (19 total, 88 pairs/run). Sampled frequencies differ from policy occupancies; signed drift differs from absolute mismatch.'
captions['Figure5']=r'Local-budget comparisons of SafeOT. Excess ratio: baseline $V$ divided by $V$ for the indicated SafeOT variant; above one favors SafeOT. Panels (b,c) use SafeOT (unclipped). Large markers: medians; faint dots: paired cells. (a) Forty cells per $K$; (b) ten cells per $K$; (c) five seeds per robot. Growth with $K$ is unsupported for the full rule family.'
# Keep source-generated F3 captions synchronized with the admitted caption.
(R/'data3/outputs/Figure3_caption.txt').write_text(captions['Figure3']+'\n')
for name,text in captions.items():
 assert not re.search(r'SafeOT[-‐‑– ]*Dual',text)
 (O/(name+'_caption.tex')).write_text(text+'\n')
(O/'captions.json').write_text(json.dumps(captions,indent=2)+'\n');(O/'font_report.json').write_text(json.dumps(reports,indent=2)+'\n')
# Canonical public names map stable historical raw IDs to display names.
shutil.copy2(R/'name_map.json',O/'name_map.json')
for p in O.iterdir():
 if p.is_file():shutil.copy2(p,F/p.name)
print(json.dumps([{k:d[k] for k in ['figure','minimum_font_pt','old_name_hits','pass']} for d in reports]))
