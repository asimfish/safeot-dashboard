from pathlib import Path
import subprocess,sys
r=Path(__file__).resolve().parent
for script in ['method/source/build_figures.py','data3/build_figure3.py','data4/build_figure4.py','data5/build_figure5.py','export_current.py','make_accessibility.py']:
    subprocess.run([sys.executable,str(r/script)],check=True)
print('Current SafeOT figures rendered in outputs/.')
