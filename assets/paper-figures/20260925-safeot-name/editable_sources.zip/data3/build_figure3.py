"""Render supplied summaries verbatim; never recompute effects, CI, wins or IQR.

A full Figure 3 export requires hash-bound source-cohort evidence. Without it,
the complete-layout preview is restricted to qa/ and explicitly marked draft.
The all-task curve panel itself has an independently documented source.
"""
from pathlib import Path
import argparse
import csv
import hashlib
import importlib.util
import json
import math
import shutil

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import FixedLocator, FixedFormatter
import numpy as np
import fitz

RUN = Path(__file__).resolve().parent
BASE = RUN
STYLE = RUN
DATA = RUN
plt.style.use(STYLE/'safeot.mplstyle')
PALETTE = json.loads((STYLE/'palette.json').read_text())['methods']
METHODS = ['SafeOT','TRPO-Lag','CPO','PID-Lag']
COMPS = ['TRPO-Lag','PPO-Lag','CPO','PCPO','FOCOPS','CUP','PPO-PID (CPPO-PID)','TRPO-PID','switch']
DISPLAY = {'PPO-PID (CPPO-PID)': 'CPPO-PID'}
SUITES = ['SafePO','Bullet']
EXPECTED_TASKS = {'SafePO':10,'Bullet':6}
canon = {'SafePO-10':'SafePO','Bullet-6':'Bullet','PID-Lag':'PPO-PID (CPPO-PID)','CPPO-PID':'PPO-PID (CPPO-PID)'}
spec = importlib.util.spec_from_file_location('anonymous', RUN/'anonymize.py')
anon = importlib.util.module_from_spec(spec)
spec.loader.exec_module(anon)

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def rows(path):
    with Path(path).open() as f: return list(csv.DictReader(f))

def load(forest_path, curves_path, wins_path):
    forest, wins, curves = {}, {}, {}
    for r in rows(forest_path):
        if r.get('status')=='not_in_admitted_comparison':
            assert all(not r[k] for k in ['point','lo','hi'])
            continue
        suite = canon.get(r['suite'], r['suite'])
        comp = canon.get(r['comparator'], r['comparator'])
        if suite not in SUITES or comp not in COMPS or r['metric'] not in ['V_ratio','R_diff_norm']: continue
        key = suite,comp,r['metric']
        assert key not in forest, ('duplicate forest',key)
        for k in ['point','lo','hi']: r[k]=float(r[k])
        assert all(math.isfinite(r[k]) for k in ['point','lo','hi'])
        assert r['lo']<=r['point']<=r['hi']
        assert int(r['n_tasks'])==EXPECTED_TASKS[suite]
        if r['metric']=='V_ratio': assert r['lo']>0
        forest[key]=r
    assert forest, 'No supplied forest summaries'
    for r in rows(wins_path):
        if not r.get('wins'):
            assert r.get('status')=='not_in_admitted_comparison'
            continue
        key=(canon.get(r['suite'],r['suite']),canon.get(r['comparator'],r['comparator']))
        assert key not in wins, ('duplicate count',key)
        r['wins'],r['n_tasks']=int(r['wins']),int(r['n_tasks'])
        assert 0<=r['wins']<=r['n_tasks']==EXPECTED_TASKS[key[0]]
        wins[key]=r
    for r in rows(curves_path):
        suite,method=r['suite'],r['method']
        assert suite in SUITES and method in METHODS
        assert int(r['n_tasks'])==EXPECTED_TASKS[suite]
        for k in ['progress_pct']+[m+'_'+q for m in ['cost_over_budget','normalized_return'] for q in ['q25','median','q75']]:
            r[k]=float(r[k]); assert math.isfinite(r[k])
        for m in ['cost_over_budget','normalized_return']:
            assert r[m+'_q25']<=r[m+'_median']<=r[m+'_q75']
        curves.setdefault((suite,method),[]).append(r)
    for (suite,method),rs in curves.items():
        rs.sort(key=lambda r:r['progress_pct'])
        grid=[r['progress_pct'] for r in rs]
        assert len(grid)==(100 if suite=='SafePO' else 50)
        assert all(a<b for a,b in zip(grid,grid[1:])) and grid[-1]==100
    assert len(curves)==8
    return forest,wins,curves

def axes_bp(fig,x,y,w,h):
    fw,fh=fig.get_size_inches()*72
    return fig.add_axes([x/fw,1-(y+h)/fh,w/fw,h/fh])

def text_bp(fig,x,y,s,**kw):
    fw,fh=fig.get_size_inches()*72
    return fig.text(x/fw,1-y/fh,s,va='center',**kw)

def curve_panel(fig,curves,top=195,first=50,last=241,width=147,height=43,gap=16):
    artists=[]
    for col,suite in enumerate(SUITES):
        x=first if col==0 else last
        a=axes_bp(fig,x,top,width,height)
        b=axes_bp(fig,x,top+height+gap,width,height)
        text_bp(fig,x+width/2,top-9,f'{suite}: {EXPECTED_TASKS[suite]} tasks, B = {25 if suite=="SafePO" else 10}',ha='center',fontweight='bold',fontsize=8)
        for method in METHODS:
            rr=curves[(suite,method)]
            xx=np.array([r['progress_pct'] for r in rr])
            st=PALETTE[method]
            for ax,metric in [(a,'cost_over_budget'),(b,'normalized_return')]:
                yy=np.array([r[metric+'_median'] for r in rr])
                lo=np.array([r[metric+'_q25'] for r in rr])
                hi=np.array([r[metric+'_q75'] for r in rr])
                band=ax.fill_between(xx,lo,hi,color=st['color'],alpha=(.09 if method in ['SafeOT','TRPO-Lag'] else 0),linewidth=0)
                vertices=band.get_paths()[0].vertices
                for x0,l0,h0 in zip(xx,lo,hi):
                    plotted_y=vertices[np.isclose(vertices[:,0],x0),1]
                    assert np.isclose(plotted_y,l0).any() and np.isclose(plotted_y,h0).any()
                line,=ax.plot(xx,yy,color=st['color'],linestyle=st['linestyle'],marker=st['marker'],markevery=16 if suite=='SafePO' else 8,markersize=2.4,label=('CPPO-PID' if method == 'PID-Lag' else method))
                assert np.array_equal(line.get_xdata(),xx) and np.array_equal(line.get_ydata(),yy)
                artists.append({'suite':suite,'method':method,'metric':metric,'points':len(xx),'line_matches_source':True,'band_displayed':method in ['SafeOT','TRPO-Lag'],'band_q25':lo.tolist(),'band_q75':hi.tolist()})
        a.axhline(1,color='#59636A',linestyle='--',linewidth=.65,zorder=0)
        if suite=='SafePO':
            a.set_ylim(0,4.3);a.set_yticks([0,1,2,4])
        else:
            a.set_yscale('symlog',linthresh=1,linscale=1)
            a.set_ylim(0,40);a.set_yticks([0,1,10,40],['0','1','10','40'])
            a.minorticks_off()
            a.text(1.002,.5,'symlog',transform=a.transAxes,rotation=90,ha='left',va='center',fontsize=7.2,color='#59636A',clip_on=False)
        b.set_ylim(-.30,1.05);b.set_yticks([0,.5,1],['0','.5','1'])
        for ax in [a,b]:
            ax.set_xlim(0,100);ax.set_xticks([0,50,100]);ax.grid(axis='y')
            ax.tick_params(axis='both',pad=1.5)
        a.tick_params(axis='x',labelbottom=False)
        b.set_xlabel('Training progress (%)',labelpad=1)
        if col==0:
            a.set_ylabel('Cost / B',labelpad=3)
            b.set_ylabel('Norm. return',labelpad=3)
    return artists

def export(fig,path,details):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    raw=path.with_suffix('.raw.pdf')
    fig.savefig(raw,format='pdf',metadata={'Creator':None,'Producer':None,'CreationDate':None})
    anon.clean_pdf(raw,path.with_suffix('.pdf'));raw.unlink()
    svg_raw=path.with_suffix('.raw.svg')
    fig.savefig(svg_raw,format='svg',metadata={'Creator':None,'Date':None})
    anon.clean_svg(svg_raw,path.with_suffix('.svg'));svg_raw.unlink()
    with fitz.open(path.with_suffix('.pdf')) as d:
        p=d[0]
        pm=p.get_pixmap(matrix=fitz.Matrix(300/72,300/72),alpha=False);pm.set_dpi(300,300);pm.save(path.with_name(path.name+'_300dpi.png'))
        pm=p.get_pixmap(matrix=fitz.Matrix(300/72,300/72),colorspace=fitz.csGRAY,alpha=False);pm.set_dpi(300,300);pm.save(path.with_name(path.name+'_grayscale.png'))
        spans=[s for b in p.get_text('dict')['blocks'] if 'lines' in b for l in b['lines'] for s in l['spans'] if s['text'].strip()]
        details.update({'minimum_font_pt':min(s['size'] for s in spans),'size_in':[p.rect.width/72,p.rect.height/72],'raster_images':len(p.get_images()),'fonts':[f[3] for f in p.get_fonts()], 'all_fonts_embedded':all(d.extract_font(f[0])[3] for f in p.get_fonts()),'text_outside_page':[s['text'] for s in spans if not p.rect.contains(fitz.Rect(s['bbox']))]})
        assert details['minimum_font_pt']>=7
        assert not details['raster_images'] and details['all_fonts_embedded']
        assert not details['text_outside_page'], details['text_outside_page']
    path.with_suffix('.report.json').write_text(json.dumps(details,indent=2))
    plt.close(fig)
    print(path,details['minimum_font_pt'])

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--forest',type=Path,default=RUN/'forest.csv')
    ap.add_argument('--curves',type=Path,default=DATA/'figure3c_alltask_aggregate.csv')
    ap.add_argument('--wins',type=Path,default=RUN/'wins.csv')
    ap.add_argument('--alignment',type=Path,default=RUN/'alignment.json',help='Hash-bound cohort verification: producer declaration or archived-source audit')
    a=ap.parse_args()
    forest,wins,curves=load(a.forest,a.curves,a.wins)
    hashes={k:sha(getattr(a,k)) for k in ['forest','curves','wins']}
    missing=[(s,c) for s in SUITES for c in COMPS if (s,c,'V_ratio') in forest and (s,c) not in wins]
    aligned=False
    if a.alignment:
        alignment=json.loads(a.alignment.read_text())
        aligned=alignment.get('same_forest_and_counts_cohort') is True and all(alignment.get(k+'_sha256')==hashes[k] for k in ['forest','wins'])
        allowed={tuple(x) for x in alignment.get('allowed_missing_counts',[])}
        assert aligned and set(missing)<=allowed, 'Source alignment or count coverage incomplete'
    fig=plt.figure(figsize=(5.5,4.1))
    av=axes_bp(fig,53,53,98,95)
    ar=axes_bp(fig,280,53,108,95)
    text_bp(fig,2,9,'(a) Learning-time violation',fontweight='bold',fontsize=8.8)
    text_bp(fig,255,9,'(b) Final return',fontweight='bold',fontsize=8.8)
    text_bp(fig,53,22,'better for SafeOT →',fontsize=7.2)
    text_bp(fig,280,22,'better for SafeOT →',fontsize=7.2)
    text_bp(fig,197,29,'Tasks where SafeOT',ha='center',fontsize=7.2)
    text_bp(fig,197,38,'has lower V',ha='center',fontsize=7.2)
    text_bp(fig,172,47,'of 10',ha='center',fontsize=7.2)
    fig.add_artist(Line2D([186/396],[1-47/295.2],marker='o',color='#59636A',markersize=2.8,linestyle='none'))
    text_bp(fig,207,47,'of 6',ha='center',fontsize=7.2)
    fig.add_artist(Line2D([219/396],[1-47/295.2],marker='D',color='#59636A',markersize=2.8,linestyle='none'))
    fig.legend(handles=[Line2D([],[],color='#59636A',marker=m,linestyle='none',markersize=3,label=s) for s,m in [('SafePO','o'),('Bullet','D')]],loc='center',bbox_to_anchor=(.24,1-36/295.2),ncol=2,columnspacing=.7,handletextpad=.3)
    ypos=[j if j<8 else j+.9 for j in range(len(COMPS))]
    ylim=(-.5,9.3)
    ybp=lambda j:53+(j-ylim[0])/(ylim[1]-ylim[0])*95
    # Shared guides link comparator names, suite counts and the two estimands.
    for j,y in enumerate(ypos):
        fig.add_artist(Line2D([2/396,390/396],[1-ybp(y)/295.2]*2,color='#E8EAEB',linewidth=.45,zorder=-2))
    forest_checks=[]
    for ax,metric,ref in [(av,'V_ratio',1),(ar,'R_diff_norm',0)]:
        for j,comp in enumerate(COMPS):
            for suite,delta,marker in [('SafePO',-.16,'o'),('Bullet',.16,'D')]:
                if (suite,comp,metric) not in forest: continue
                r=forest[suite,comp,metric];color=PALETTE[comp]['color']
                eb=ax.errorbar(r['point'],ypos[j]+delta,xerr=[[r['point']-r['lo']],[r['hi']-r['point']]],fmt=marker,color=color,markeredgecolor='#333333',markersize=3.2,elinewidth=.7,capsize=1.4,markeredgewidth=.35)
                segment=eb.lines[2][0].get_segments()[0]
                assert eb.lines[0].get_xdata()[0]==r['point']
                assert np.allclose(segment[:,0],[r['lo'],r['hi']],rtol=0,atol=1e-14)
                if suite=='Bullet' and metric=='R_diff_norm' and comp in ['TRPO-Lag','PPO-Lag']:
                    ax.annotate('†',(r['point'],ypos[j]+delta),xytext=(4,3),textcoords='offset points',fontsize=7.2,color='#23343B')
                forest_checks.append({'suite':suite,'comparator':comp,'metric':metric,'point':r['point'],'lo':r['lo'],'hi':r['hi'],'artist_matches_source':True})
        ax.axvline(ref,color='#59636A',linestyle='--',linewidth=.7)
        ax.set_ylim(ylim[1],ylim[0]);ax.set_yticks(ypos,[DISPLAY.get(c,c) for c in COMPS])
        ax.tick_params(axis='y',length=0,pad=3);ax.tick_params(axis='x',pad=2)
        ax.grid(axis='x');ax.set_facecolor('none')
    av.set_xscale('log');av.set_xlim(8,.12);av.set_xticks([8,4,2,1,.5,.25],['8','4','2','1','.5','.25']);av.minorticks_off()
    ar.set_xlim(-.72,.72);ar.set_xticks([-.5,0,.5],['−.5','0','.5'])
    for j,comp in enumerate(COMPS):
        y=ybp(ypos[j])
        for suite,x in [('SafePO',175),('Bullet',211)]:
            if (suite,comp) in wins:
                r=wins[suite,comp]
                text_bp(fig,x,y,f'{r["wins"]}',ha='center',fontsize=7.2)
            else:
                text_bp(fig,x,y,'n/r' if suite=='SafePO' and comp=='warm' else '—',ha='center',fontsize=7.2,color='#777777')
        if not any((su,comp,'R_diff_norm') in forest for su in SUITES):
            ar.text(0,ypos[j],'n/r',ha='center',va='center',fontsize=7.2,color='#777777')
    text_bp(fig,5,ybp(7.85),'ablations',fontsize=7.2,color='#59636A')
    text_bp(fig,233,ybp(7.85),'ablations',fontsize=7.2,color='#59636A')
    text_bp(fig,101,164,'V(SafeOT) / V(baseline), log',ha='center',fontsize=7.2)
    text_bp(fig,334,164,'Normalized return difference',ha='center',fontsize=7.2)
    text_bp(fig,2,175,'(c) All-task learning curves',fontweight='bold',fontsize=8.8)
    handles=[Line2D([],[],label=('CPPO-PID' if m=='PID-Lag' else m),color=PALETTE[m]['color'],linestyle=PALETTE[m]['linestyle'],marker=PALETTE[m]['marker'],markersize=2.5) for m in METHODS]
    fig.legend(handles=handles,loc='center',bbox_to_anchor=(.58,1-187/295.2),ncol=4,columnspacing=1.1)
    checks=curve_panel(fig,curves,top=209,first=45,last=242,width=146,height=26,gap=14)
    assert len(forest_checks)==len(forest)
    for r in forest_checks:
        limits=sorted(av.get_xlim() if r['metric']=='V_ratio' else ar.get_xlim())
        assert limits[0]<=r['lo']<=r['hi']<=limits[1], 'CI would be clipped'
    details={'status':'source_aligned_review_candidate' if aligned else 'QA_ONLY_SOURCE_ALIGNMENT_PENDING','source_hashes':hashes,'missing_count_rows':missing,'forest_artists':forest_checks,'curve_artists':checks,'aggregation_performed_by_drawing':False,'forest_stats_recomputed':False,'same_cohort_evidence_verified':aligned,'violation_axis_reversed':True,'better_direction_both':'right','bullet_cost_axis':'symlog; linthresh=1, linscale=1','curves':{'line':'median across task seed means','band':'task IQR, only SafeOT/TRPO-Lag displayed','SafePO_tasks':10,'Bullet_tasks':6},'dagger':json.loads((RUN/'dagger_cost_receipt.json').read_text())}
    if not aligned:
        text_bp(fig,390,312,'Layout review · cohort alignment pending',ha='right',fontsize=7.2,color='#9C3D32')
    dest=(RUN/'outputs' if aligned else RUN/'qa')/'Figure3'
    export(fig,dest,details)
    if aligned:
        (RUN/'outputs/Figure3_caption.txt').write_text((RUN/'caption.tex').read_text())

if __name__=='__main__': main()
