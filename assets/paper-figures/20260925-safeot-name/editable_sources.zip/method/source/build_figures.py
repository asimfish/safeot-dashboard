"""Reproducible native TikZ diagrams. Frozen producer quantiles are drawn unchanged."""
from pathlib import Path
import csv, json, math, hashlib, os, re, subprocess
import fitz
from anonymize import clean_pdf
R=Path(__file__).resolve().parent
ROOT=R.parent
O=ROOT/'outputs';B=ROOT/'build';Q=ROOT/'qa'
for p in (O,B,Q):p.mkdir(exist_ok=True)
PRE=r'''\documentclass[border=0bp]{standalone}
\usepackage{newtxtext,newtxmath}
\usepackage{tikz}
\usetikzlibrary{arrows.meta,calc}
\definecolor{teal}{HTML}{167C80}
\definecolor{orange}{HTML}{D55E00}
\definecolor{blue}{HTML}{0072B2}
\definecolor{purple}{HTML}{8064A2}
\definecolor{gray}{HTML}{59636A}
\definecolor{ink}{HTML}{23343B}
\definecolor{midgray}{HTML}{7C858B}
\DeclareMathSizes{7.2}{7.2}{7.2}{7.2}
\DeclareMathSizes{7.5}{7.5}{7.2}{7.2}
\DeclareMathSizes{8}{8}{7.2}{7.2}
\DeclareMathSizes{8.5}{8.5}{7.2}{7.2}
\DeclareMathSizes{9}{9}{7.2}{7.2}
\newcommand{\bodyfont}{\fontsize{7.5}{8.7}\selectfont}
\newcommand{\smallfont}{\fontsize{7.2}{8.2}\selectfont}
\newcommand{\titlefont}{\fontsize{8.5}{9.7}\selectfont\bfseries}
\newcommand{\mathfont}{\fontsize{9}{10}\selectfont}
\tikzset{every node/.style={font=\bodyfont,text=ink,inner sep=0pt,outer sep=0pt},
 module/.style={rounded corners=3bp,line width=.6bp},
 flow/.style={line width=.8bp,-{Stealth[length=3bp,width=2.6bp]}},
 title/.style={font=\titlefont},formula/.style={font=\mathfont}}
\begin{document}
\begin{tikzpicture}[x=1bp,y=-1bp]
'''
END='\\end{tikzpicture}\n\\end{document}\n'
class Scene:
 def __init__(self,h):self.h=h;self.s=[f'\\path[use as bounding box] (0,0) rectangle (396,{h});'];self.labels=[]
 def raw(self,s):self.s.append(s)
 def text(self,x,y,t,opt='',kind='label'):
  self.s.append(f'\\node[{opt}] at ({x},{y}) {{{t}}};');self.labels.append({'text':t,'kind':kind})
 def box(self,x,y,w,h,stroke='gray!55',fill='white',opt=''):
  self.raw(f'\\draw[module,draw={stroke},fill={fill},{opt}] ({x},{y}) rectangle ({x+w},{y+h});')
 def line(self,pts,opt='draw=gray,line width=.65bp',close=False):
  self.raw('\\draw['+opt+'] '+' -- '.join(f'({x:.4f},{y:.4f})' for x,y in pts)+(' -- cycle' if close else '')+';')
 def arrow(self,pts,col='gray',opt=''):self.line(pts,f'flow,draw={col},{opt}')
 def circle(self,x,y,r=1.8,col='gray',fill='white'):
  self.raw(f'\\filldraw[draw={col},fill={fill},line width=.55bp] ({x},{y}) circle ({r}bp);')
 def graph(self,x,y,w,h,target=False):
  pts=[(x,y+h/2),(x+w*.29,y),(x+w*.68,y),(x+w,y+h/2),(x+w*.68,y+h),(x+w*.29,y+h)]
  edges=[(0,1),(1,2),(2,3),(0,5),(5,4),(4,3)]
  col='teal' if target else 'midgray'
  for j,(i,k) in enumerate(edges):
   thick=j>=3 if target else j<3
   self.line([pts[i],pts[k]],f'draw={col},line width={1.8 if thick else .5}bp')
  for j,(xx,yy) in enumerate(pts):self.circle(xx,yy,1.55,col,col if j==3 else 'white')
 def build(self):return PRE+'\n'.join(self.s)+'\n'+END

rows=list(csv.DictReader((R/'figure3c_alltask_aggregate.csv').open()))
metrics=json.loads((R/'primary_V_summaries.json').read_text())
receipts=[]
safepo_return=next(r for r in csv.DictReader((R/'final_return_safepo.csv').open()) if r['baseline']=='trpo_lag' and r['budget']=='25')
bullet_return=next(r for r in csv.DictReader((R/'final_return_cross_suite.csv').open()) if r['suite']=='Bullet-6' and r['comparator']=='TRPO-Lag' and r['metric']=='R_diff_norm')
RETURN={'SafePO':tuple(float(safepo_return[k]) for k in ['R_diff_median','R_diff_median_lo','R_diff_median_hi']), 'Bullet':tuple(float(bullet_return[k]) for k in ['point','lo','hi'])}
def curves(c):
 c.box(3,112,390,94,'gray!25','white')
 c.text(10,120,'Cost / budget (log)','anchor=west,font=\\smallfont')
 c.line([(229,120),(240,120)],'draw=blue,line width=1.2bp');c.text(244,120,'SafeOT','anchor=west,font=\\smallfont')
 c.line([(314,120),(325,120)],'draw=purple,line width=1.1bp,dashed');c.text(329,120,'TRPO-Lag','anchor=west,font=\\smallfont')
 for suite,x,lo,hi in [('SafePO',27,.02,5),('Bullet',224,.5,50)]:
  y=139;w=156;h=40
  xx=lambda v:x+w*v/100
  yy=lambda v:y+h-(math.log(v)-math.log(lo))/(math.log(hi)-math.log(lo))*h
  st=metrics[suite]
  c.text(x+w/2,131,rf'{suite}: ${st["point"]:.2f}\times V$, {st["lower_V"]}/{st["n_tasks"]} lower','font=\\fontsize{8}{9}\\selectfont\\bfseries')
  for method,col,dash in [('TRPO-Lag','purple',True),('SafeOT','blue',False)]:
   data=sorted([r for r in rows if r['suite']==suite and r['method']==method],key=lambda r:float(r['progress_pct']))
   pts=[(float(r['progress_pct']),float(r['cost_over_budget_median']),float(r['cost_over_budget_q25']),float(r['cost_over_budget_q75'])) for r in data]
   assert all(lo<a<=v<=b<hi for t,v,a,b in pts)
   poly=[(xx(t),yy(a)) for t,v,a,b in pts]+[(xx(t),yy(b)) for t,v,a,b in reversed(pts)]
   c.line(poly,f'fill={col}!14,draw=none',True)
   c.line([(xx(t),yy(v)) for t,v,a,b in pts],f'draw={col},line width={1.25 if not dash else 1.0}bp'+(',dashed' if dash else ''))
   receipts.append({'suite':suite,'method':method,'y_scale':'log','y_limits':[lo,hi],'points_median_q25_q75':pts,'end_of_training_normalized_return_median':float(data[-1]['normalized_return_median'])})
  c.line([(x,y),(x,y+h),(x+w,y+h)],'draw=gray,line width=.5bp')
  c.line([(x,yy(1)),(x+w,yy(1))],'draw=gray,line width=.55bp,dashed')
  for t in ([.1,1] if suite=='SafePO' else [1,10]):
   c.line([(x-2,yy(t)),(x,yy(t))],'draw=gray,line width=.5bp')
   c.text(x-4,yy(t),str(t),'anchor=east,font=\\smallfont',kind='tick')
  for t in [0,100]:c.text(xx(t),185,str(t),'font=\\smallfont',kind='tick')
  point,lower,upper=RETURN[suite]
  c.text(x+w/2,194,rf'Final $\Delta R_{{\rm norm}}$: ${point:.3f}\ [{lower:.3f},\,{upper:.3f}]$','font=\\smallfont')
  c.text(x+w/2,185,r'training (\%)','font=\\smallfont')
 c.text(198,202,r'$V=$ cumulative violation during training','font=\\smallfont')

def figure1():
 c=Scene(208.8)
 c.box(3,3,100,102,'gray!50','gray!2')
 c.box(110,3,283,102,'teal','teal!4')
 c.text(53,16,r'Feedback-only prices\\react after violations','title,align=center')
 # One schematic: cost and price use their own illustrative vertical scales.
 x=18;y=43;w=73;h=45
 c.line([(x,y),(x,y+h),(x+w,y+h)],'draw=gray,line width=.5bp')
 c.line([(x,y+26),(x+w,y+26)],'draw=gray,line width=.6bp,dashed')
 c.text(x-3,y+26,'$B$','anchor=east,font=\\smallfont')
 ts=[i/60 for i in range(61)]
 cost=[(.0,0.16),(.2,.24),(.35,.45),(.5,.81),(.68,.90),(.82,.65),(1,.42)]
 def interp(t,knots):
  for (a,b),(d,e) in zip(knots,knots[1:]):
   if a<=t<=d:return b+(e-b)*(t-a)/(d-a)
  return knots[-1][1]
 baseline=.4222
 cp=[(x+t*w,y+h-interp(t,cost)*h) for t in ts]
 pp=[(x+t*w,y+h-(.05+max(0,t-.45)*1.15)*h) for t in ts]
 poly=[(x+t*w,y+h-max(baseline,interp(t,cost))*h) for t in ts]+[(x+w,y+26),(x,y+26)]
 c.line(poly,'fill=gray!13,draw=none',True)
 c.line(cp,'draw=gray,line width=1.1bp')
 c.line(pp,'draw=purple,line width=1.1bp,dashed')
 c.text(88,43,'cost','anchor=east,font=\\smallfont')
 c.text(91,80,'price','anchor=east,font=\\smallfont,text=purple')
 c.text(54,97,'training','font=\\smallfont')
 # Dominant module: data -> graph -> solve; only budget duals continue to actor.
 c.text(251.5,15,'SafeOT solves the price from rollouts','title,text=teal')
 c.text(132,31,'Rollouts','font=\\smallfont')
 for a,b in [((121,51),(132,43)),((132,43),(143,51)),((121,51),(132,60)),((132,60),(143,51))]:c.line([a,b],'draw=gray,line width=.7bp')
 for p in [(121,51),(132,43),(132,60),(143,51)]:c.circle(*p,1.5)
 c.arrow([(146,51),(161,51)])
 c.graph(164,41,39,20)
 c.text(183.5,32,r'$\widehat F$','formula')
 c.arrow([(207,51),(221,51)],'teal')
 c.box(224,38,65,27,'teal','teal!10')
 c.text(256.5,51,r'One flow solve\\all budgets','align=center,text=teal')
 c.arrow([(292,51),(315,51)],'teal')
 c.graph(320,41,56,20,True)
 c.text(348,32,r'$F^\star$','formula,text=teal')
 c.arrow([(256.5,65),(256.5,88)],'teal')
 c.text(262,77,r'budget duals $\lambda^\star$','anchor=west,font=\\smallfont,text=teal')
 c.box(117,81,100,18,'orange!45','orange!5')
 c.text(167,90,r'$\beta$: observed-cost feedback','font=\\smallfont,text=orange')
 c.arrow([(217,90),(234,96)],'gray')
 c.text(276,96,r'$\lambda=\bar\lambda^\star+{\color{orange}\beta}$','formula')
 c.arrow([(313,96),(344,96)],'teal')
 c.text(367,96,'Actor','font=\\fontsize{8}{9}\\selectfont\\bfseries')
 curves(c)
 return c

def figure2():
 c=Scene(165.6)
 # Five numbered modules, with inputs/budgets stacked to free projection space.
 c.box(3,3,65,126,'gray!55','gray!2')
 c.box(76,3,78,69,'gray!55','white')
 c.box(76,79,78,50,'gray!55','white')
 c.box(163,3,123,126,'teal','teal!7')
 c.box(295,3,98,126,'gray!55','white')
 c.text(35.5,14,'1  Rollout','title,text=gray')
 c.text(115,14,'2  Rollout graph','title')
 c.text(115,89,'3  Soft budgets','title')
 c.text(220,14,'4  Flow projection','title,text=teal')
 c.text(280,23,'new','anchor=east,text=teal,font=\\smallfont')
 c.text(344,14,'5  Actor update','title,text=gray')
 # Standard RL source.
 c.text(35.5,35,r'$\pi_t$','formula,text=gray')
 for a,b in [((17,51),(31,51)),((36,51),(51,51))]:c.arrow([a,b])
 for x in (15,33,53):c.circle(x,51,2,'gray')
 c.box(11,69,49,34,'gray!50','white')
 c.text(35.5,78,'GAE','title,text=gray')
 c.text(35.5,94,r'$\widehat A_r,\ \widehat A_{c_k}$')
 c.text(35.5,117,r'Costs $\bar J_k$')
 # Top graph input card, all labels associated with graph semantics.
 c.graph(96,26,38,12)
 c.text(115,45,'nodes = state clusters','font=\\smallfont')
 c.text(115,54,'edges = transitions','font=\\smallfont')
 c.text(115,65,r'per edge: $\widehat F, A, C_k$','font=\\smallfont')
 c.arrow([(68,42),(76,42)])
 c.arrow([(154,42),(163,42)],'teal')
 # Budget card: one equation, not an extra forbidden-edge story.
 c.text(115,108,r'$b_k=B_k/L$','formula')
 c.text(115,121,'one bound per cost','font=\\smallfont')
 c.arrow([(154,101),(163,101)],'teal')
 # Complete benchmark projection (H is empty), with real stacked math.
 c.text(224.5,35,r'$\displaystyle\min_{F\geq0}\ -\langle A,F\rangle$')
 c.text(224.5,49,r'$+\,\varepsilon\,\mathrm{KL}(F\,\|\,\widehat F)$')
 c.text(224.5,66,r'$\begin{gathered}\text{s.t. }F\mathbf1-\gamma F^\top\mathbf1\\=(1-\gamma)\mu_0\end{gathered}$')
 c.text(224.5,85,r'$\langle C_k,F\rangle\leq b_k\quad\forall k$')
 c.graph(174,99,35,13)
 c.graph(242,99,35,13,True)
 c.arrow([(214,105.5),(237,105.5)],'teal')
 c.text(192,94,r'$\widehat F$','font=\\smallfont')
 c.text(261,94,r'$F^\star$','font=\\smallfont,text=teal')
 c.text(224.5,122,r'$F^\star$: target, not executed','font=\\smallfont,text=teal')
 # Solved multipliers cross into policy space; graph target does not.
 c.arrow([(280,105.5),(290,105.5),(290,33),(300,33)],'teal')
 c.text(306,33,r'clip $c$ + EMA','anchor=west,font=\\smallfont,text=teal')
 c.text(285,97,r'$\lambda_k^\star$','anchor=east,font=\\smallfont,text=teal')
 c.arrow([(344,39),(344,45)],'teal')
 c.text(344,54,r'$\lambda_k=\bar\lambda_k^\star+{\color{orange}\beta_k}$','formula')
 c.arrow([(344,62),(344,67)],'gray')
 c.text(344,81,r'$\displaystyle\widetilde A=\frac{\widehat A_r-\sum_k\lambda_k\widehat A_{c_k}}{1+\sum_k\lambda_k}$')
 c.arrow([(344,94),(344,100)],'gray')
 c.box(313,102,65,16,'gray!45','gray!3')
 c.text(345.5,110,'PPO / TRPO','text=gray')
 c.text(345.5,124,r'$\pi_{t+1}$','font=\\smallfont,text=gray')
 # Two distinct standard channels; no large feedback box.
 c.arrow([(60,95),(72,95),(72,136),(303,136),(303,84),(308,84)],'gray')
 c.text(167,136,r'GAE advantages $\widehat A_r,\widehat A_{c_k}$','fill=white,inner xsep=4bp,font=\\smallfont')
 c.arrow([(35.5,122),(35.5,148),(389,148),(389,54),(383,54)],'gray')
 c.text(212,148,r'${\color{orange}\beta_k}\!\leftarrow\![\beta_k+\eta(\bar J_k-B_k)]_+$','fill=white,inner xsep=4bp,font=\\smallfont')
 c.arrow([(345.5,129),(345.5,160),(7,160),(7,35),(23,35)],'gray')
 c.text(163,160,'next rollout','fill=white,inner xsep=4bp,font=\\smallfont')
 return c

CAPTIONS={
'Figure1':r'SafeOT adds rollout-derived budget prices to observed-cost feedback. The upper-left schematic illustrates fixed-step feedback lag; the projection yields a target flow, while clipped and filtered duals price the actor. Curves show task medians and interquartile bands of seed-mean cost. Final normalized return differences versus TRPO-Lag have 95\% intervals, not equivalence guarantees. Primary violation ratios, curve cohorts and return estimands differ; Appendix specifies each.',
'Figure2':r'SafeOT uses one flow solve to supply budget shadow prices to a standard actor update. Gray components perform rollout, GAE, feedback and PPO/TRPO; the teal projection changes target visitation, which is not executed. Here $L$ is episode length, $\varepsilon$ the KL weight, $\eta$ the illustrative fixed feedback step, $c$ the price cap, and $B_k$ the episode budget. Benchmark hard-edge masks $H$ are empty. Implementation feedback may use Adam; clipping and EMA produce $\bar\lambda^\star$.'}

def build(name,c):
 tex=O/f'{name}.tex';tex.write_text(c.build())
 env=dict(os.environ,PATH='/usr/bin:/bin:'+os.environ.get('PATH',''))
 res=subprocess.run(['/usr/bin/pdflatex','-halt-on-error','-interaction=nonstopmode','-output-directory',str(B),str(tex)],env=env,capture_output=True,text=True)
 (Q/f'{name}_compile.txt').write_text(res.stdout+res.stderr)
 if res.returncode:raise RuntimeError(res.stdout[-4500:])
 clean_pdf(B/f'{name}.pdf',O/f'{name}.pdf')
 with fitz.open(O/f'{name}.pdf') as d:
  p=d[0]
  for suf,cs,dpi in [('300dpi',fitz.csRGB,300),('grayscale',fitz.csGRAY,300),('print96',fitz.csRGB,96)]:
   pm=p.get_pixmap(matrix=fitz.Matrix(dpi/72,dpi/72),colorspace=cs,alpha=False);pm.set_dpi(dpi,dpi);pm.save(O/f'{name}_{suf}.png')
  (O/f'{name}.svg').write_text(p.get_svg_image(text_as_path=True))
  spans=[s for b in p.get_text('dict')['blocks'] if 'lines' in b for l in b['lines'] for s in l['spans'] if s['text'].strip()]
  fonts=[{'name':f[3],'type':f[2],'embedded_bytes':len(d.extract_font(f[0])[3])} for f in p.get_fonts()]
  report={'figure':name,'size_in':[p.rect.width/72,p.rect.height/72],'min_font_pt':min(s['size'] for s in spans),'font_sizes':sorted(set(round(s['size'],4) for s in spans)),'fonts':fonts,'raster_images':len(p.get_images()),'outside':[s for s in spans if not p.rect.contains(fitz.Rect(s['bbox']))],'metadata':d.metadata,'xmp':bool(d.get_xml_metadata()),'text':p.get_text(),'label_count':len(c.labels),'non_tick_labels':sum(x['kind']!='tick' for x in c.labels),'labels':c.labels,'sha256':hashlib.sha256((O/f'{name}.pdf').read_bytes()).hexdigest()}
  report['mechanical_pass']=report['min_font_pt']>=7 and not report['outside'] and not report['raster_images'] and all(f['embedded_bytes'] for f in fonts) and abs(p.rect.width-396)<.02 and (name!='Figure1' or p.rect.height<=208.82)
 (O/f'{name}_font_report.json').write_text(json.dumps(report,indent=2))
 (O/f'{name}_caption.tex').write_text(CAPTIONS[name]+'\n')
 print(name,json.dumps({k:report[k] for k in ['size_in','min_font_pt','label_count','non_tick_labels','mechanical_pass']}),flush=True)
 return report
if __name__=='__main__':
 reports=[build('Figure1',figure1()),build('Figure2',figure2())]
 (O/'captions.json').write_text(json.dumps(CAPTIONS,indent=2)+'\n')
 (O/'font_report.json').write_text(json.dumps(reports,indent=2)+'\n')
 (O/'curve_render_receipt.json').write_text(json.dumps(receipts,indent=2)+'\n')
