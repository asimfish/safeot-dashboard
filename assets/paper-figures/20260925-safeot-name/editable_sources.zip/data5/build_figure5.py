from pathlib import Path
import csv,json,hashlib,argparse
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parent);ap.add_argument('--out',type=Path);args=ap.parse_args()
R=args.root; E=R/'evidence';O=args.out or R/'outputs';O.mkdir(exist_ok=True,parents=True)
a=list(csv.DictReader((E/'r24_public/a3/figure5a_a3_cell_ratios.csv').open()));p=list(csv.DictReader((E/'r29_public/local_budget/outputs/paired.csv').open()))
plt.rcParams.update({'font.size':7.2,'axes.titlesize':7.5,'axes.labelsize':7.2,'xtick.labelsize':7.2,'ytick.labelsize':7.2,'legend.fontsize':7.2,'pdf.fonttype':42,'ps.fonttype':42,'font.family':'DejaVu Sans','axes.spines.top':False,'axes.spines.right':False})
fig,axs=plt.subplots(3,1,figsize=(2.65,3.15),gridspec_kw={'height_ratios':[1,1,1]});fig.subplots_adjust(left=.18,right=.98,top=.945,bottom=.165,hspace=.77)
colors={'lag':'#BD6B36','pid':'#476A91','switch':'#25917C','warm':'#8F76A4','switch4':'#AF4760'}
labels={'lag':'Lag','pid':'PID','switch':'Switch-1','warm':'Warm','switch4':'Switch-4'}
for i,ax in enumerate(axs):
 ax.set_yscale('log');ax.axhline(1,color='#42484E',lw=.65,ls=':');ax.set_ylabel('V(rule) /\nV(SafeOT)',labelpad=1);ax.grid(axis='y',alpha=.12)
 ax.tick_params(axis='both',length=2,pad=1)
for rule in ['lag','pid','switch','warm']:
 yy=[np.median([float(x['V_rule_over_V_solve']) for x in a if x['rule']==rule and int(x['K'])==k]) for k in [1,4,8]]
 axs[0].plot([0,1,2],yy,'o-',color=colors[rule],ms=2.8,lw=.8,label=labels[rule])
axs[0].set_title('(a) Exact tabular: 40 cells per K',loc='left',pad=3);axs[0].set_xticks([0,1,2],['K=1','K=4','K=8']);axs[0].set_yticks([1,3,10],[1,3,10]);axs[0].set_ylim(.8,22)
for rule in ['lag','pid','switch','switch4']:
 vals=[]
 for i,k in enumerate([1,4,8]):
  v=[1/float(x['V_ratio']) for x in p if x['scope']==f'E034_K{k}' and x['solve']=='solve_unc' and x['rule']==({'switch':'switch_c1','switch4':'switch_c4'}.get(rule,rule))]
  assert len(v)==10,(rule,k,len(v)); vals.append(np.median(v))
  axs[1].scatter(np.full(len(v),i)+np.linspace(-.065,.065,len(v)),v,s=3,color=colors[rule],alpha=.28,edgecolors='none')
 axs[1].plot([0,1,2],vals,'o-',color=colors[rule],ms=2.8,lw=.8,label=labels[rule])
axs[1].set_title('(b) Grids: SafeOT (unclipped)',loc='left',pad=3);axs[1].set_xticks([0,1,2],['K=1','K=4','K=8']);axs[1].set_yticks([.1,1,10,100],[.1,1,10,100]);axs[1].set_ylim(.025,120)
for ri,rule in enumerate(['lag','pid','switch']):
 med=[]
 for i,task in enumerate(['HalfCheetahJ6','AntJ8']):
  v=[1/float(x['V_ratio']) for x in p if x['scope']=='E037_secondary' and x['solve']=='solve_unc' and x['rule']==({'switch':'switch_c1'}.get(rule,rule)) and x['task']==task]
  assert len(v)==5,(rule,task,len(v));med.append(np.median(v));axs[2].scatter(np.full(len(v),i)+(ri-1)*.13+np.linspace(-.025,.025,len(v)),v,s=5,alpha=.35,color=colors[rule],edgecolors='none')
 axs[2].plot(np.array([0,1])+(ri-1)*.13,med,'o',color=colors[rule],ms=3.2)
axs[2].set_title('(c) Robots: SafeOT (unclipped)',loc='left',pad=3);axs[2].set_xticks([0,1],['HalfCheetah (6)','Ant (8)']);axs[2].set_xlim(-.4,1.4);axs[2].set_yticks([1,3,10],[1,3,10]);axs[2].set_ylim(.75,24)
from matplotlib.lines import Line2D
fig.legend([Line2D([0],[0],color=colors[k],marker='o',ms=3,lw=.8) for k in colors],[labels[k] for k in colors],loc='lower center',bbox_to_anchor=(.53,.005),ncol=3,frameon=False,columnspacing=.65,handlelength=1,handletextpad=.25)
fig.savefig(O/'Figure5_local.pdf',metadata={'Creator':'','Producer':'','CreationDate':None});fig.savefig(O/'Figure5_local.svg',metadata={'Date':None,'Creator':''});fig.savefig(O/'Figure5_local.png',dpi=300)
(O/'Figure5_receipt.json').write_text(json.dumps({'a_rows':len(a),'paired_rows':len(p),'robot_scope':'prospective five-seed confirmation; primary governs','note':'Points/lines descriptive, no CIs. Reciprocal medians displayed; do not round from textual solve/rule medians.'},indent=2))
