"""Compact signed means plus separate direction medians; no stacked medians."""
import csv,hashlib,json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.text import Text
from matplotlib.patches import Patch
from matplotlib.lines import Line2D

p=Path(__file__).parent;out=p/'figure';out.mkdir(exist_ok=True)
rows=list(csv.DictReader((p/'outputs/component_distributions.csv').open()))
tasks=list(csv.DictReader((p/'outputs/per_task.csv').open()))
order=[('SafetyPointGoal1-v0','PG1'),('SafetyCarGoal1-v0','CG1'),('SafetyPointPush1-v0','PP1'),('SafetyCarPush1-v0','CP1'),
       ('SafetyPointButton1-v0','PB1'),('SafetyCarButton1-v0','CB1'),('SafetyAntVelocity-v1','Ant'),
       ('SafetyHalfCheetahVelocity-v1','HC'),('SafetyHopperVelocity-v1','Hop'),('SafetyWalker2dVelocity-v1','W2d')]
d={(r['key'],r['metric']):r for r in rows if r['level']=='task'};td={r['key']:r for r in tasks}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':7.2,'axes.labelsize':7.2,'xtick.labelsize':7.2,
 'ytick.labelsize':7.2,'legend.fontsize':7.2,'pdf.fonttype':42,'svg.fonttype':'none','svg.hashsalt':'r26-realization',
 'axes.linewidth':.55,'axes.spines.top':False,'axes.spines.right':False,'xtick.major.pad':1.5,'ytick.major.pad':2})
fig=plt.figure(figsize=(2.65,3.10));left=fig.add_axes([.20,.23,.455,.65]);right=fig.add_axes([.752,.23,.223,.65])
fig.text(.02,.985,'(a) Cost components and direction',fontsize=7.5,weight='bold',va='top')
left.set_title('Signed means',fontsize=7.2,pad=2);right.set_title('Medians',fontsize=7.2,pad=2)
colors=['#56B4E9','#0072B2','#D55E00','#009E73'];terms=['r_over_b','real_over_b','drift_over_b','agg_over_b']
plotted=[]
for i,(task,name) in enumerate(order):
    pos=neg=0.
    for term,color in zip(terms,colors):
        v=float(d[task,term]['mean']);base=pos if v>=0 else neg
        left.barh(i,v,left=base,height=.66,color=color,edgecolor='white',linewidth=.1)
        if v>=0:pos+=v
        else:neg+=v
        plotted.append(dict(task=task,quantity=term,aggregation='mean',value=v,n=int(td[task]['pairs'])))
    net=float(d[task,'excess_over_b']['mean']);assert abs(net-pos-neg)<1e-12
    left.scatter([net],[i],marker='D',s=7,color='black',edgecolors='white',lw=.3,zorder=5)
    plotted.append(dict(task=task,quantity='net_budget_error',aggregation='mean',value=net,n=int(td[task]['pairs'])))
    for term,marker,color,dy in [('align','o','#333333',-.13),('proj','^','#A63A92',.13)]:
        v=float(d[task,term]['median']);right.scatter([v],[i+dy],s=10,marker=marker,color=color,lw=.35,edgecolors='white')
        plotted.append(dict(task=task,quantity=term,aggregation='median',value=v,n=int(td[task]['pairs'])))
left.set_yticks(range(10),[name+' ('+td[task]['runs']+')' for task,name in order]);left.tick_params(axis='y',length=0)
left.set_xlim(-.52,1.88);left.set_xticks([-.5,0,1,1.8],['−.5','0','1','1.8']);left.set_xlabel('Mean(term / b)',labelpad=1.5)
right.set_xlim(-.03,.68);right.set_xticks([0,.3,.6]);right.set_yticks([]);right.set_xlabel('Cos / proj',labelpad=1.5)
for ax in [left,right]:
    ax.set_ylim(9.55,-.55);ax.axvline(0,color='#777777',ls='--',lw=.6);ax.grid(axis='x',alpha=.10,lw=.4)
    ax.spines['left'].set_visible(False)
handles=[Patch(facecolor=c,label=l) for c,l in zip(colors,['Target','Flow','Drift','Remainder'])]
handles.extend([Line2D([],[],marker='o',color='#333333',ls='',markersize=3,label='Alignment'),
                Line2D([],[],marker='^',color='#A63A92',ls='',markersize=3,label='Projection')])
fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.5,.015),ncol=3,frameon=False,
           handlelength=.75,handletextpad=.3,columnspacing=.65,labelspacing=.2,borderpad=0)
fig.canvas.draw();renderer=fig.canvas.get_renderer();bounds=[]
for t in fig.findobj(Text):
    if not t.get_visible() or not t.get_text():continue
    bb=t.get_window_extent(renderer)
    assert t.get_fontsize()>=7.2
    assert bb.x0>=-.5 and bb.y0>=-.5 and bb.x1<=fig.bbox.x1+.5 and bb.y1<=fig.bbox.y1+.5,(t.get_text(),bb.bounds)
    bounds.append(dict(text=t.get_text(),font=t.get_fontsize(),bbox=list(bb.bounds)))
for ext in ['pdf','svg','png']:
    kw={'metadata':{'CreationDate':None,'ModDate':None,'Creator':'','Producer':''}} if ext=='pdf' else {'metadata':{'Date':None,'Creator':''}} if ext=='svg' else {'dpi':300}
    fig.savefig(out/f'Figure4a_stacked_direction.{ext}',**kw)
with (out/'plotted_values.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(plotted[0]));w.writeheader();w.writerows(plotted)
(out/'verification.json').write_text(json.dumps(dict(size_inches=[2.65,3.10],min_font_pt=7.2,text_in_bounds=True,
    signed_stacks='Positive and negative mean terms accumulated separately; black diamond is their signed sum.',
    directions='Medians across retained pairs, separate axis; no additive identity claimed for medians.',
    cells=19,tasks=10,pairs=1672,source_sha256=hashlib.sha256((p/'outputs/component_distributions.csv').read_bytes()).hexdigest(),
    script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),text_bounds=bounds),indent=2)+'\n')
print('Figure4a ready: 2.65 x 3.10 inches, minimum 7.2 pt; additive task means and separate direction medians.')
