"""V10: source-grounded modular semantic reconstruction, not pixel tracing."""
from pathlib import Path
import argparse,json
from PIL import Image
from drawing import Drawing,save,INK,TEAL,GRAY,LINE,WHITE
from motifs import matrix,graph,hard_edge,prices,BLUE,GOLD,BT,TT,GT

SOFT='#F6F8F9'

def header(d,id,title,x,y,w,color=INK,size=34):
    d.txt(id+'_title',title,x+22,y+43,size,True,color=color)
    d.line(id+'_rule',[x+20,y+65],[x+w-20,y+65],LINE,1.3)

def fraction(d,id,x,y,size=38,half=160):
    with d.module(id):
        d.math(id+'_num',[('A','r',''),' − ',('∑','k',''),' ',('λ','k',''),('A','c_k','')],x,y,size,center=True)
        d.line(id+'_bar',[x-half,y+17],[x+half,y+17],INK,1.8)
        d.math(id+'_den',['1 + ',('∑','k',''),' ',('λ','k','')],x,y+57,size,center=True)

def clip_plot(d,id,x,y,w,h):
    with d.module(id):
        d.line(id+'_x',[x,y+h],[x+w,y+h],GRAY,1.5,True)
        d.line(id+'_y',[x,y+h],[x,y],GRAY,1.5,True)
        d.join(id+'_y',id+'_x','Analytical axes meet at the origin.')
        d.route(id+'_curve',[[x+7,y+h-5],[x+w*.60,y+h*.25],[x+w*.91,y+h*.25]],TEAL,3,False)
        d.line(id+'_capline',[x+5,y+h*.25],[x+w*.53,y+h*.25],GOLD,1.6,dash=[6,5])
        d.math(id+'_cap',['c'],x-21,y+h*.25+8,31,color=GOLD,center=True)
        d.math(id+'_raw',[('λ','','*')],x+w-5,y+h+43,32,color=TEAL,center=True)

def figure1(d):
    # One enclosing core holds all operations AND the policy update.
    with d.module('shared_construction',[348,24,1304,930],WHITE,TEAL,2.4):
        d.txt('method_title','SafeOT-Dual',1000,86,43,True,color=TEAL,center=True)
        d.txt('method_subtitle','One shared price construction',1000,132,33,color=GRAY,center=True)
        with d.module('joint_constraints',[374,174,292,538],SOFT,LINE,1.3):
            header(d,'joint','Joint constraints',374,174,292,INK,32)
            for j,k in enumerate(['1','2','K']):
                y=278+j*87
                d.math('cost_label'+str(j),[('C',k,'')],413,y+34,35,center=True,color=GOLD)
                matrix(d,'cost_matrix'+str(j),454,y,108,52,GOLD,GT)
                d.math('budget_label'+str(j),[('b',k,'')],607,y+34,35,center=True,color=GOLD)
            d.line('constraint_inner_rule',[398,548],[642,548],LINE,1.2)
            d.txt('hard_support_label','Hard graph support',520,589,30,center=True)
            hard_edge(d,'hard_support',438,612)
            d.math('hard_zero',[('F','H',''),' = 0'],520,683,36,center=True)
        with d.module('graph_problem',[708,174,422,538],SOFT,LINE,1.3):
            header(d,'graph','Graph optimization',708,174,422,INK,32)
            graph(d,'joint_graph',763,304,312,144)
            next(e for e in d.elements if e['id']=='joint_graph_node4')['fill']=TEAL
            d.math('objective_1',[('min','F≥0',''),' − ⟨A,F⟩'],919,527,38,center=True)
            d.math('objective_2',['+ ε KL(F ∥ F̂)'],919,576,38,center=True)
            d.txt('balance','discounted flow balance',919,629,30,center=True)
            d.math('budget_constraint',[('⟨C','k',''),',F⟩ ≤ ',('b','k','')],919,683,36,center=True)
        with d.module('shared_price',[1172,174,454,538],SOFT,LINE,1.3):
            header(d,'price','Shared safety price',1172,174,454,INK,32)
            d.math('raw_price',[('λ','','*')],1250,301,38,center=True,color=TEAL)
            d.line('raw_to_filter',[1281,287],[1312,287],TEAL,2.3,True)
            with d.module('clip_filter',[1317,263,269,52],TT,None):
                d.txt('clip_filter_label','Clip + filter',1451,299,32,center=True,color=TEAL)
            d.line('filter_to_graph_price',[1451,321],[1451,344],TEAL,2.3,True)
            # Adjacent terms, visibly distinct origins, merge in one place.
            d.math('conditioned_price',[('λ̄','','*')],1304,407,43,center=True,color=TEAL)
            d.txt('conditioned_label','graph price',1304,449,30,center=True,color=TEAL)
            d.math('feedback_price',['β'],1500,407,43,center=True,color=GOLD)
            d.txt('feedback_label','cost feedback',1500,449,30,center=True,color=GOLD)
            d.route('filtered_route',[[1451,347],[1304,347],[1304,361]],TEAL,2.2)
            d.route('graph_to_sum',[[1304,466],[1304,506],[1370,506]],TEAL,2.2)
            d.route('feedback_to_sum',[[1500,466],[1500,506],[1430,506]],GOLD,2.2)
            with d.module('price_junction',[1375,481,50,50],WHITE,TEAL,1.8):
                d.txt('price_plus','+',1400,519,36,color=TEAL,center=True)
            d.line('sum_to_price',[1400,536],[1400,558],TEAL,2.3,True)
            d.math('unified_price',[('λ','k',''),' = ',('λ̄','k','*'),' + ',('β','k','')],1400,609,40,center=True,color=TEAL)
            prices(d,'shared_vector',1272,640)
        d.line('constraints_to_graph',[673,392],[700,392],TEAL,2.4,True)
        d.line('graph_to_price',[1137,392],[1164,392],TEAL,2.4,True)
        with d.module('shared_policy_update',[374,769,1252,153],TT,None):
            d.txt('one_update_label','One policy update',401,813,33,True,color=TEAL)
            d.math('normalized_label',['Ã ='],735,857,38,center=True)
            fraction(d,'common_advantage',990,824,37,178)
            d.line('advantage_to_optimizer',[1201,844],[1250,844],TEAL,2.5,True)
            with d.module('optimizer',[1270,807,324,76],WHITE,TEAL,1.5):
                d.txt('optimizer_label','PPO / TRPO',1432,856,35,True,color=TEAL,center=True)
        d.route('shared_price_to_update',[[1400,719],[1400,743],[1086,743],[1086,763]],TEAL,2.4)
    # Endpoints are interpretations/settings, so connectors are leaders, not flow arrows.
    d.line('penalty_relation',[318,438],[341,438],BLUE,1.6)
    d.line('constraint_relation',[1659,438],[1682,438],GOLD,1.6)
    with d.module('penalty_view',[24,162,290,695],WHITE,LINE,1.4):
        header(d,'penalty','Penalty view',24,162,290,BLUE,34)
        d.math('penalty_objective',[('max','π',''),' ',('J','r',''),'(π)'],169,285,36,center=True)
        d.math('penalty_cost',['− ',('λ','','T'),('J','c',''),'(π)'],169,331,36,center=True)
        d.txt('weighted_costs_label','Weighted costs',169,391,30,center=True,color=GRAY)
        for j,k in enumerate(['1','2','K']):
            x=51+j*80
            with d.module('weighted_term'+str(j),[x,420,75,57],BT,None):
                d.math('weighted_term_label'+str(j),[('λ',k,'')],x+37.5,458,34,center=True,color=BLUE)
        d.math('weighted_sum',[('∑','k',''),' ',('λ','k',''),('J','c_k',''),'(π)'],169,531,34,center=True)
        d.line('exact_rule',[45,564],[293,564],LINE,1.3)
        d.txt('exact_label','Exact settings',169,606,31,True,color=BLUE,center=True)
        d.math('zero_clip',['c = 0'],169,653,36,center=True)
        d.txt('fixed_beta','fixed β',169,696,30,center=True)
        d.txt('fixed_family','fixed penalty',169,731,30,center=True)
        d.txt('adaptive_beta','adaptive β',169,778,30,center=True)
        d.txt('adaptive_family','Lagrangian',169,813,30,center=True)
    with d.module('constraint_view',[1686,162,290,695],WHITE,LINE,1.4):
        header(d,'constraint','Constraint view',1686,162,290,GOLD,33)
        d.math('constrained_objective',[('max','π',''),' ',('J','r',''),'(π)'],1831,285,36,center=True)
        d.math('constrained_cost',['s.t. ',('J','c',''),'(π) ≤ B'],1831,331,35,center=True)
        d.txt('budget_schematic_label','Joint budgets',1831,389,30,center=True,color=GRAY)
        with d.module('budget_geometry'):
            d.shape('budget_region',[1750,423,103,94],GT,None,shape='rect')
            d.line('budget_x',[1747,520],[1919,520],GRAY,1.7,True)
            d.line('budget_y',[1747,520],[1747,406],GRAY,1.7,True)
            d.join('budget_y','budget_x','Budget schematic axes share the origin.')
            d.line('budget_vertical',[1856,516],[1856,420],GOLD,1.7,dash=[6,4])
            d.line('budget_horizontal',[1751,420],[1856,420],GOLD,1.7,dash=[6,4])
            d.join('budget_horizontal','budget_vertical','Two unit budget boundaries meet.')
            d.math('budget_axis_x',[('J','c1',''),'/',('B','1','')],1833,553,29,center=True)
            d.math('budget_axis_y',[('J','c2',''),'/',('B','2','')],1905,446,28,center=True)
        d.line('limits_rule',[1707,578],[1955,578],LINE,1.3)
        d.txt('limits_title','Graph-price limits',1831,616,30,True,color=GOLD,center=True)
        d.txt('limits_qualification','under assumptions',1831,650,28.5,color=GRAY,center=True)
        d.math('zero_limit',['ε → 0:'],1711,695,31)
        d.txt('lp_limit','LP-derived price',1831,730,28.5,center=True)
        d.math('infty_limit',['ε → ∞:'],1711,768,31)
        d.txt('active_limit','clipped active-set limit',1831,834,28.5,center=True,color=GRAY)

def figure2(d):
    with d.module('rollout_inputs',[22,24,392,851],WHITE,BLUE,1.7):
        header(d,'inputs','(a)  Rollout & graph',22,24,392,BLUE,33)
        with d.module('rollout',[43,119,350,287],SOFT,None):
            d.txt('rollout_title','Policy rollout',63,159,32,True)
            for j,k in enumerate(['0','1','…','T']):
                x=79+j*90
                with d.module('rollout_state'+str(j),[x-19,186,47,45],BT,None):
                    if k=='…':d.txt('state_label'+str(j),'…',x+4,219,30,center=True,color=BLUE)
                    else:d.math('state_label'+str(j),[('s',k,'')],x+4,218,34,center=True,color=BLUE)
                if j<3:d.line('rollout_arrow'+str(j),[x+32,209],[x+67,209],BLUE,2,True)
            for j,(label,col,tint) in enumerate([('rewards',BLUE,BT),('K costs',GOLD,GT)]):
                y=280+j*61;d.txt('sample_label'+str(j),label,63,y+15,30,color=col)
                for k in range(4):d.shape(f'sample_{j}_{k}',[213+k*45,y-7,24,24],col if k==1 else tint,col,1,shape='rect')
        d.line('rollout_to_graph',[216,413],[216,446],BLUE,2.1,True)
        d.txt('graph_construction_label','build graph',245,435,28,color=GRAY)
        with d.module('empirical_graph',[43,454,350,264],SOFT,None):
            d.txt('empirical_title','Empirical graph',63,495,32,True)
            graph(d,'empirical_network',84,530,266,90,BLUE)
            d.math('graph_statistics',['F̂, A, ',('C','k',''),', ',('μ','0','')],218,696,36,center=True)
        d.math('episode_cost_output',[('J̄','k',''),'  (episode costs)'],218,772,33,center=True,color=GOLD)
        d.txt('advantages_label','GAE advantages',218,842,31,True,color=BLUE,center=True)
    with d.module('unified_price_construction',[468,24,1086,789],WHITE,TEAL,2.4):
        header(d,'unified','(b)  Unified price construction',468,24,1086,TEAL,36)
        with d.module('joint_solver',[488,119,668,473],SOFT,LINE,1.2):
            header(d,'solve','Joint graph solve',488,119,668,INK,32)
            for j,k in enumerate(['1','2','K']):
                x=514+j*105
                matrix(d,'graph_cost'+str(j),x,231,76,45,GOLD,GT)
                d.math('graph_cost_name'+str(j),[('C',k,'')],x+38,217,31,center=True,color=GOLD)
            d.math('rate_budget',[('b','k',''),' = ',('B','k',''),'/L'],972,230,35,center=True,color=GOLD)
            d.math('zero_support',[('F','H',''),' = 0'],972,276,34,center=True)
            d.line('graph_definition_rule',[508,300],[1136,300],LINE,1.3)
            d.math('flow_objective',[('min','F≥0',''),' − ⟨A,F⟩ + ε KL(F ∥ F̂)'],822,357,35,center=True)
            d.math('flow_balance',['F1 − γ',('F','','T'),'1 = (1−γ)',('μ','0','')],822,412,33,center=True)
            d.math('soft_budgets',[('⟨C','k',''),',F⟩ ≤ ',('b','k',''),'   (soft channels)'],822,460,33,center=True)
            with d.module('newton',[545,505,214,61],WHITE,LINE,1.2):
                d.math('newton_label',['Newton in u'],652,547,32,center=True)
            with d.module('bisection',[880,505,247,61],WHITE,LINE,1.2):
                d.math('bisection_label',['Bisection in λ'],1003,547,32,center=True)
            d.line('newton_to_bisection',[768,524],[872,524],TEAL,1.9,True)
            d.line('bisection_to_newton',[872,550],[768,550],TEAL,1.9,True)
        with d.module('conditioning',[1210,119,323,473],SOFT,LINE,1.2):
            header(d,'condition','Clip + filter',1210,119,323,INK,32)
            d.math('filter_first',[('λ̄','','*'),' ← (1−α)',('λ̄','','*')],1371,250,34,center=True)
            d.math('filter_second',['+ α min(',('λ','','*'),',c)'],1371,301,34,center=True)
            clip_plot(d,'clip',1260,375,232,139)
        d.line('solve_to_condition',[1163,384],[1202,384],TEAL,2.5,True)
        d.math('raw_price_label',[('λ','','*')],1182,357,32,center=True,color=TEAL)
        with d.module('cost_feedback',[488,637,678,148],GT,None):
            d.txt('feedback_title','Episode-cost feedback',510,677,32,True,color=GOLD)
            d.math('feedback_equation',[('β','k',''),' ← [',('β','k',''),' + η(',('J̄','k',''),' − ',('B','k',''),')',(']','+','')],827,742,35,center=True)
        d.route('filtered_to_fusion',[[1371,599],[1371,622],[1244,622],[1244,679]],TEAL,2.3)
        d.math('filtered_price_label',[('λ̄','','*')],1290,665,33,center=True,color=TEAL)
        d.line('beta_to_fusion',[1173,711],[1212,711],GOLD,2.3,True)
        d.math('beta_label',['β'],1190,686,31,center=True,color=GOLD)
        with d.module('fusion',[1219,686,50,50],WHITE,TEAL,1.8):
            d.txt('fusion_plus','+',1244,724,36,color=TEAL,center=True)
        d.line('fusion_to_price',[1276,711],[1300,711],TEAL,2.4,True)
        d.math('unified_price',[('λ','k',''),' = ',('λ̄','k','*'),' + ',('β','k','')],1408,725,36,center=True,color=TEAL)
        d.txt('price_output_label','one price vector',1408,773,29,color=TEAL,center=True)
    with d.module('policy_update',[1610,24,367,851],WHITE,BLUE,1.7):
        header(d,'update','(c)  Policy update',1610,24,367,BLUE,33)
        with d.module('priced_advantage',[1630,119,327,312],SOFT,None):
            d.txt('advantage_title','Priced advantage',1793,160,31,True,center=True)
            d.math('advantage_symbol',['Ã ='],1793,242,39,center=True)
            fraction(d,'advantage',1793,310,35,146)
        d.line('advantage_to_ppo',[1793,438],[1793,518],BLUE,2.3,True)
        with d.module('optimizer',[1640,525,307,133],BT,None):
            d.txt('optimizer_name','PPO / TRPO',1793,577,35,True,color=BLUE,center=True)
            d.txt('optimizer_operation','policy step',1793,625,31,center=True)
        d.line('ppo_to_policy',[1793,665],[1793,716],BLUE,2.3,True)
        with d.module('updated_policy',[1707,723,173,85],WHITE,BLUE,1.5):
            d.math('new_policy',[('π','t+1','')],1793,781,44,color=BLUE,center=True)
    # The three genuinely independent consumers receive their own named inputs.
    d.line('graph_input',[420,483],[461,483],BLUE,2.2,True)
    d.route('episode_input',[[420,752],[443,752],[443,711],[461,711]],GOLD,2.2)
    d.route('price_to_update',[[1561,711],[1574,711],[1574,308],[1603,308]],TEAL,2.5)
    d.math('price_port',['λ'],1582,276,35,color=TEAL,center=True)
    d.route('gae_bypass',[[421,841],[1585,841],[1585,393],[1603,393]],BLUE,2.1)
    d.math('gae_label',['GAE: ',('A','r',''),', ',('A','c_k','')],910,884,33,color=BLUE,center=True)
    d.route('next_rollout',[[1793,882],[1793,939],[216,939],[216,883]],BLUE,1.9)
    d.txt('next_rollout_label','next rollout',1000,979,30,color=BLUE,center=True)

def write(d):
    scene={'version':1,'slide_width_inches':5.5,'slides':[{'id':'page_001','width':d.w,'height':d.h,'source':'pages/page_001/source.png','background':WHITE,'reviewed':True,'notes':'V10 modular semantic redraw of generated reference, corrected against frozen R2. All miniatures schematic; math is native grouped text/lines, not OMML.','elements':d.elements,'groups':d.groups}]}
    save(d.dest/'scene.json',scene);save(d.dest/'typography.json',d.type)
    regions=[{'id':'white','slide':'page_001','roi':[2,2,4,4],'actual_roi':[2,2,4,4],'kind':'solid','mode':'target','target_color':WHITE,'reason':'Explicit white publication background.'}]
    for color in [TEAL,GOLD,BLUE]:
        es=[e for e in d.elements if e.get('fill')==color and e['kind']=='shape']
        if es:
            e=es[0];x,y,w,h=e['box'];regions.append({'id':'target_'+color[1:],'slide':'page_001','roi':[2,2,4,4],'actual_roi':[int(x+w*.4),int(y+h*.4),3,3],'kind':'solid','mode':'target','target_color':color,'reason':'Explicit requested semantic recoloring; patch in native '+e['id']})
    save(d.dest/'appearance-plan.json',{'version':1,'regions':regions})
    save(d.dest/'redraw-changes.json',{'revision':'V10','source':f'Figure{d.number}_v01.png','mode':'semantic redesign, not faithful tracing','changes':['Strong nested module hierarchy','Uniform size tiers','Fixed semantic palette','Source-correct flow balance and episodic feedback','Independent GAE routing'],'raster_objects':0,'formula_type':'Native grouped text/lines; not OMML'})
    print(json.dumps({'scene':str(d.dest/'scene.json'),'objects':len(d.elements),'canvas':[d.w,d.h]}))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('figure',type=int);p.add_argument('--out',required=True);a=p.parse_args()
    d=Drawing(a.figure,Path(a.out));(figure1 if a.figure==1 else figure2)(d);write(d)
