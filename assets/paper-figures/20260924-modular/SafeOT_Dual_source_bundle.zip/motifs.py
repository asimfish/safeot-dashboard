"""Native semantic redraw of the inspected legacy-led generated references."""
from pathlib import Path
import argparse,json,math
from PIL import Image
from drawing import Drawing,save,INK,TEAL,GRAY,LINE,WHITE

BLUE='#536F8E';GOLD='#B78129';BT='#EDF1F6';TT='#ECF5F4';GT='#F8F1E4'

def matrix(d,id,x,y,w=110,h=65,color=TEAL,tint=TT):
    # Symbolic cost-map tiles, without measured values or a numerical color scale.
    with d.module(id):
        for r in range(3):
            for c in range(4):
                d.shape(f'{id}_{r}_{c}',[x+c*w/4,y+r*h/3,w/4-1.2,h/3-1.2],color if (r,c) in [(0,1),(1,2),(2,0)] else tint,None,shape='rect')

def panel(d,id,box,color,title,tx,ty):
    return d.module(id,box,WHITE,color,1.8)

def graph(d,id,x,y,w,h,color=TEAL):
    d.graph(id,x,y,w,h,color)
    # Native node fills add figure-ground hierarchy while leaving nodes individually editable.
    for e in d.elements:
        if e['id'] in (id+'_node2',id+'_node4',id+'_node5'):
            e['fill']=TT if color==TEAL else BT

def hard_edge(d,id,x,y):
    with d.module(id):
        d.shape(id+'_a',[x,y,24,24],WHITE,GRAY,1.8,'ellipse')
        d.shape(id+'_b',[x+140,y,24,24],WHITE,GRAY,1.8,'ellipse')
        d.line(id+'_l',[x+29,y+12],[x+61,y+12],GRAY,2)
        d.line(id+'_r',[x+103,y+12],[x+135,y+12],GRAY,2)
        d.line(id+'_x1',[x+72,y+2],[x+92,y+22],GRAY,2.6)
        d.line(id+'_x2',[x+72,y+22],[x+92,y+2],GRAY,2.6)
        d.join(id+'_x2',id+'_x1','The two strokes form a single exclusion mark on the hard-support edge.')

def prices(d,id,x,y,color=TEAL):
    with d.module(id):
        for j,k in enumerate(['1','2','…','K']):
            with d.module(id+f'_cell{j}',[x+j*64,y,62,55],TT,None):
                if k=='…':d.txt(id+'_dots','…',x+j*64+31,y+36,34,center=True,color=color)
                else:d.math(id+f'_label{j}',[('λ',k,'')],x+j*64+31,y+37,38,center=True,color=color)

