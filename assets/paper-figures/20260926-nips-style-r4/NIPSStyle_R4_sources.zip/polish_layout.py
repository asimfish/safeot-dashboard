from pathlib import Path
from pptx import Presentation
from pptx.util import Inches

ROOT = Path(__file__).resolve().parent


def remove_shape(shape):
    element = shape._element
    element.getparent().remove(element)


def dedupe(slide, name, keep="last"):
    matches = [shape for shape in slide.shapes if shape.name == name]
    if len(matches) <= 1:
        return 0
    retained = matches[-1] if keep == "last" else matches[0]
    for shape in matches:
        if shape is not retained:
            remove_shape(shape)
    return len(matches) - 1


def move_resize(shape, *, x=None, y=None, w=None, h=None):
    if x is not None:
        shape.left = Inches(x)
    if y is not None:
        shape.top = Inches(y)
    if w is not None:
        shape.width = Inches(w)
    if h is not None:
        shape.height = Inches(h)


# Figure 1: the build inherited one subtitle from R2 and added another.
path = ROOT / "Figure1_NIPSStyle_R4.pptx"
prs = Presentation(str(path))
dedupe(prs.slides[0], "safeot_center_subtitle", keep="last")
prs.save(str(path))

# Figure 2: retain the current generated labels and separate the two right-column cards.
path = ROOT / "Figure2_NIPSStyle_R4.pptx"
prs = Presentation(str(path))
slide = prs.slides[0]
for name in (
    "current_projection_eq",
    "current_price_eq",
    "current_advantage_eq",
    "current_update_eq",
    "current_safety_prices",
    "current_flow_key",
    "current_adv_key",
    "current_cost_key",
):
    dedupe(slide, name, keep="last")
for shape in slide.shapes:
    if shape.name == "current_advantage_eq":
        move_resize(shape, y=1.49, h=0.27)
    elif shape.name == "current_update_eq":
        move_resize(shape, y=1.91, h=0.27)
prs.save(str(path))
print("deduped and spaced R3 layout")
