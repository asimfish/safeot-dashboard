from pathlib import Path

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.util import Inches, Pt


ROOT = Path(__file__).resolve().parent
FONT = "Times New Roman"
ORANGE = RGBColor(232, 139, 16)
DARK = RGBColor(20, 40, 55)


def walk(shapes):
    for shape in shapes:
        yield shape
        if hasattr(shape, "shapes"):
            yield from walk(shape.shapes)


def find(prs, name):
    for slide in prs.slides:
        for shape in walk(slide.shapes):
            if shape.name == name:
                return shape
    raise KeyError(name)


def set_text(prs, name, text, size=None, color=None, bold=None):
    shape = find(prs, name)
    tf = shape.text_frame
    tf.clear()
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.CENTER
    run = p.add_run()
    run.text = text
    run.font.name = FONT
    if size is not None:
        run.font.size = Pt(size)
    if color is not None:
        run.font.color.rgb = color
    if bold is not None:
        run.font.bold = bold
    return shape


def move_resize(shape, *, x=None, y=None, w=None, h=None):
    if x is not None:
        shape.left = Inches(x)
    if y is not None:
        shape.top = Inches(y)
    if w is not None:
        shape.width = Inches(w)
    if h is not None:
        shape.height = Inches(h)


def add_text(slide, name, x, y, w, h, text, size=6.8, color=DARK, bold=False,
             fill=None, line=None):
    box = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    box.name = name
    tf = box.text_frame
    tf.clear()
    tf.word_wrap = True
    tf.margin_left = Inches(0.025)
    tf.margin_right = Inches(0.025)
    tf.margin_top = Inches(0.015)
    tf.margin_bottom = Inches(0.015)
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.CENTER
    run = p.add_run()
    run.text = text
    run.font.name = FONT
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = color
    if fill is None:
        box.fill.background()
    else:
        box.fill.solid()
        box.fill.fore_color.rgb = fill
    if line is None:
        box.line.fill.background()
    else:
        box.line.color.rgb = line
    return box


path = ROOT / "Figure2_NIPSStyle_R4.pptx"
prs = Presentation(str(path))
slide = prs.slides[0]

# One price equation belongs inside the price card. The old heading repeated it.
set_text(prs, "weights", "price fusion", size=7.0, color=ORANGE, bold=True)
move_resize(find(prs, "current_price_eq"), x=4.53, y=0.86, w=0.84, h=0.17)

# Make the priced-update band read as three deliberate steps with air between them.
move_resize(find(prs, "current_advantage_eq"), x=4.52, y=1.50, w=0.86, h=0.26)
set_text(prs, "current_update_eq", "PPO / TRPO\n→ πₜ₊₁", size=7.0, color=ORANGE, bold=True)
move_resize(find(prs, "current_update_eq"), x=4.52, y=1.88, w=0.86, h=0.29)
move_resize(find(prs, "ppo_box"), y=1.44, h=0.78)
move_resize(find(prs, "actor_down"), y=2.18, h=0.16)

# A compact observed-cost cue fills the otherwise empty gap and gives β a visible source.
add_text(slide, "observed_cost_feedback", 4.54, 1.14, 0.84, 0.12,
         "J̄ₖ − Bₖ  →  β", size=7.0, color=ORANGE, bold=True,
         fill=RGBColor(255, 247, 238), line=ORANGE)

# Keep the rollout panel balanced without adding another equation-heavy card.
add_text(slide, "observed_episode_cost", 0.16, 1.67, 0.60, 0.13,
         "observed episode cost  J̄ₖ", size=7.0, color=ORANGE, bold=False)

prs.save(str(path))
print("Figure 2 R4 layout written")
