"""V11 visual mechanisms. Native editable motifs; all quantities are schematic."""
from pathlib import Path
import argparse,json,math
from drawing import Drawing,save,INK,TEAL,GRAY,LINE,WHITE
from motifs import matrix,hard_edge,BLUE,GOLD,BT,TT,GT

PALE='#F2F7F7'

def label(d,id,s,x,y,size=33,color=INK,bold=False,center=False):
    return d.txt(id,s,x,y,size,bold,color=color,center=center)

def token(d,id,x,y,text,color=TEAL,fill=TT,r=25,size=36):
    with d.module(id,[x-r,y-r,2*r,2*r],fill,color,1.5):
        next(e for e in d.elements if e['id']==id+'_panel')['shape']='ellipse'
        if text:d.txt(id+'_label',text,x,y+size*.30,size,center=True,color=color)

def box(d,id,x,y,w,h,text,color=INK,fill=WHITE,size=33,stroke=None):
    with d.module(id,[x,y,w,h],fill,stroke,1.5):
        label(d,id+'_label',text,x+w/2,y+h/2+size*.30,size,color,center=True)

def graph(d,id,x,y,w,h):
    """One schematic empirical graph, with channel annotations and excluded edge."""
    coords=[(0,.48),(.27,0),(.70,0),(1,.48),(.45,.48),(.15,1),(.62,1),(1,1)]
    nodes=[(x+a*w,y+b*h) for a,b in coords];rad=22
    edges=[(0,1),(1,2),(2,3),(0,4),(1,4),(4,3),(0,5),(5,6),(6,7),(7,3)]
    with d.module(id):
        for j,(a,b) in enumerate(edges):
            a,b=nodes[a],nodes[b];dist=math.dist(a,b);v=[(b[k]-a[k])/dist for k in (0,1)]
            d.line(id+f'_edge{j}',[a[k]+(rad+5)*v[k] for k in (0,1)],[b[k]-(rad+5)*v[k] for k in (0,1)],TEAL if j in (0,1,2,5) else GRAY,2.8 if j in (0,1,2,5) else 2.1,True)
        for j,(a,b) in enumerate(nodes):d.shape(id+f'_node{j}',[a-rad,b-rad,2*rad,2*rad],TT if j in (1,3,4) else WHITE,TEAL,1.9,'ellipse')
        # Hard edge is explicitly excluded; its broken geometry leaves room for X.
        a,b=nodes[4],nodes[6];dist=math.dist(a,b);v=[(b[k]-a[k])/dist for k in (0,1)];mid=[(a[k]+b[k])/2 for k in (0,1)]
        d.line(id+'_hard_a',[a[k]+(rad+5)*v[k] for k in (0,1)],[mid[k]-18*v[k] for k in (0,1)],GRAY,1.9,dash=[5,5])
        d.line(id+'_hard_b',[mid[k]+18*v[k] for k in (0,1)],[b[k]-(rad+5)*v[k] for k in (0,1)],GRAY,1.9,dash=[5,5])
        d.line(id+'_cross1',[mid[0]-10,mid[1]-10],[mid[0]+10,mid[1]+10],GOLD,3)
        d.line(id+'_cross2',[mid[0]-10,mid[1]+10],[mid[0]+10,mid[1]-10],GOLD,3)
        d.join(id+'_cross2',id+'_cross1','A single hard-edge exclusion mark formed by two crossing strokes.')
        for j,xx,yy in [(1,x+w*.10,y+h*.14),(2,x+w*.90,y+h*.14),(3,x+w*.35,y+h*.95)]:
            d.math(id+f'_cost{j}',[('c',str(j),'')],xx,yy,34,color=GOLD,center=True)

def tracks(d,id,x,y,w,mode='weights'):
    color=BLUE if mode=='weights' else GOLD;tint=BT if mode=='weights' else GT
    with d.module(id):
        for j,f in enumerate([.42,.68,.30]):
            yy=y+j*47
            d.math(id+f'_c{j}',[('c',str(j+1),'')],x-34,yy+10,32,color=color,center=True)
            d.shape(id+f'_track{j}',[x,yy-5,w,10],tint,None)
            d.shape(id+f'_fill{j}',[x,yy-5,w*f,10],color,None)
            # Inset foreground fill intentionally shares a track footprint.
            d.join(id+f'_fill{j}',id+f'_track{j}','The track fill is an intentional symbolic overlay, not a measured value.')
            if mode=='weights':
                d.shape(id+f'_knob{j}',[x+w*f-9,yy-9,18,18],WHITE,color,2,'ellipse')
                for k in ('track','fill'):d.join(id+f'_knob{j}',id+f'_{k}{j}','The knob is the symbolic weight setting on its track.')
            else:
                d.line(id+f'_limit{j}',[x+w*.78,yy-12],[x+w*.78,yy+12],color,2.2)
                d.join(id+f'_limit{j}',id+f'_track{j}','A budget tick marks the limit on its schematic track.')

def figure1(d):
    # Two lightweight views bind to one broad construction instead of parallel algorithms.
    with d.module('penalty_view'):
        label(d,'penalty_title','Penalty view',265,64,36,BLUE,True,True)
        tracks(d,'penalty_weights',149,111,243)
        label(d,'penalty_settings','Fixed / adaptive weights',265,250,32,BLUE,center=True)
        label(d,'zero_cap_note','Zero graph-price cap',265,293,31.5,GRAY,center=True)
    with d.module('constraint_view'):
        label(d,'constraint_title','Constraint view',1735,64,36,GOLD,True,True)
        tracks(d,'joint_budget_view',1619,111,243,'budgets')
        label(d,'constraint_budgets','Joint cost budgets',1735,250,32,GOLD,center=True)
        label(d,'conditional_limits','Conditional price limits',1735,293,31.5,GRAY,center=True)
    label(d,'title','SafeOT-Dual',1000,98,45,TEAL,True,True)
    label(d,'subtitle','One price rule, two views',1000,153,35,INK,center=True)
    # Non-arrow leaders are conceptual relationships, not data paths.
    d.route('left_view_relation',[[458,156],[534,156],[534,319]],BLUE,1.6,False)
    d.route('right_view_relation',[[1542,156],[1466,156],[1466,319]],GOLD,1.6,False)
    with d.module('shared_construction',[54,329,1892,605],PALE,LINE,1.4):
        next(e for e in d.elements if e['id']=='shared_construction_panel')['radius']=34*d.scale
        label(d,'encode_title','Encode jointly',280,386,35,INK,True,True)
        label(d,'graph_title','Price on one graph',890,386,35,TEAL,True,True)
        label(d,'combine_title','Combine prices',1584,386,35,INK,True,True)
        with d.module('cost_maps'):
            for j,k in enumerate(['1','2','3']):
                y=439+j*93
                matrix(d,'cost_map'+k,166,y,145,63,GOLD,GT)
                d.math('cost_map_label'+k,[('C',k,'')],354,y+43,36,color=GOLD,center=True)
            label(d,'shared_states','Shared state space',280,761,32,GRAY,center=True)
        graph(d,'priced_graph',648,463,469,229)
        label(d,'graph_constraints','Budgets + flow balance',890,767,32,TEAL,center=True)
        label(d,'graph_hard','×  excluded graph edge',890,811,31.5,GRAY,center=True)
        d.line('maps_to_graph',[452,574],[599,574],TEAL,2.7,True)
        d.line('graph_to_prices',[1173,574],[1299,574],TEAL,2.7,True)
        with d.module('price_combination'):
            for txt,x in [('Graph',1400),('Feedback',1550),('Shared',1755)]:label(d,'price_head_'+txt,txt,x,447,32,TEAL if txt!='Feedback' else GOLD,center=True)
            for j in range(3):
                y=496+j*94
                token(d,f'graph_price{j}',1400,y,'',TEAL,TT,23)
                token(d,f'feedback_price{j}',1550,y,'',GOLD,GT,23)
                label(d,f'plus{j}','+',1475,y+11,36,INK,center=True)
                d.line(f'total_arrow{j}',[1590,y],[1676,y],TEAL,2.2,True)
                token(d,f'total_price{j}',1720,y,['λ₁','λ₂','λ₃'][j],TEAL,WHITE,27,34)
            d.route('price_vector_bracket',[[1785,478],[1811,478],[1811,703],[1785,703]],TEAL,1.9,False)
        d.route('shared_prices_to_actor',[[1811,726],[1811,787],[1638,787],[1638,820]],TEAL,2.3)
        with d.module('shared_policy_update'):
            label(d,'common_update','One policy update',332,877,36,TEAL,True,True)
            label(d,'reward_cost_label','Reward + cost advantages',873,878,33,BLUE,center=True)
            d.line('advantages_to_actor',[1180,865],[1539,865],BLUE,2.3,True)
            token(d,'policy',1597,865,'π',BLUE,WHITE,37,48)
            label(d,'ppo','PPO / TRPO',1782,876,34,BLUE,True,True)
    label(d,'schematic','Schematic',77,987,31.5,GRAY)
    label(d,'safety_scope','Graph feasibility does not certify policy safety',1923,987,31.5,GRAY,center=False)
    # Right-align the scope label with measured width, rather than shrinking it.
    e=next(e for e in d.elements if e['id']=='safety_scope');e['box'][0]=(1923*d.scale)-e['box'][2]

def figure2(d):
    label(d,'observe_title','Observe',198,70,38,BLUE,True,True)
    label(d,'update_title','Update policy',1785,70,38,BLUE,True,True)
    with d.module('rollout_inputs'):
        label(d,'rollout_label','Policy rollout',198,154,33,INK,True,True)
        for j in range(4):
            x=68+j*85
            token(d,f'rollout_state{j}',x,210,'',BLUE,BT,18)
            if j<3:d.line(f'rollout_link{j}',[x+24,210],[x+61,210],BLUE,2.1,True)
        for j,(txt,col,tint) in enumerate([('states',BLUE,BT),('rewards',BLUE,BT),('costs',GOLD,GT)]):
            y=298+j*65;label(d,'data_'+txt,txt,35,y+12,32,col)
            for k in range(4):d.shape(f'data_{j}_{k}',[190+k*41,y-9,24,24],tint,col,1.2,shape='rect')
        label(d,'episodic_label','Episode costs',194,606,33,GOLD,center=True)
        token(d,'observed_cost',194,665,'J̄',GOLD,GT,34,37)
        label(d,'gae_label','GAE advantages',194,836,32,BLUE,True,True)
    with d.module('shared_prices',[439,24,1107,770],PALE,LINE,1.4):
        next(e for e in d.elements if e['id']=='shared_prices_panel')['radius']=30*d.scale
        label(d,'core_title','Construct shared prices',469,78,38,TEAL,True)
        with d.module('joint_graph'):
            label(d,'joint_graph_title','Joint graph',734,149,33,INK,True,True)
            graph(d,'empirical_graph',498,208,428,224)
            label(d,'solve_label','Solve jointly',725,491,33,TEAL,True,True)
            label(d,'balance_budgets','Balance · per-step budgets',725,538,31.5,INK,center=True)
            label(d,'solver_note','Newton / bisection',725,578,31.5,GRAY,center=True)
            label(d,'hard_legend','×  hard graph support',1163,570,31.5,GRAY,center=True)
        d.line('graph_to_condition',[957,315],[1032,315],TEAL,2.4,True)
        label(d,'raw_price_label','λ*',995,285,35,TEAL,center=True)
        with d.module('condition_prices'):
            label(d,'condition_title','Clip + smooth',1275,149,33,INK,True,True)
            d.line('clip_x',[1082,367],[1341,367],GRAY,1.6,True)
            d.line('clip_y',[1082,367],[1082,213],GRAY,1.6,True)
            d.join('clip_y','clip_x','Analytic transfer response axes share the origin.')
            d.route('clip_response',[[1089,361],[1247,252],[1319,252]],TEAL,3.0,False)
            d.line('clip_cap_mark',[1088,252],[1233,252],GOLD,1.5,dash=[6,5])
            label(d,'cap_label','cap',1130,226,31.5,GOLD,center=True)
            d.line('condition_output',[1353,309],[1391,309],TEAL,2.1,True)
            for j in range(3):token(d,f'filtered_price{j}',1433,230+j*80,'',TEAL,TT,22)
            label(d,'filtered_label','Filtered',1433,458,31.5,TEAL,center=True)
            label(d,'filtered_label2','prices',1433,497,31.5,TEAL,center=True)
        with d.module('cost_feedback'):
            label(d,'feedback_title','Episode-cost feedback',477,644,33,GOLD,True)
            token(d,'feedback_budget',516,714,'B',GOLD,GT,24,33)
            d.line('budget_to_error',[550,714],[594,714],GOLD,2,True)
            token(d,'error',632,714,'−',GOLD,WHITE,25,36)
            d.line('error_to_feedback',[667,714],[778,714],GOLD,2.1,True)
            label(d,'cost_error_label','cost − budget',635,777,31.5,GRAY,center=True)
            box(d,'accumulate',794,679,232,71,'Accumulate',GOLD,GT,32)
            d.route('feedback_memory',[[986,755],[986,772],[833,772],[833,755]],GOLD,1.6,True)
            d.line('feedback_to_price',[1036,714],[1359,714],GOLD,2.3,True)
            label(d,'feedback_beta','β',1180,693,36,GOLD,center=True)
        d.route('conditioned_to_sum',[[1490,380],[1511,380],[1511,647],[1413,647],[1413,677]],TEAL,2.3)
        token(d,'price_sum',1413,714,'+',TEAL,WHITE,27,38)
        d.line('sum_to_output',[1450,714],[1495,714],TEAL,2.3,True)
    # Three true independent data consumers, with no artificial serial relay.
    d.line('rollout_to_graph',[359,210],[428,210],BLUE,2.3,True)
    label(d,'transition_label','transitions',198,263,31.5,BLUE,center=True)
    d.route('episode_cost_path',[[235,665],[413,665],[632,665],[632,679]],GOLD,2.1)
    d.join('episode_cost_path_1','shared_prices_panel','The episode-cost input crosses the core boundary to its explicit feedback comparator port.')
    d.join('episode_cost_path_2','shared_prices_panel','The input arrow ends at the comparator inside the core.')
    # Policy operation drawn as signed ribbons, cost weighting and normalization.
    with d.module('policy_update'):
        label(d,'reward_adv_label','Reward advantage',1784,154,31.5,BLUE,center=True)
        with d.module('reward_adv',[1694,181,178,51],BT,None):
            d.math('reward_adv_symbol',[('A','r','')],1783,217,35,center=True,color=BLUE)
        label(d,'cost_adv_label','Cost advantages',1784,288,31.5,GOLD,center=True)
        with d.module('cost_adv',[1694,314,178,51],GT,None):
            d.math('cost_adv_symbol',[('A','c','')],1783,350,35,center=True,color=GOLD)
        token(d,'weight_gate',1784,456,'×',GOLD,WHITE,27,36)
        d.line('cost_to_weight',[1784,372],[1784,422],GOLD,2.2,True)
        d.route('reward_to_combiner',[[1883,207],[1936,207],[1936,554],[1854,554]],BLUE,2.2)
        label(d,'reward_plus','+',1893,532,32,BLUE,center=True)
        token(d,'signed_sum',1818,554,'−',INK,WHITE,27,36)
        d.route('weight_to_combiner',[[1784,492],[1818,492],[1818,517]],GOLD,2.2,True)
        d.line('mix_to_normalize',[1818,590],[1818,620],BLUE,2.1,True)
        box(d,'normalize',1686,628,264,60,'Normalize',BLUE,BT,33)
        d.line('normalize_to_ppo',[1818,696],[1818,735],BLUE,2.1,True)
        box(d,'ppo',1686,743,264,64,'PPO / TRPO',BLUE,WHITE,34,BLUE)
        d.line('ppo_to_policy',[1818,814],[1818,844],BLUE,2.1,True)
        token(d,'new_policy',1818,885,'π',BLUE,BT,33,44)
    d.route('price_to_weight',[[1555,714],[1610,714],[1610,456],[1748,456]],TEAL,2.5)
    label(d,'shared_price_label','Shared',1676,404,31.5,TEAL,center=True)
    label(d,'shared_price_label2','prices',1676,441,31.5,TEAL,center=True)
    # Dedicated GAE corridor forks before the update and enters advantage inputs only.
    d.route('gae_lower',[[358,847],[1571,847],[1571,726]],BLUE,1.9,False)
    # An underpass gap makes the independent blue GAE line cross the teal price
    # output without suggesting a merge. The only GAE fork is at the two inputs.
    d.route('gae_to_inputs',[[1571,702],[1571,104],[1653,104],[1653,207],[1684,207]],BLUE,1.9)
    d.route('gae_cost_fork',[[1653,207],[1653,339],[1684,339]],BLUE,1.9)
    d.join('gae_cost_fork_0','gae_to_inputs_2','The GAE branch shares its upstream segment before splitting to reward and cost inputs.')
    d.join('gae_cost_fork_0','gae_to_inputs_3','The reward/cost advantage inputs share a single GAE fork.')
    d.route('next_rollout',[[1818,925],[1818,962],[20,962],[20,210],[38,210]],BLUE,1.8)
    label(d,'next_rollout_label','next rollout',1000,946,31.5,BLUE,center=True)
    label(d,'schematic_note','Schematic',42,925,31.5,GRAY)

def write(d):
    scene={'version':1,'slide_width_inches':5.5,'slides':[{'id':'page_001','width':d.w,'height':d.h,'source':'pages/page_001/source.png','background':WHITE,'reviewed':True,'notes':'V11 visual mechanism redraw of generated reference. Schematic only. Full equations in companion captions. Frozen R2 science; no policy-safety guarantee.','elements':d.elements,'groups':d.groups}]}
    save(d.dest/'scene.json',scene);save(d.dest/'typography.json',d.type)
    save(d.dest/'appearance-plan.json',{'version':1,'regions':[{'id':'white','slide':'page_001','roi':[2,2,4,4],'actual_roi':[2,2,4,4],'kind':'solid','mode':'target','target_color':WHITE,'reason':'Opaque white publication ground replaces generated transparency.'}]})
    save(d.dest/'redraw-changes.json',{'mode':'semantic redesign','source':f'Figure{d.number}_v01.png','changes':['Zero displayed objective/update equations','Visual constrained graph, price fusion and signed advantage combination','Correct price labels and GAE ports','White ground and fixed blue/teal/ochre meanings'],'omitted_visible_details':'Full optimization/filter/feedback/advantage formulas moved to captions and manuscript.','raster_objects':0})
    print(json.dumps({'scene':str(d.dest/'scene.json'),'objects':len(d.elements)}))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('figure',type=int);p.add_argument('--out',required=True);a=p.parse_args()
    d=Drawing(a.figure,Path(a.out));(figure1 if a.figure==1 else figure2)(d);write(d)
