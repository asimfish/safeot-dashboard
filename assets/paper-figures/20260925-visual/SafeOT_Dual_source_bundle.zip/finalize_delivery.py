"""Package V11 after inspecting native renders and the isolated paper placement."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,json,re,shutil
import fitz
from assemble import SELECTED
R=Path(__file__).resolve().parent;ROOT=R.parents[1];D=R/'delivery';Q=R/'outputs/qa';P=R/'paper-preview'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def main():
 assert not (D/'manifest.json').exists(), 'Already packaged; inspect instead of overwriting.'
 doc=fitz.open(P/'main.pdf');refs=[i+1 for i,p in enumerate(doc) if re.search(r'(?m)^REFERENCES\s*$',p.get_text())]
 assert len(doc)==57 and refs[0]==10
 issues=[s for s in (P/'main.log').read_text().splitlines() if re.search(r'Overfull|undefined|multiply defined|^!|LaTeX Error',s)];assert not issues
 fonts={f[0]:f for p in doc for f in p.get_fonts(full=True)};assert all(doc.extract_font(x)[3] for x in fonts)
 before=json.loads((Q/'paper-preview-provenance.json').read_text());assert sha(ROOT/'iclr_2027_v2/main.pdf')==before['canonical_main_pdf_sha256_before']
 aux=(P/'main.aux').read_text();pages={}
 for i,name in enumerate(['concept','method'],1):
  m=re.search(r'\\newlabel\{fig:safeot-dual-'+name+r'\}\{\{\d+\}\{(\d+)\}',aux);assert m
  pages[i]=int(m.group(1));doc[pages[i]-1].get_pixmap(matrix=fitz.Matrix(1.6,1.6)).save(Q/f'paper_figure{i}_page.png')
 excerpt=fitz.open()
 for page in pages.values():excerpt.insert_pdf(doc,from_page=page-1,to_page=page-1)
 excerpt.save(D/'ICLR2027_figure_placement.pdf')
 native=json.loads((Q/'native-verification.json').read_text());count=sum(f['native_leaves'] for f in native['figures'])
 report={'status':'PASS','base':'Frozen author-referenced R2','pages':len(doc),'main_text_pages':refs[0]-1,'references_start_page':refs[0],
  'figure_pages':pages,'latex_issues':issues,'pdf_fonts_embedded':True,'canonical_main_unchanged':True,'width_fraction':.98,
  'min_ordinary_label_pt':{f'Figure{f["figure"]}':f['min_ordinary_label_pt_at_5_5in']*.98 for f in native['figures']},
  'scope':'Isolated R2 figure placement; not full submission clearance. Canonical and concurrently edited manuscripts remain separate.'}
 save(Q/'paper-placement.json',report)
 (D/'README.md').write_text(f'''# SafeOT-Dual — V11 visual mechanism revision (2026-09-25)

The author found V10 cluttered and formula-heavy. V11 replaces displayed objectives
and update equations with visible operations: encode joint costs, price one graph,
condition its prices, combine cost feedback, and update one policy. Full equations
remain in the manuscript and companion captions.

Figure1 connects penalty and constraint views to a single shared construction.
Cost-map tiles feed one graph; conditioned graph prices and feedback combine into
a shared price vector for the same policy update. The two upper leaders are
conceptual relationships, not separate algorithm branches. Zero-cap settings are
exact; conditional graph-price limits do not recover CPO.

Figure2 follows Observe → Construct shared prices → Update policy. The graph solve
and cost-feedback branch are inside one core. Clipping is shown as an analytic
response. GAE independently supplies reward and cost advantages. Prices weight
the cost advantages; reward minus weighted cost is normalized before PPO/TRPO.
The outer loop returns to rollout. A gap at the blue/teal line crossing means an
underpass, not a junction. Only prices pass from the graph to the actor.

Blue means policy/observation, teal means graph/shared prices, ochre means costs
and feedback. All motifs are schematic; no experimental measurements are depicted.
Three illustrated channels represent an arbitrary number of costs. The graph's
balance is discounted. Graph budgets are per-step B_k/L, feedback uses episodic B_k.
Hard graph exclusion and a finite hard-channel policy penalty do not certify
policy support or deployed-policy safety.

The two delivered figures contain {count} native leaf objects, no raster artwork.
PNG previews are actual LibreOffice renders of the PPTX. Labels, mathematical
symbols, nodes and connectors are editable; mathematical symbols are grouped
text/lines, not Office Math. Moving a group does not auto-reroute external arrows.
Use Liberation Sans and Liberation Serif when editing. Fonts are embedded in PDF,
not in the PPTX. PowerPoint/WPS rendering was not independently checked.

Geometry, native objects, actual-render text/fonts and the opaque white target-fill
checks pass. Duplicate-file group movement and label editing were verified. The
smallest ordinary label is about 6.24 pt at 5.5 inches / 6.11 pt at the checked paper
width; mathematical subscripts are smaller. The isolated paper preview retains
9 main / 57 total pages, with embedded fonts and zero overfull or unresolved
reference diagnostics. ICLR2027_figure_placement.pdf contains the two figure pages.
This checks figure placement, not all current venue submission requirements.

SuperTeaser's visual mechanism/composition guidance and built-in image generation
were used for proposals. Provider model ID was not exposed. SuperImg2PPT 0.3.15
was used for native semantic reconstruction, not pixel-faithful tracing. Generated
proposals are preserved as unadopted history; their price/GAE labels and connections
are corrected in the native version. No borrowed paper artwork is included.

V00–V10 and all dated assets are retained. V11 remains a comparison candidate on the
same frozen R2 method; canonical main.pdf and active writing revisions are unchanged.
''')
 (D/'captions.tex').write_text(r'''% Proposed expanded captions; full mathematics belongs in the paper, not the image.
\textbf{One algorithm connects penalty and constraint views.} Multiple cost maps
share one empirical state graph. SafeOT-Dual solves for graph prices, clips and
filters them, then adds realized-cost feedback to obtain coefficients for one
policy update. The graph column denotes conditioned prices, not raw dual prices.
With a zero graph-price cap, fixed or adaptive feedback recovers the corresponding
fixed-penalty or Lagrangian setting. Constraint-side graph-price limits require
the assumptions in the pricing section and retain clipping and feedback; they do
not recover an external method such as CPO. Three channels and all track values
are schematic. Graph feasibility does not certify deployed-policy safety.

\textbf{From observations to a shared priced update.} Rollouts provide the empirical
graph, reward and cost GAE advantages, and episode costs. The graph solve jointly
uses discounted flow balance, entropy regularization, soft budgets $b_k=B_k/L$,
and hard support exclusions. Damped Newton in $u$ and coordinate bisection in
$\lambda$ yield $\lambda^\star$. Clipping and filtering produce
$\bar\lambda^\star_k\leftarrow(1-\alpha)\bar\lambda^\star_k+
\alpha\min(\lambda^\star_k,\bar\lambda_{\max})$; the cost-feedback branch uses
$\beta_k\leftarrow[\beta_k+\eta(\bar J_k-B_k)]_+$. These combine as
$\lambda_k=\bar\lambda^\star_k+\beta_k$. The multiplication gate denotes the
weighted sum $\sum_k\lambda_k A_{c_k}$; reward advantage minus this term is
normalized by $1+\sum_k\lambda_k$ before the PPO/TRPO step. GAE reaches the two
advantage inputs independently; the gapped blue crossing is not a price junction.
Only prices pass from the graph to the actor. Hard graph support is excluded;
the finite on-policy hard-channel penalty does not enforce policy support. The
updated policy supplies the next rollout. The off-policy executor is not shown.
''')
 for n in ['native-verification.json','paper-placement.json']:shutil.copy2(Q/n,D/n)
 bundle=D/'SafeOT_Dual_source_bundle.zip'
 with ZipFile(bundle,'x',compression=ZIP_DEFLATED,compresslevel=6) as z:
  for n in ['author.py','drawing.py','motifs.py','assemble.py','finalize_delivery.py']:z.write(R/n,n)
  for n in ['README.md','captions.tex']:z.write(D/n,n)
  for n in ['brief.json','semantic-audit.json']:z.write(R/'state'/n,'state/'+n)
  for folder in ['outputs/prompts','outputs/generated']:
   for p in (R/folder).rglob('*'):
    if p.is_file():z.write(p,p.relative_to(R))
  for name in SELECTED:
   job=R/'outputs/native'/name
   for p in job.rglob('*'):
    if p.is_file() and 'build_01' not in p.parts:z.write(p,p.relative_to(R))
   for name2 in ['validation.json','editability.json','fonts.json','scene.resolved.json']:
    p=job/'build_01'/name2;z.write(p,p.relative_to(R))
 with ZipFile(bundle) as z:assert z.testzip() is None
 save(D/'manifest.json',{'task':'T-FIGURE-VISUAL-20260925','version':'20260925-visual','status':'author comparison candidate',
  'source_reference':'Frozen R2 price-based science underlying V06–V10','native_objects':count,'visible_rasters':0,
  'files':[{'name':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(D.iterdir()) if p.is_file()],
  'historical_retention':'All previous versions and generated attempts retained.'})
 print(json.dumps(report,indent=2))
if __name__=='__main__':main()
