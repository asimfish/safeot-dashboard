from pathlib import Path
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE

ROOT=Path(__file__).resolve().parent
PPT=ROOT/'Figure2_NIPSStyle_R5.pptx'
DARK=RGBColor(20,40,55); BLUE=RGBColor(24,24,230); GREEN=RGBColor(18,85,41); ORANGE=RGBColor(232,139,16); PURPLE=RGBColor(80,40,130); GRAY=RGBColor(90,90,90); RED=RGBColor(190,35,35)
PALE_GREEN=RGBColor(242,250,244); PALE_ORANGE=RGBColor(255,247,238); PALE_GRAY=RGBColor(248,249,250)

def walk(shapes):
    for sh in list(shapes):
        yield sh
        if hasattr(sh,'shapes'):
            yield from walk(sh.shapes)

def find(prs,name):
    for sl in prs.slides:
        for sh in walk(sl.shapes):
            if sh.name==name:return sh
    raise KeyError(name)

def delete(prs,names=(),prefixes=()):
    names=set(names); prefixes=tuple(prefixes)
    for sl in prs.slides:
        def rec(container):
            for sh in list(container):
                if sh.name in names or any(sh.name.startswith(p) for p in prefixes):
                    sh._element.getparent().remove(sh._element); continue
                if hasattr(sh,'shapes'): rec(sh.shapes)
        rec(sl.shapes)

def move(sh,x=None,y=None,w=None,h=None):
    for a,v in [('left',x),('top',y),('width',w),('height',h)]:
        if v is not None:setattr(sh,a,Inches(v))

def set_text(prs,name,text,size=7.5,color=DARK,bold=False,align=PP_ALIGN.CENTER):
    sh=find(prs,name); tf=sh.text_frame; tf.clear(); tf.word_wrap=False
    tf.margin_left=tf.margin_right=Inches(0.01); tf.margin_top=tf.margin_bottom=Inches(0.01); tf.vertical_anchor=MSO_ANCHOR.MIDDLE
    for i,line in enumerate(text.split('\n')):
        p=tf.paragraphs[0] if i==0 else tf.add_paragraph(); p.alignment=align; p.space_before=Pt(0); p.space_after=Pt(0)
        r=p.add_run(); r.text=line; r.font.name='Times New Roman'; r.font.size=Pt(size); r.font.bold=bold; r.font.color.rgb=color
    return sh

def add_text(sl,name,x,y,w,h,text,size=7.5,color=DARK,bold=False,fill=None,line=None,align=PP_ALIGN.CENTER):
    box=sl.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h)); box.name=name
    tf=box.text_frame; tf.clear(); tf.word_wrap=False; tf.margin_left=tf.margin_right=Inches(0.01); tf.margin_top=tf.margin_bottom=Inches(0.01); tf.vertical_anchor=MSO_ANCHOR.MIDDLE
    for i,line_text in enumerate(text.split('\n')):
        p=tf.paragraphs[0] if i==0 else tf.add_paragraph(); p.alignment=align; p.space_before=Pt(0); p.space_after=Pt(0)
        r=p.add_run(); r.text=line_text; r.font.name='Times New Roman'; r.font.size=Pt(size); r.font.bold=bold; r.font.color.rgb=color
    if fill is None: box.fill.background()
    else: box.fill.solid(); box.fill.fore_color.rgb=fill
    if line is None: box.line.fill.background()
    else: box.line.color.rgb=line; box.line.width=Pt(0.6)
    return box

def add_card(sl,name,x,y,w,h,fill,line):
    sh=sl.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE,Inches(x),Inches(y),Inches(w),Inches(h)); sh.name=name
    sh.fill.solid(); sh.fill.fore_color.rgb=fill; sh.line.color.rgb=line; sh.line.width=Pt(0.7)
    return sh

prs=Presentation(str(PPT)); sl=prs.slides[0]
# Stage headings become short and aligned, with the same original five-column rhythm.
set_text(prs,'title3','Constraints',8.6,GREEN,True)
set_text(prs,'title4','Flow projection',9.0,GREEN,True)
set_text(prs,'title5','Priced actor',8.6,ORANGE,True)
set_text(prs,'weights','prices + feedback',7.0,ORANGE,True)

# Stage 3: remove stale capacity-composition matrices; show only the two constraints needed by the method.
delete(prs, prefixes=('capmini','cap_label','compose','composed_','capellipsis','brace_'), names=('one_matrix','composed_S'))
# Existing composebox may not be removed by prefix (it is included); ensure it is gone.
delete(prs,names=('composebox',))
add_card(sl,'soft_constraint_card',2.19,0.84,0.74,0.72,PALE_GREEN,GREEN)
add_text(sl,'soft_constraint_label',2.22,0.90,0.68,0.15,'SOFT',7.1,GREEN,True)
add_text(sl,'soft_constraint_eq',2.21,1.08,0.70,0.22,'⟨Cₖ,F⟩ ≤ bₖ\nbₖ = Bₖ / L',7.3,GREEN,False)
add_card(sl,'hard_constraint_card',2.19,1.78,0.74,0.57,PALE_GRAY,GREEN)
add_text(sl,'hard_constraint_label',2.22,1.83,0.68,0.15,'HARD',7.1,RED,True)
add_text(sl,'hard_constraint_eq',2.21,2.03,0.70,0.20,'F_H = 0\n(excluded edges)',7.2,RED,False)
add_text(sl,'constraint_note',2.20,2.48,0.70,0.16,'limits for F★',7.0,GRAY,False)

# Stage 4: the projection is a single idea. Delete solver internals and the old kernel equation.
delete(prs,names=('projection_formula_box','iterations','iter_row','iter_col','iter_projected','repeat','repeat_label','certbox','kernel','current_projection_eq','current_safety_prices'))
# Retain the original green panel and matrix motif; add a clean projection card and an uncluttered output card.
add_card(sl,'projection_card',3.18,0.70,1.08,0.37,PALE_GREEN,GREEN)
add_text(sl,'projection_formula',3.21,0.75,1.02,0.24,'F̂  →  F★',11.0,GREEN,True)
add_text(sl,'projection_caption',3.20,1.10,1.04,0.14,'entropic projection',7.3,GREEN,True)
# Rename the existing chain labels and give each one a separate lane.
delete(prs,names=('iter_row','iter_col','iter_projected','ppo_label'))
# One glyph per lane: the visual matrices carry the transformation, so no long labels can collide.
add_text(sl,'flow_observed',3.17,1.27,0.18,0.15,'F̂',8.0,GREEN,True)
add_text(sl,'flow_reroute',3.68,1.27,0.18,0.15,'→',8.0,GREEN,True)
add_text(sl,'flow_target',4.13,1.27,0.20,0.15,'F★',8.0,GREEN,True)
# Place labels below the matrices rather than through the arrows.
add_text(sl,'projection_note',3.24,2.05,0.98,0.16,'target flow; policy executes π',7.0,GRAY,False)
add_card(sl,'price_output_card',3.25,2.37,0.96,0.32,PALE_GREEN,GREEN)
add_text(sl,'price_output',3.28,2.42,0.90,0.21,'safety prices  λ̄ₖ★',7.4,GREEN,True)
# The old kernel outline was a detached formula; removing it is the key overlap fix.

# Stage 5: keep three equations, each in its own card with enough vertical separation.
delete(prs,names=('current_price_eq','current_advantage_eq','current_update_eq','observed_cost_feedback'))
# Existing containers are retained but resized into three independent bands.
move(find(prs,'weight_box'),x=4.50,y=0.76,w=0.92,h=0.38)
move(find(prs,'ppo_box'),x=4.48,y=1.48,w=0.94,h=0.78)
# Formula 1: graph price plus realized-cost feedback.
add_text(sl,'price_fusion_eq',4.54,0.81,0.84,0.18,'λₖ = λ̄ₖ★ + βₖ',7.8,ORANGE,True,fill=PALE_ORANGE,line=ORANGE)
add_text(sl,'feedback_eq',4.52,1.19,0.88,0.18,'βₖ ← [βₖ + α eₖ]₊',7.1,ORANGE,True,fill=PALE_ORANGE,line=ORANGE)
add_text(sl,'feedback_def',4.55,1.38,0.82,0.11,'eₖ = J̄ₖ − Bₖ',7.0,ORANGE,False)
# Formula 2: full priced advantage, split over two lines for clean typesetting.
add_text(sl,'advantage_eq',4.52,1.55,0.86,0.37,'Ã = (Aᵣ − Σₖ λₖA𝚌ₖ)\n      / (1 + Σₖ λₖ)',7.0,ORANGE,True,fill=PALE_ORANGE,line=ORANGE)
add_text(sl,'actor_update',4.53,1.97,0.84,0.21,'PPO / TRPO → πₜ₊₁',7.0,ORANGE,True,fill=PALE_ORANGE,line=ORANGE)
# Leave the actor pictogram as the visual endpoint; remove excess bottom whitespace by adding a small endpoint tag.
add_text(sl,'actor_tag',4.72,2.73,0.58,0.11,'next policy',7.0,ORANGE,False)

# Stage 2 labels explicitly identify the three input tensors without colliding with the matrices.
add_text(sl,'flow_input_label_r5',1.40,1.86,0.48,0.14,'flow  F̂',7.0,BLUE,True)
add_text(sl,'adv_input_label_r5',1.40,2.19,0.48,0.14,'adv.  A',7.0,PURPLE,True)
add_text(sl,'cost_input_label_r5',1.40,2.52,0.48,0.14,'cost  Cₖ',7.0,GREEN,True)
delete(prs,names=('current_flow_key','current_adv_key','current_cost_key'))

# Ensure title and stage borders remain intact; update metadata on the source package later.
prs.core_properties.author=''; prs.core_properties.last_modified_by=''; prs.core_properties.title='SafeOT Figure 2'; prs.core_properties.subject='Method framework'; prs.core_properties.comments=''
prs.save(str(PPT))
print(PPT)
