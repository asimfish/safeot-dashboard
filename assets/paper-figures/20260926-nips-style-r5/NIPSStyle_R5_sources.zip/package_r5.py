from pathlib import Path
import hashlib,json,zipfile,shutil
from PIL import Image,ImageOps
from pptx import Presentation
import fitz
from pypdf import PdfReader,PdfWriter
ROOT=Path(__file__).resolve().parent
RENDER=ROOT/'render'; RENDER.mkdir(exist_ok=True)
# Rendered input is created by LibreOffice; strip metadata for the delivered PDF.
raw=RENDER/'Figure2_NIPSStyle_R5.pdf'
rd=PdfReader(str(raw)); wr=PdfWriter(); [wr.add_page(p) for p in rd.pages]
wr.add_metadata({'/Title':'Figure 2 SafeOT method framework','/Author':'','/Creator':'','/Producer':'','/Subject':''})
out=ROOT/'Figure2_NIPSStyle_R5.pdf'
with out.open('wb') as f: wr.write(f)
doc=fitz.open(str(out)); page=doc[0]
pix=page.get_pixmap(matrix=fitz.Matrix(300/72,300/72),alpha=False)
png=ROOT/'Figure2_NIPSStyle_R5_300dpi.png'; pix.save(str(png))
(ROOT/'Figure2_NIPSStyle_R5.svg').write_text(page.get_svg_image(matrix=fitz.Matrix(1,1),text_as_path=1),encoding='utf-8')
im=Image.open(png).convert('RGB'); ImageOps.grayscale(im).convert('RGB').save(ROOT/'Figure2_NIPSStyle_R5_grayscale.png')
import numpy as np
arr=np.asarray(im).astype(float)/255
for label,m in {'deuteranopia':np.array([[.625,.375,0],[.70,.30,0],[0,.30,.70]]),'protanopia':np.array([[.567,.433,0],[.558,.442,0],[0,.242,.758]])}.items():
 Image.fromarray((np.clip(arr@m.T,0,1)*255).astype('uint8')).save(ROOT/f'Figure2_NIPSStyle_R5_{label}.png')
# Text-size report from the editable source.
prs=Presentation(str(ROOT/'Figure2_NIPSStyle_R5.pptx')); vals=[]; named={}
def rec(sh):
 if hasattr(sh,'shapes'):
  for x in sh.shapes: rec(x)
 elif hasattr(sh,'text_frame'):
  for p in sh.text_frame.paragraphs:
   for r in p.runs:
    if r.text.strip() and r.font.size:
     vals.append(float(r.font.size.pt)); named.setdefault(sh.name,[]).append(float(r.font.size.pt))
for sh in prs.slides[0].shapes: rec(sh)
font={'all_text_runs_min_pt':min(vals),'all_text_runs_count':len(vals),'formula_text_min_pt':min(v for k,vs in named.items() if any(t in k for t in ['eq','formula','constraint']) for v in vs),'source':'editable PPTX runs; formulas are native text in this candidate'}
(ROOT/'font_report.json').write_text(json.dumps(font,indent=2),encoding='utf-8')
# Structural QA: formula cards are independent and do not intersect one another.
checks={'formula_cards':{'price_fusion_eq':'feedback_eq','feedback_eq':'feedback_def','feedback_def':'advantage_eq','advantage_eq':'actor_update'},'removed_solver_internals':['kernel','projection_formula_box','iterations','repeat','certbox']}
boxes={}
def collect(sh):
 if sh.name in {'price_fusion_eq','feedback_eq','feedback_def','advantage_eq','actor_update','projection_formula','projection_caption','projection_note','price_output'}:
  boxes[sh.name]=(sh.left/914400,sh.top/914400,sh.width/914400,sh.height/914400)
 if hasattr(sh,'shapes'):
  for x in sh.shapes: collect(x)
for sh in prs.slides[0].shapes: collect(sh)
def overlap(a,b):
 ax,ay,aw,ah=boxes[a];bx,by,bw,bh=boxes[b]
 return max(0,min(ax+aw,bx+bw)-max(ax,bx))*max(0,min(ay+ah,by+bh)-max(ay,by))
checks['formula_card_overlaps']={f'{a}:{b}':overlap(a,b) for a,b in [('price_fusion_eq','feedback_eq'),('feedback_eq','feedback_def'),('feedback_def','advantage_eq'),('advantage_eq','actor_update')]}
checks['passed']=all(v==0 for v in checks['formula_card_overlaps'].values()) and not any(find for find in checks['removed_solver_internals'] if find in named)
(ROOT/'layout_qa.json').write_text(json.dumps(checks,indent=2,ensure_ascii=False),encoding='utf-8')
manifest={'branch':'NIPSStyle_R5','basis':'NIPSStyle_R4 Figure 2 editable baseline','figure2_changes':['removed stale solver kernel/capacity-composition equations','separated projection, safety-price output, feedback, and priced-advantage cards','kept one equation per card with explicit beta residual'],'figure1_unchanged':'NIPSStyle_R4','paper_source_modified':False,'anonymous_exports':True,'print_size_in': [5.5,3.0954],'font_report':'font_report.json','layout_qa':'layout_qa.json','sha256':hashlib.sha256(png.read_bytes()).hexdigest()}
(ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8')
(ROOT/'HANDOFF.md').write_text('''# NIPSStyle R5 handoff\n\nFigure 2 is a layout-only continuation of the NIPSStyle R4 editable baseline. The fifth column now separates the graph price, observed-cost feedback, normalized priced advantage, and PPO/TRPO update into non-overlapping cards. Column 4 shows only the observed-to-target flow, the projection caption, and the safety-price output; solver-kernel internals and stale capacity-composition equations were removed.\n\nThe displayed equations are the method-level equations: `F-hat -> F-star`, soft/hard constraints, `lambda_k = bar-lambda_k-star + beta_k`, the beta residual update, and the normalized priced advantage. Detailed solver derivation remains in the paper. Figure 1 is unchanged from NIPSStyle R4. The PPTX remains editable; PDF/SVG are vector exports.\n''',encoding='utf-8')
(ROOT/'PROCESS_NOTES.md').write_text('''# Process notes — NIPSStyle R5\n\nRound 1: inspected R4 at 5.5-inch print width and identified the overlap source: a detached kernel equation, old iteration labels, and a repeated PPO label occupying the projection/feedback lanes.\n\nRound 2: removed those stale solver internals; reduced column 3 to the two constraints used by the method; separated column 4 into projection, flow labels, and safety-price output; and placed the three actor-side equations in independent cards.\n\nRound 3: rendered through LibreOffice, checked the 300-dpi print PNG, grayscale/CVD previews, card intersection QA, and anonymous PDF metadata. No manuscript or experimental data were changed.\n''',encoding='utf-8')
# Include the editable source and reproducibility notes; keep old R4 source untouched.
with zipfile.ZipFile(ROOT/'NIPSStyle_R5_sources.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in [ROOT/'Figure2_NIPSStyle_R5.pptx',ROOT/'build_r5.py',ROOT/'package_r5.py',ROOT/'font_report.json',ROOT/'layout_qa.json',ROOT/'manifest.json',ROOT/'HANDOFF.md',ROOT/'PROCESS_NOTES.md']:
  z.write(p,p.name)
print(json.dumps({'pdf':str(out),'png':str(png),'font':font,'qa':checks},ensure_ascii=False,indent=2))
